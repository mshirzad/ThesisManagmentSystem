package com.example.eventhub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eventhub.Models.Tickets;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class EditTicketActivity extends AppCompatActivity {

    TextView txt_startDate, txt_endDate, txt_name_length,d_title;
    String postid, str_price,str_startDate,str_endDate;
    Button btn_free, btn_paid, btn_publish, btn_cancel;
    FirebaseUser firebaseUser;
    RelativeLayout frm_free_price;
    EditText txt_price, txt_description, txt_quantity, txt_ticket_name;
    LinearLayout frm_startDate, frm_endDate, frm_quantity, frm_description, frm_name, frm_price;
    private View decorView;
    Calendar c,m;
    ArrayAdapter<CharSequence> adapter;
    Spinner spinner;
    long aLong,maxDate;

    int DAY,Dayofmonth,MONTH,YEAR;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket);
        txt_price = (EditText) findViewById(R.id.txt_price);
        txt_description = (EditText) findViewById(R.id.txt_description);
        txt_quantity = (EditText) findViewById(R.id.txt_quantity);
        txt_ticket_name = (EditText) findViewById(R.id.txt_ticket_name);
        txt_name_length = (TextView) findViewById(R.id.txt_name_length);
        frm_price = (LinearLayout) findViewById(R.id.frm_price);
        txt_startDate = findViewById(R.id.txt_startDate);
        txt_endDate = findViewById(R.id.txt_endDate);
        frm_startDate = (LinearLayout) findViewById(R.id.frm_startDate);
        frm_endDate = (LinearLayout) findViewById(R.id.frm_endDate);
        frm_quantity = (LinearLayout) findViewById(R.id.frm_quantity);
        frm_description = (LinearLayout) findViewById(R.id.frm_description);
        frm_name = (LinearLayout) findViewById(R.id.frm_ticket_name);
        frm_free_price = (RelativeLayout) findViewById(R.id.frm_free_price);
        btn_free = (Button) findViewById(R.id.btn_free);
        btn_paid = (Button) findViewById(R.id.btn_paid);
        btn_cancel = findViewById(R.id.btn_cancel);
        btn_publish = findViewById(R.id.btn_publish);
        d_title = findViewById(R.id.d_title);
        d_title.setText("Edit Ticket");

         spinner = (Spinner) findViewById(R.id.spinner);
        adapter = ArrayAdapter.createFromResource(this,R.array.refund,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setDropDownVerticalOffset(60);

        spinner.setAdapter(adapter);
        spinner.getOnItemClickListener();


// get the extra values
        postid = getIntent().getStringExtra("postid");
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder b = new AlertDialog.Builder(EditTicketActivity.this, R.style.dialogTheme);
                b.setMessage("Are sure you want to cancel?");

                b.setPositiveButton("Yes, Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        startActivity(new Intent(EditTicketActivity.this, MainActivity.class));
                        finish();
                    }
                });
                b.setNegativeButton("No, Continue", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {


                    }
                });
                b.show();
            }
        });
        btn_publish.setText("Apply");
        //fetch data from firebase database
        fetchTicketData();
        btn_publish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                upload();
            }
        });





        txt_name_length.setText((int) txt_ticket_name.length() + " / 30");
        txt_ticket_name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_name_length.setText((int) txt_ticket_name.length() + " / 30");
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_name_length.setText((int) txt_ticket_name.length() + " / 30");
            }

            @Override
            public void afterTextChanged(Editable editable) {
                txt_name_length.setText((int) txt_ticket_name.length() + " / 30");
            }
        });

        // change focus in free button and hide the paid price
        btn_free.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btn_free.setBackgroundResource(R.drawable.button_background_focus);
                btn_paid.setBackgroundResource(R.drawable.button_background_notfocus);
                frm_price.setVisibility(View.GONE);
                frm_free_price.setVisibility(View.VISIBLE);

            }
        });
        // change focus in paid button and hide the free price
        btn_paid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                btn_free.setBackgroundResource(R.drawable.button_background_notfocus);
                btn_paid.setBackgroundResource(R.drawable.button_background_focus);
                frm_price.setVisibility(View.VISIBLE);
                frm_free_price.setVisibility(View.GONE);

            }
        });


// focus goes on linear layout child by clicking on it
        frm_price.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_price.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(txt_price, 1);
            }
        });
        // focus goes on linear layout child by clicking on it
        frm_description.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_description.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(txt_description, 1);
            }
        });
        // focus goes on linear layout child by clicking on it
        frm_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_ticket_name.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(txt_ticket_name, 1);
            }
        });
        frm_quantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_quantity.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(txt_quantity, 1);
            }
        });

//show Status bar on swipe
        decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int Visibility) {
                if(Visibility == 0)
                    decorView.setSystemUiVisibility(hideSystermBars());

            }
        });


    }

    //hide status bar on focus
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus){
            decorView.setSystemUiVisibility(hideSystermBars());
        }
    }
    // UI elements to hide and show
    private int hideSystermBars(){
        return View.SYSTEM_UI_FLAG_FULLSCREEN
                |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

    }



    public void upload() {

        final ProgressDialog progressDialog = new ProgressDialog(this,android.R.style.Theme_DeviceDefault_Light_Dialog);
        progressDialog.setMessage("Posting...");
        //prevent from progress dialog canelation on touch outside
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        if (frm_price.getVisibility() == View.VISIBLE) {
            str_price = txt_price.getText().toString();

        } else if (frm_free_price.getVisibility() == View.VISIBLE) {
            str_price = "Free";
        }


        String str_name = txt_ticket_name.getText().toString().trim();
        String str_quantity = txt_quantity.getText().toString().trim();
        String str_startSales = txt_startDate.getText().toString().trim();
        String str_endSales = txt_endDate.getText().toString().trim();
        String str_description = txt_description.getText().toString().trim();
        Spinner spinner = findViewById(R.id.spinner);
        final  String str_refund_policy = spinner.getSelectedItem().toString().trim();


        if (str_price.equals("0")) {
            progressDialog.dismiss();
            Toast.makeText(this, "Your price should be free or more than 0 AFN!", Toast.LENGTH_SHORT).show();
        } else {

            if (TextUtils.isEmpty(str_name) || TextUtils.isEmpty(str_quantity) || TextUtils.isEmpty(str_startSales) || TextUtils.isEmpty(str_endSales) || TextUtils.isEmpty(str_description) || TextUtils.isEmpty(str_price)) {
                progressDialog.dismiss();
                Toast.makeText(EditTicketActivity.this, "All fields are requred!", Toast.LENGTH_SHORT).show();
            } else {

                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Tickets");
                String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                //add notifications
                Map<String, Object> hashmap = new HashMap<>();
                hashmap.put("name", str_name);
                hashmap.put("quantity", str_quantity);
                hashmap.put("startDate", str_startDate);
                hashmap.put("endDate", str_endDate);
                hashmap.put("publisher", userid);
                hashmap.put("description", str_description);
                hashmap.put("price", str_price);
                hashmap.put("refundpolicy", str_refund_policy);
                reference.child(postid).updateChildren(hashmap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        FirebaseDatabase.getInstance().getReference("Unpublished").child(postid).removeValue();
                        progressDialog.dismiss();
                        startActivity(new Intent(EditTicketActivity.this, MainActivity.class));
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(EditTicketActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

            }
        }


    }


    // Date picker for end date and start date
    public void openSelectedDate(View view) {
        c = Calendar.getInstance();
        m = Calendar.getInstance();
        Dayofmonth = c.get(Calendar.DAY_OF_MONTH);
        MONTH = c.get(Calendar.MONTH);
        YEAR = c.get(Calendar.YEAR);
        if (view.getId() == R.id.frm_startDate){

            final DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayofmonth) {
                    int mo = monthOfYear + 1;
                    txt_endDate.setText(null);

                    //change calendar date to the first datepicker date
                    m.set(Calendar.DAY_OF_MONTH, dayofmonth);
                    m.set(Calendar.YEAR, year);
                    m.set(Calendar.MONTH, monthOfYear);
                    str_startDate = String.valueOf(m.getTimeInMillis());

                    m.add(Calendar.DAY_OF_MONTH,1);
                    aLong = m.getTimeInMillis();

                    txt_startDate.setText(dayofmonth + " " + generateMonthabb(mo) + "," + year);



                    m.add(Calendar.YEAR,1);
                    m.add(Calendar.MONTH,6);
                    maxDate = m.getTimeInMillis();





                }

            };
            DatePickerDialog datePickerDialog = new DatePickerDialog(this, R.style.dialogTheme, listener, YEAR, MONTH, Dayofmonth);
            datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
            c.add(Calendar.YEAR,1);
            c.add(Calendar.MONTH,6);
            datePickerDialog.getDatePicker().setMaxDate(c.getTimeInMillis());
            datePickerDialog.show();




        }else if (view.getId() == R.id.frm_endDate){
            String d =   txt_startDate.getText().toString();
            if (txt_startDate.getText().toString().length() > 0) {

                DatePickerDialog.OnDateSetListener listener2 = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {




                        m.set(Calendar.MONTH,monthOfYear);
                        m.set(Calendar.YEAR, year);
                        m.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        str_endDate = String.valueOf(m.getTimeInMillis());



                        txt_endDate.setText(dayOfMonth  +" "+ generateMonthabb((monthOfYear + 1)) + "," + year);



                    }
                };
                DatePickerDialog datePickerDialogenddate = new DatePickerDialog(this, R.style.dialogTheme, listener2, YEAR, MONTH, DAY);
                datePickerDialogenddate.getDatePicker().setMinDate(aLong - 1000);
                datePickerDialogenddate.getDatePicker().setMaxDate(maxDate);
                datePickerDialogenddate.show();


            }else  {
                Toast.makeText(this, "You must select the starting date first!", Toast.LENGTH_SHORT).show();
            }

        }else {
            Toast.makeText(this, "nothing", Toast.LENGTH_SHORT).show();
        }


    }



    // get the day of week integers and return string day name
    public String generateDays(int day) {
        String days;
        if (day == 7) {
            return days = "Saturday";
        } else if (day == 1)
            return days = "Sunday";
        else if (day == 2)
            return days = "Monday";
        else if (day == 3)
            return days = "Tuesday";
        else if (day == 4)
            return days = "wednesday";
        else if (day == 5)
            return days = "Thursday";
        else if (day == 6)
            return days = "Friday";
        else
            return days = "";


    }

    public String generateMonth(int month) {
        String monthName;

        if (month == 1) {
            return monthName = "January";
        } else if (month == 2) {
            return monthName = "February";
        } else if (month == 3) {
            return monthName = "March";
        } else if (month == 4) {
            return monthName = "April";
        } else if (month == 5) {
            return monthName = "May";
        } else if (month == 6) {
            return monthName = "June";
        } else if (month == 7) {
            return monthName = "July";
        } else if (month == 8) {
            return monthName = "August";
        } else if (month == 9) {
            return monthName = "September";
        } else if (month == 10) {
            return monthName = "October";
        } else if (month == 11) {
            return monthName = "November";
        } else if (month == 12) {
            return monthName = "December";

        } else {
            return null;
        }

    }

    public String generateDaysabb(int day) {
        String days;
        if (day == 7) {
            return days = "Sat";
        } else if (day == 1)
            return days = "Sun";
        else if (day == 2)
            return days = "Mon";
        else if (day == 3)
            return days = "Tue";
        else if (day == 4)
            return days = "wed";
        else if (day == 5)
            return days = "Thu";
        else if (day == 6)
            return days = "Fri";
        else
            return days = "";


    }

    public String generateMonthabb(int month) {
        String monthName;

        if (month == 1) {
            return monthName = "Jan";
        } else if (month == 2) {
            return monthName = "Feb";
        } else if (month == 3) {
            return monthName = "Mar";
        } else if (month == 4) {
            return monthName = "Apr";
        } else if (month == 5) {
            return monthName = "May";
        } else if (month == 6) {
            return monthName = "Jun";
        } else if (month == 7) {
            return monthName = "Jul";
        } else if (month == 8) {
            return monthName = "Aug";
        } else if (month == 9) {
            return monthName = "Sep";
        } else if (month == 10) {
            return monthName = "Oct";
        } else if (month == 11) {
            return monthName = "Nov";
        } else if (month == 12) {
            return monthName = "Dec";

        } else {
            return null;
        }

    }

    public void fetchTicketData(){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Tickets").child(postid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    Tickets tickets = dataSnapshot.getValue(Tickets.class);
                    txt_description.setText(tickets.getDescription());
                    txt_quantity.setText(tickets.getQuantity());
                    txt_ticket_name.setText(tickets.getName());
                    spinner.setSelection(adapter.getPosition(tickets.getRefundpolicy()));

                    if (!tickets.getPrice().equals("Free")){
                        frm_free_price.setVisibility(View.GONE);
                        frm_price.setVisibility(View.VISIBLE);
                        txt_price.setText(tickets.getPrice());
                    }
                    Long l = Long.parseLong(tickets.getStartDate());
                    Calendar c = Calendar.getInstance();
                    c.setTimeInMillis(l);
                    str_startDate = tickets.getStartDate();
                    txt_startDate.setText(c.get(Calendar.DAY_OF_MONTH)  +" "+ generateMonthabb(c.get(Calendar.MONTH)) + "," + c.get(Calendar.YEAR));
                    Long e = Long.parseLong(tickets.getEndDate());
                    c.setTimeInMillis(e);
                    str_endDate = tickets.getEndDate();
                    txt_endDate.setText(c.get(Calendar.DAY_OF_MONTH)  +" "+ generateMonthabb(c.get(Calendar.MONTH)) + "," + c.get(Calendar.YEAR));

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}
