package com.example.eventhub.Fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.eventhub.Adapter.PhotosAdapter;
import com.example.eventhub.EditProfileActivity;
import com.example.eventhub.Models.Posts;
import com.example.eventhub.Models.Tickets;
import com.example.eventhub.Models.User;
import com.example.eventhub.OptionsActivity;
import com.example.eventhub.R;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;


public class ProfileFragment extends Fragment {

    FirebaseUser firebaseUser;
    ImageView btn_setting, img_profile, img_edit;
    TextView txt_username, txt_email, txt_likes, txt_tickets, txt_following, txt_posts, txt_saved_posts;
    ImageButton btn_img_showPosts, btn_img_savePosts;
    RecyclerView recycler_view_post, recycler_view_save;
    LinearLayout frm_tickets, frm_likes, frm_following, layout;
    ScrollView scrollView;
    ShimmerFrameLayout shimmer_container;
    CircleImageView confirm;
    PhotosAdapter photosAdapter;
    PhotosAdapter photosAdapter_saves;
    List<Posts> postsList;
    List<String> savedList;
    List<String> publishedList;
    List<Posts> postsListSaved;

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        btn_setting = view.findViewById(R.id.btn_setting);
        img_profile = view.findViewById(R.id.img_profile);
        img_edit = view.findViewById(R.id.img_edit);
        shimmer_container = view.findViewById(R.id.shimmer_container);
        scrollView = view.findViewById(R.id.scrollView);
        confirm = view.findViewById(R.id.confirm);
        layout = view.findViewById(R.id.layout);
        txt_username = view.findViewById(R.id.txt_username);
        txt_email = view.findViewById(R.id.txt_email);
        txt_posts = view.findViewById(R.id.txt_posts);
        txt_saved_posts = view.findViewById(R.id.txt_saved_posts);
        txt_likes = view.findViewById(R.id.txt_likes);
        txt_tickets = view.findViewById(R.id.txt_tickets);
        txt_following = view.findViewById(R.id.txt_following);
        btn_img_showPosts = view.findViewById(R.id.btn_img_showPosts);
        btn_img_savePosts = view.findViewById(R.id.btn_img_savePosts);
        recycler_view_post = view.findViewById(R.id.recycler_view_post);
        recycler_view_save = view.findViewById(R.id.recycler_view_save);
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        frm_following = view.findViewById(R.id.frm_following);
        frm_likes = view.findViewById(R.id.frm_likes);
        frm_tickets = view.findViewById(R.id.frm_tickets);

        shimmer_container.startShimmer();


        recycler_view_post.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new GridLayoutManager(getContext(), 3);
        recycler_view_post.setLayoutManager(linearLayoutManager);
        postsList = new ArrayList<>();
        photosAdapter = new PhotosAdapter(getContext(), postsList);
        recycler_view_post.setAdapter(photosAdapter);


        recycler_view_save.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager1 = new GridLayoutManager(getContext(), 3);
        recycler_view_save.setLayoutManager(linearLayoutManager1);
        postsListSaved = new ArrayList<>();
        photosAdapter_saves = new PhotosAdapter(getContext(), postsListSaved);
        recycler_view_save.setAdapter(photosAdapter_saves);

        recycler_view_save.setVisibility(View.GONE);
        recycler_view_post.setVisibility(View.VISIBLE);


        img_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), EditProfileActivity.class));
            }
        });
        btn_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), OptionsActivity.class));
            }
        });

        btn_img_showPosts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (postsList.size() == 0) {
                    txt_saved_posts.setVisibility(View.GONE);
                    txt_posts.setVisibility(View.VISIBLE);
                } else {
                    txt_saved_posts.setVisibility(View.GONE);
                    txt_posts.setVisibility(View.GONE);
                }
                recycler_view_post.setVisibility(View.VISIBLE);
                recycler_view_save.setVisibility(View.GONE);
                btn_img_showPosts.setImageResource(R.drawable.ic_posts_red);
                btn_img_savePosts.setImageResource(R.drawable.ic_favorite_border_black_24dp);
            }
        });
        btn_img_savePosts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (postsListSaved.size() == 0) {
                    txt_saved_posts.setVisibility(View.VISIBLE);
                    txt_posts.setVisibility(View.GONE);
                } else {
                    txt_saved_posts.setVisibility(View.GONE);
                    txt_posts.setVisibility(View.GONE);
                }
                recycler_view_post.setVisibility(View.GONE);
                recycler_view_save.setVisibility(View.VISIBLE);
                btn_img_showPosts.setImageResource(R.drawable.ic_posts);
                btn_img_savePosts.setImageResource(R.drawable.ic_favorites);
            }
        });
        frm_likes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (postsListSaved.size() == 0) {
                    txt_saved_posts.setVisibility(View.VISIBLE);
                    txt_posts.setVisibility(View.GONE);
                } else {
                    txt_saved_posts.setVisibility(View.GONE);
                    txt_posts.setVisibility(View.GONE);
                }
                recycler_view_post.setVisibility(View.GONE);
                recycler_view_save.setVisibility(View.VISIBLE);
                btn_img_showPosts.setImageResource(R.drawable.ic_posts);
                btn_img_savePosts.setImageResource(R.drawable.ic_favorites);
            }
        });
        frm_tickets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BottomNavigationView bottomNavigationView = getActivity().findViewById(R.id.bottom_navigation);
                bottomNavigationView.setSelectedItemId(R.id.navigation_tickets);
                ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new TicketsFragment()).commit();
            }
        });
        frm_following.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new FollowingOrganizersFragment()).addToBackStack(null).commit();
            }
        });
        getPublishedLists();
        mySavedPosts();
        userinfo(txt_email, txt_username, txt_following, txt_likes, txt_tickets, img_profile);


        return view;

    }


    private void userinfo(final TextView txt_email, final TextView txt_username, final TextView txt_following, final TextView txt_likes, final TextView txt_tickets, final ImageView img_profile) {
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Users").child(firebaseUser.getUid());
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user = dataSnapshot.getValue(User.class);
                txt_email.setText(firebaseUser.getEmail());
                txt_username.setText(user.getFirstname() + " " + user.getLastname());
                if (getActivity() != null) {
                    isconfirmed(user.getId(),confirm);
                    if (!user.getImageurl().isEmpty() && !user.getImageurl().equals("https://firebasestorage.googleapis.com/v0/b/eventhub-5ecec.appspot.com/o/user%20(1).png?alt=media&token=58590a57-0254-4a2a-b733-56874d051cd4")){
                    Glide.with(getActivity()).load(user.getImageurl()).into(img_profile);}
                    shimmer_container.stopShimmer();
                    shimmer_container.setVisibility(View.GONE);
                    scrollView.setBackgroundColor(getResources().getColor(R.color.lightpurple));
                    layout.setVisibility(View.VISIBLE);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference().child("Saves").child(firebaseUser.getUid());
        reference1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    txt_likes.setText(String.valueOf(dataSnapshot.getChildrenCount()));
                } else {
                    txt_likes.setText("0");
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        DatabaseReference reference2 = FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid()).child("following");
        reference2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    txt_following.setText(String.valueOf(dataSnapshot.getChildrenCount()));
                } else {
                    txt_following.setText("0");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        DatabaseReference reference3 = FirebaseDatabase.getInstance().getReference().child("Joined").child(firebaseUser.getUid());
        reference3.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists() && dataSnapshot.getChildrenCount() != 0) {
                    txt_tickets.setText(String.valueOf(dataSnapshot.getChildrenCount()));
                } else {
                    txt_tickets.setText("0");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void getPublishedLists() {
        publishedList = new ArrayList<>();
        publishedList.clear();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Tickets");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {

                    Tickets tickets = snapshot.getValue(Tickets.class);
                    if (tickets.getPublisher().equals(firebaseUser.getUid())) {
                        publishedList.add(snapshot.getKey());
                    }

                }
                myPosts();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void myPosts() {


        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                postsList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Posts posts = snapshot.getValue(Posts.class);
                    for (String id : publishedList) {
                        if (posts.getPostid().equals(id)) {
                            txt_posts.setVisibility(View.GONE);
                            postsList.add(posts);
                        }
                    }
                }
                Collections.reverse(postsList);
                photosAdapter.notifyDataSetChanged();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


    private void mySavedPosts() {
        savedList = new ArrayList<>();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Saves").child(firebaseUser.getUid());
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        savedList.add(snapshot.getKey());
                    }
                    readSavedPosts();


                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void readSavedPosts() {

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                postsListSaved.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Posts posts = snapshot.getValue(Posts.class);
                    for (String id : savedList) {
                        if (posts.getPostid().equals(id)) {
                            txt_saved_posts.setVisibility(View.GONE);
                            postsListSaved.add(posts);
                        }
                    }


                }
                photosAdapter_saves.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void isconfirmed(String id,final CircleImageView circleImageView) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Confirmed").child(id);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    circleImageView.setVisibility(View.VISIBLE);
                } else {
                    circleImageView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }



}
