package com.example.eventhub.Fragments;

import android.app.ActionBar;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.eventhub.Adapter.RelevantPostsAdapter;
import com.example.eventhub.Models.Organizers;
import com.example.eventhub.Models.Posts;
import com.example.eventhub.Models.Tickets;
import com.example.eventhub.Models.User;
import com.example.eventhub.R;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class PostDetailsFragment extends Fragment {
    public ImageView image_profile, post_image, favorites, share,img_profile,img_event_state,img_event_state2;
    public TextView username, description, eventDate, title, txt_title, venue,txt_sales_end, readmore,txt_event_state, eventTime, refundpolicy, feesDescription, description_view, btn_back, txt_price,txt_desc,user_name;
    public FrameLayout back_icon, share_icon, ic_favorites,menue, framelayout_follow;
    public Button btn_follow, btn_register,bt_follow,btn_seeParticipant;
    View progress_bar;
    public Dialog dialog;
    FirebaseUser firebaseUser;
    public List<Posts> mPost;
    CircleImageView confirm1,confirm;

    private RecyclerView recyclerView_sameEvents;
    private List<Posts> postlists;
    private RelevantPostsAdapter relevantPostsAdapter;
    String postid, category,publisher,publisherid;
    FragmentManager fragmentManager;
    private List<String> publishedlist;
    LinearLayout li;
    RelativeLayout rl;



    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_post_details, container, false);
        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        back_icon = view.findViewById(R.id.ic_back);
        confirm = view.findViewById(R.id.confirm);
        confirm1 = view.findViewById(R.id.confirm1);
        image_profile = view.findViewById(R.id.image_profile);
        user_name = view.findViewById(R.id.user_name);
        txt_desc = view.findViewById(R.id.txt_desc);
        img_event_state2 = view.findViewById(R.id.img_event_state2);
        img_event_state = view.findViewById(R.id.img_event_state);
        txt_event_state = view.findViewById(R.id.txt_event_state);
        li = view.findViewById(R.id.li);
        rl = view.findViewById(R.id.rl);
        txt_sales_end = view.findViewById(R.id.txt_sales_end);
        bt_follow = view.findViewById(R.id.bt_follow);
        img_profile = view.findViewById(R.id.img_profile);
        title = view.findViewById(R.id.txt_title_in_menue);
        post_image = view.findViewById(R.id.post_image);
        txt_title = view.findViewById(R.id.txt_title);
        username = view.findViewById(R.id.username);
        menue = view.findViewById(R.id.ic_menu_ver);
        btn_follow = view.findViewById(R.id.btn_follow);
        btn_seeParticipant = view.findViewById(R.id.btn_seeParticipant);
        eventDate = view.findViewById(R.id.txt_dateofevent);
        eventTime = view.findViewById(R.id.txt_timeofevent);
        venue = view.findViewById(R.id.txt_venue_location);
        refundpolicy = view.findViewById(R.id.txt_fees);
        feesDescription = view.findViewById(R.id.txt_fees_description);
        description = view.findViewById(R.id.txt_description);
        readmore = view.findViewById(R.id.btn_readMore);
        AppBarLayout appBarLayout = view.findViewById(R.id.app_bar);
        btn_register = view.findViewById(R.id.btn_register);
        txt_price = view.findViewById(R.id.txt_price);
        progress_bar = view.findViewById(R.id.progress_bar);
        favorites = view.findViewById(R.id.img_favorite);
        ic_favorites = view.findViewById(R.id.ic_favorites);


        menue.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                showMenu(menue);
            }
        });
        bottomNavigationView.setVisibility(View.GONE);




        back_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    getActivity().onBackPressed();
            }
        });

// show the title while toolbar is collapsed
        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int i) {
                if (Math.abs(i) - appBarLayout.getTotalScrollRange() == 0) {
                  //collapsed
                    title.setVisibility(View.VISIBLE);

                } else {
                    //expanded
                    title.setVisibility(View.GONE);
                }

            }
        });




        SharedPreferences preferences = getContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE);
        postid = preferences.getString("postid", "none");
        SharedPreferences pref = getContext().getSharedPreferences("PREF", Context.MODE_PRIVATE);
        category = pref.getString("category", "none");

        //show ticket detail
        final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Tickets").child(postid);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    final Tickets tickets = dataSnapshot.getValue(Tickets.class);
                    final String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                    final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Participants").child(postid);
                    databaseReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            //check the sales end date
                            Long endDate = Long.parseLong(tickets.getEndDate());
                            Calendar t = Calendar.getInstance();
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTimeInMillis(endDate);
                            calendar.set(Calendar.HOUR_OF_DAY, 0);
                            calendar.set(Calendar.MINUTE, 0);
                            calendar.set(Calendar.MILLISECOND, 0);
                            calendar.set(Calendar.SECOND, 0);
                            if (firebaseUser.getUid().equals(tickets.getPublisher())) {
                                btn_seeParticipant.setVisibility(View.VISIBLE);
                                btn_seeParticipant.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        ((FragmentActivity)getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner,new ParticipantFragment()).addToBackStack(null).commit();
                                    }
                                });
                            }else {
                                Long l = dataSnapshot.getChildrenCount();
                                String join = (String) l.toString();
                                if (!tickets.getPublisher().isEmpty()) {
                                    if (join.equals(tickets.getQuantity())) {
                                        btn_register.setClickable(false);
                                        btn_register.setTextColor(getResources().getColor(R.color.colorAccent));
                                        btn_register.setText("No Ticket Left");
                                    }
                                    if (dataSnapshot.child(userid).exists()) {
                                        btn_register.setClickable(false);
                                        btn_register.setTextColor(getResources().getColor(R.color.colorAccent));
                                        btn_register.setText("Already Joined");
                                    }

                                    Date eventStartDate = calendar.getTime();
                                    Calendar currentDate = Calendar.getInstance();
                                    Date current = currentDate.getTime();
                                    if (current.after(eventStartDate)) {
                                        btn_register.setClickable(false);
                                        btn_register.setTextColor(getResources().getColor(R.color.colorAccent));
                                        btn_register.setText("Sales Ended");

                                    }
                                }else {
                                    btn_register.setText("Event Canceled");
                                    btn_register.setClickable(false);
                                }

                                if (!FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()){
                                    btn_register.setClickable(false);
                                    btn_register.setTextColor(getResources().getColor(R.color.colorAccent));
                                    btn_register.setText("Register");
                                }
                                }
                            publisherid = tickets.getPublisher();
                            String  endSales = generateDaysabb(calendar.get(Calendar.DAY_OF_WEEK))+", " + generateMonthabb(((calendar.get(Calendar.MONTH))+1))+" "+calendar.get(Calendar.DAY_OF_MONTH)+", "+calendar.get(Calendar.YEAR);
                            txt_sales_end.setText(endSales);
                            progress_bar.setVisibility(View.GONE);



                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });



                    if (tickets.getPrice().equals("Free"))
                    txt_price.setText("      "+tickets.getPrice());
                    else
                    txt_price.setText(tickets.getPrice() + " AFN");
                    refundpolicy.setText(tickets.getRefundpolicy());
                } else {

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        isSaved(postid, favorites);


        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = getContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE).edit();
                editor.putString("postid", postid);
                editor.apply();
                ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new TicketDetailsFragment()).addToBackStack(null).commit();
            }
        });


        recyclerView_sameEvents = view.findViewById(R.id.recycler_view_sameEvents);

        LinearLayoutManager linearLayoutManagerHorizontal = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        linearLayoutManagerHorizontal.setAutoMeasureEnabled(true);

        recyclerView_sameEvents.setLayoutManager(linearLayoutManagerHorizontal);

        postlists = new ArrayList<>();
        relevantPostsAdapter = new RelevantPostsAdapter(getContext(), postlists);

        recyclerView_sameEvents.setAdapter(relevantPostsAdapter);


        //show post details
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts").child(postid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                final Posts post = dataSnapshot.getValue(Posts.class);
                //check if following then change button
                isFollowing(post.getPublisher(), btn_follow);
                isFollowing(post.getPublisher(), bt_follow);
                isconfirmed(post.getPublisher(),confirm);
                isconfirmed(post.getPublisher(),confirm1);
                //check publisher info
                publisherid = post.getPublisher();
                if (post.getPublisher().isEmpty()){
                    rl.setVisibility(View.GONE);
                    li.setVisibility(View.GONE);
                }else {
                    publisherinfo(image_profile, username,null, post.getPublisher());
                    publisherinfo(img_profile, user_name,txt_desc, post.getPublisher());
                }

                ic_favorites.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (favorites.getTag().equals("save")){
                            FirebaseDatabase.getInstance().getReference().child("Saves")
                                    .child(firebaseUser.getUid()).child(post.getPostid()).setValue(true);
                        }else {
                            FirebaseDatabase.getInstance().getReference().child("Saves")
                                    .child(firebaseUser.getUid()).child(post.getPostid()).removeValue();
                        }


                    }
                });

                if (post.getPublisher().equals(firebaseUser.getUid())) {
                    btn_follow.setVisibility(View.GONE);
                    bt_follow.setVisibility(View.GONE);
                }
                if (post.getDescription().length() <= 250){
                    readmore.setVisibility(View.GONE);
                }

                readmore.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog = new Dialog(getActivity(), R.style.AppTheme_FullScreen);
                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialog.setContentView(R.layout.description_layout);
                        Window window = dialog.getWindow();
                        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
                        dialog.show();
                        btn_back = dialog.findViewById(R.id.btn_back);
                        description_view = (TextView) dialog.findViewById(R.id.txt_description_more);


                        description_view.setText(post.getDescription());

                        btn_back.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog.dismiss();
                            }
                        });
                    }
                });

                btn_follow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (btn_follow.getText().toString().equals("Follow")) {
                            FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                                    .child("following").child(post.getPublisher()).setValue(true);
                            FirebaseDatabase.getInstance().getReference().child("Follow").child(post.getPublisher())
                                    .child("followers").child(firebaseUser.getUid()).setValue(true);
                        } else {
                            FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                                    .child("following").child(post.getPublisher()).removeValue();
                            FirebaseDatabase.getInstance().getReference().child("Follow").child(post.getPublisher())
                                    .child("followers").child(firebaseUser.getUid()).removeValue();

                        }
                    }
                });
                bt_follow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (btn_follow.getText().toString().equals("Follow")) {
                            FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                                    .child("following").child(post.getPublisher()).setValue(true);
                            FirebaseDatabase.getInstance().getReference().child("Follow").child(post.getPublisher())
                                    .child("followers").child(firebaseUser.getUid()).setValue(true);
                        } else {
                            FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                                    .child("following").child(post.getPublisher()).removeValue();
                            FirebaseDatabase.getInstance().getReference().child("Follow").child(post.getPublisher())
                                    .child("followers").child(firebaseUser.getUid()).removeValue();

                        }
                    }
                });


                if (getActivity() != null){
                Glide.with(getActivity()).load(post.getPostimage()).into(post_image);
                }


                String finalDate = generateDate(post.getStartDate(),post.getEndDate());
                String finalTime = generateTime(post.getStartTime(),post.getEndTime());
                eventDate.setText(finalDate);
                eventTime.setText(finalTime);
                venue.setText(post.getVenue());
                title.setText(post.getTitle());
                txt_title.setText(post.getTitle());
                description.setText(post.getDescription());
                txt_event_state.setText(post.getState());
                if (post.getState().equals("Confirmed")){
                    img_event_state.setBackgroundResource(R.drawable.ic_confirmed);
                    img_event_state2.setBackgroundResource(R.drawable.ic_confirmed);
                }else if (post.getState().equals("Changeable And Possible to Cancel")){
                    img_event_state.setBackgroundResource(R.drawable.ic_cancelable);
                    img_event_state2.setBackgroundResource(R.drawable.ic_cancelable);
                }else{
                    img_event_state.setBackgroundResource(R.drawable.ic_editable);
                    img_event_state2.setBackgroundResource(R.drawable.ic_editable);
                }

                checkPublishedPosts();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });







        return view;


    }

    //get posts that have been published and has ticket
    private void checkPublishedPosts() {
        publishedlist = new ArrayList<>();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Tickets");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                publishedlist.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    publishedlist.add(snapshot.getKey());
                }

                readSamePosts(category);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


    private void readSamePosts(String c) {
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        final String userid = firebaseUser.getUid();
        Query query = FirebaseDatabase.getInstance().getReference("posts").orderByChild("category")
                .startAt(c)
                .endAt(c + "\uf0ff");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                postlists.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Posts post = snapshot.getValue(Posts.class);

                    for (String id : publishedlist){
                        if (postid != null){
                            Calendar currentDate = Calendar.getInstance();
                            Date current = currentDate.getTime();
                            if (current.before(getDate(post.getStartDate(),post.getStartTime()))) {
                            if (post.getPostid().equals(id) && !post.getPostid().equals(postid)){
                                postlists.add(post);
                            }
                        }
                        }
                    }

                }

                relevantPostsAdapter.notifyDataSetChanged();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public void onStop() {
        super.onStop();
        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);

        bottomNavigationView.setVisibility(View.VISIBLE);

    }

    private void publisherinfo(final ImageView image_profile, final TextView username, final TextView txt_desc, final String userid) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Organizers").child(userid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                Organizers organizers = dataSnapshot.getValue(Organizers.class);
                if (getActivity() != null){
                Glide.with(getActivity()).load(organizers.getImageurl()).into(image_profile);
                }
                publisher = organizers.getUserid();
                username.setText(organizers.getName());
                if (txt_desc != null) {
                    txt_desc.setText(organizers.getDescription());
                    txt_desc.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            SharedPreferences.Editor editor = getContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE).edit();
                            editor.putString("profileid", userid);
                            editor.apply();

                            ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new OrganizerProfileFragment()).addToBackStack(null).commit();
                        }
                    });
                }
                image_profile.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        SharedPreferences.Editor editor = getContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE).edit();
                        editor.putString("profileid", userid);
                        editor.apply();

                        ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new OrganizerProfileFragment()).addToBackStack(null).commit();
                    }
                });
                username.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        SharedPreferences.Editor editor = getContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE).edit();
                        editor.putString("profileid", userid);
                        editor.apply();

                        ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new OrganizerProfileFragment()).addToBackStack(null).commit();
                    }
                });



            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void isFollowing(final String userid, final Button button) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                .child("Follow").child(firebaseUser.getUid()).child("following");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child(userid).exists()) {
                    button.setText("Following");
                    button.setBackgroundResource(R.drawable.button_focus);
                    ((Button)button).setTextColor(Color.parseColor("#ffffff"));

                } else {
                    button.setText("Follow");
                    button.setBackgroundResource(R.drawable.button_background);
                    ((Button)button).setTextColor(Color.parseColor("#455cde"));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public  String generateDate(String startDate,String endDate){
        String startDATE,endDATE,date;
        Calendar ed = Calendar.getInstance();
        Calendar sd = Calendar.getInstance();
        Long sDate = Long.parseLong(startDate);
        sd.setTimeInMillis(sDate);
        if (!endDate.isEmpty() && endDate.length() != 0){
            Long eDate = Long.parseLong(endDate);
            ed.setTimeInMillis(eDate);
            if (sd.get(Calendar.YEAR) == ed.get(Calendar.YEAR)) {
                startDATE = generateDaysabb(sd.get(Calendar.DAY_OF_WEEK))+", " + generateMonthabb(((sd.get(Calendar.MONTH))+1))+" "+sd.get(Calendar.DAY_OF_MONTH);
                endDATE = generateDaysabb(ed.get(Calendar.DAY_OF_WEEK))+", " + generateMonthabb(((ed.get(Calendar.MONTH))+1))+" "+ed.get(Calendar.DAY_OF_MONTH)+", "+ed.get(Calendar.YEAR);

            }else {

                startDATE = generateDaysabb(sd.get(Calendar.DAY_OF_WEEK))+", " + generateMonthabb(((sd.get(Calendar.MONTH))+1))+" "+sd.get(Calendar.DAY_OF_MONTH)+", "+sd.get(Calendar.YEAR);
                endDATE = generateDaysabb(ed.get(Calendar.DAY_OF_WEEK))+", " + generateMonthabb(((ed.get(Calendar.MONTH))+1))+" "+ed.get(Calendar.DAY_OF_MONTH)+", "+ed.get(Calendar.YEAR);
            }

            date = startDATE +" - "+endDATE;

        }else {
            startDATE = generateDaysabb(sd.get(Calendar.DAY_OF_WEEK))+", " + generateMonthabb(((sd.get(Calendar.MONTH))+1))+" "+sd.get(Calendar.DAY_OF_MONTH)+", "+sd.get(Calendar.YEAR);
            date = startDATE;

        }

        return date;

    }

    public String generateTime(String startTime,String endTime){

        String time;
        Calendar st = Calendar.getInstance();
        Long starttime = Long.parseLong(startTime);
        st.setTimeInMillis(starttime);
        int hourOFDAY = st.get(Calendar.HOUR_OF_DAY);
        int minuteofhour = st.get(Calendar.MINUTE);
        String amPM,status;

        if (hourOFDAY > 12) {
            hourOFDAY -= 12;
            amPM = "PM";

        } else if (hourOFDAY == 0) {
            hourOFDAY += 12;
            amPM = "AM";
        } else if (hourOFDAY == 12)
            amPM = "PM";
        else
            amPM = "AM";

        String stimes;
        if (minuteofhour <= 9) {

            if (minuteofhour == 0){

                stimes  =  hourOFDAY  + " " + amPM;
            }else {
                stimes = hourOFDAY + ": 0" + minuteofhour + " " + amPM;}
        } else{
            stimes =  hourOFDAY + ":" + minuteofhour + " " + amPM;}


        Calendar et = Calendar.getInstance();
        Long endtime = Long.parseLong(endTime);
        et.setTimeInMillis(endtime);
        int hour = et.get(Calendar.HOUR_OF_DAY);
        int minute = et.get(Calendar.MINUTE);

        if (hour > 12) {
            hour -= 12;
            status = "PM";

        } else if (hour == 0) {
            hour += 12;
            status = "AM";
        } else if (hour == 12)
            status = "PM";
        else
            status = "AM";

        String etimes;
        if (minute <= 9) {

            if (minute == 0){

                etimes  =  hour  + " " + status;
            }else {
                etimes = hour + ": 0" + minute + " " + status;}
        } else{
            etimes =  hour + ":" + minute + " " + status;}


        time = stimes + " - "+etimes;

        return time;
    }

    public String generateDaysabb(int day){
        String days;
        if (day == 7){
            return   days = "Sat";
        }else if (day == 1)
            return   days = "Sun";
        else if (day == 2)
            return days = "Mon";
        else if(day == 3)
            return days = "Tue";
        else if (day == 4)
            return days = "wed";
        else if(day == 5)
            return days = "Thu";
        else if(day == 6)
            return days = "Fri";
        else
            return  days = "";


    }
    public String generateMonthabb(int month){
        String monthName;

        if(month == 1){
            return monthName = "Jan";
        }else if (month == 2){
            return monthName = "Feb";
        }else if (month == 3){
            return monthName = "Mar";
        }else if (month == 4){
            return monthName = "Apr";
        }else if (month == 5){
            return monthName = "May";
        }else if (month == 6){
            return monthName = "Jun";
        }else if (month == 7){
            return monthName = "Jul";
        }else if (month == 8){
            return monthName = "Aug";
        }else if (month == 9){
            return monthName = "Sep";
        }else if (month == 10){
            return monthName = "Oct";
        }else if (month == 11){
            return monthName = "Nov";
        }else if (month == 12){
            return monthName = "Dec";

        }else {
            return null;
        }

    }

    private  void  isSaved(final String postid, final ImageView imageView){

        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Saves")
                .child(firebaseUser.getUid());
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.child(postid).exists()){
                    imageView.setImageResource(R.drawable.ic_favorites);
                    imageView.setTag("saved");
                }else {
                    imageView.setImageResource(R.drawable.ic_favorite_border_black_24dp);
                    imageView.setTag("save");
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });




    }
        public Date getDate(String startDates, String startTimes){
            Long startDate = Long.parseLong(startDates);
            Long startTime = Long.parseLong(startTimes);
            Calendar t = Calendar.getInstance();
            t.setTimeInMillis(startTime);
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(startDate);
            calendar.set(Calendar.HOUR_OF_DAY, t.get(Calendar.HOUR_OF_DAY));
            calendar.set(Calendar.MINUTE, t.get(Calendar.MINUTE));
            calendar.set(Calendar.MILLISECOND, t.get(Calendar.MILLISECOND));
            calendar.set(Calendar.SECOND, t.get(Calendar.SECOND));
            Date eventStartDate = calendar.getTime();
            return eventStartDate;
        }
    private void isconfirmed(String id,final CircleImageView circleImageView) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Confirmed").child(id);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    circleImageView.setVisibility(View.VISIBLE);
                } else {
                    circleImageView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void showMenu(View v) {
        PopupMenu popup = new PopupMenu(getContext(),v, Gravity.RIGHT);
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
            if (menuItem.getTitle().equals("Report")){
                SharedPreferences.Editor editor = getContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE).edit();
                editor.putString("postid", postid);
                editor.putString("publisher",publisherid);
                editor.apply();
                ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new FragmentReport()).addToBackStack(null).commit();
            }
                return false;
            }
        });// to implement on click event on items of menu
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.popup_menu, popup.getMenu());
        popup.show();
    }

}
