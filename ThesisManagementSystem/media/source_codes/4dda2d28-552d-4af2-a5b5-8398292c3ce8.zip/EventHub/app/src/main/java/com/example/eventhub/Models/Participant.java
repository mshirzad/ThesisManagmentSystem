package com.example.eventhub.Models;

public class Participant {
    String imageurl;
    String firstname;
    String lastname;
    String email;
    String userid;
    String number;

    public Participant(String imageurl, String firstname, String lastname, String email,String userid,String number) {
        this.imageurl = imageurl;
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.userid = userid;
        this.number = number;
    }

    public Participant() {
    }

    public String getImageurl() {
        return imageurl;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
