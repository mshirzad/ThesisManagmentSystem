package com.example.eventhub.Adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.eventhub.Fragments.OrganizerProfileFragment;
import com.example.eventhub.Fragments.ProfileFragment;
import com.example.eventhub.Models.Organizers;
import com.example.eventhub.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class OrganizerAdapter extends RecyclerView.Adapter<OrganizerAdapter.ViewHolder> {

    private Context mContext;
    private List<Organizers> mOrganizers;
    private String mItem;

    private FirebaseUser firebaseUser;

    public OrganizerAdapter(Context mContext, List<Organizers> mOrganizers,String mItem) {
        this.mContext = mContext;
        this.mOrganizers = mOrganizers;
        this.mItem = mItem;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (mItem.equals("user_item")) {
            view = LayoutInflater.from(mContext).inflate(R.layout.user_item, parent, false);
        }else {
            view = LayoutInflater.from(mContext).inflate(R.layout.organizers_profile_items, parent, false);
        }

        return new OrganizerAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int i) {

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        final Organizers organizer = mOrganizers.get(i);

        holder.btn_follow.setVisibility(View.VISIBLE);

        holder.username.setText(organizer.getName());
        Glide.with(mContext).load(organizer.getImageurl()).into(holder.image_profile);
        isFollowing(organizer.getUserid(), holder.btn_follow);

        if (organizer.getUserid().equals(firebaseUser.getUid())) {
            holder.btn_follow.setVisibility(View.GONE);
        }
        isconfirmed(organizer.getUserid(),holder.confirm);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = mContext.getSharedPreferences("PREFS", Context.MODE_PRIVATE).edit();
                editor.putString("profileid", organizer.getUserid());
                editor.apply();

                ((FragmentActivity) mContext).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new OrganizerProfileFragment()).addToBackStack(null).commit();
            }
        });
        holder.btn_follow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (holder.btn_follow.getText().toString().equals("Follow")) {
                    FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                            .child("following").child(organizer.getUserid()).setValue(true);
                    FirebaseDatabase.getInstance().getReference().child("Follow").child(organizer.getUserid())
                            .child("followers").child(firebaseUser.getUid()).setValue(true);
                } else {
                    FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                            .child("following").child(organizer.getUserid()).removeValue();
                    FirebaseDatabase.getInstance().getReference().child("Follow").child(organizer.getUserid())
                            .child("followers").child(firebaseUser.getUid()).removeValue();

                }
            }
        });


    }

    @Override
    public int getItemCount() {
        return mOrganizers.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView username;
        public CircleImageView image_profile,confirm;
        public Button btn_follow;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            username = itemView.findViewById(R.id.username);
            image_profile = itemView.findViewById(R.id.image_profile);
            btn_follow = itemView.findViewById(R.id.btn_follow);
            confirm = itemView.findViewById(R.id.confirm);

        }
    }

    private void isFollowing(final String userid, final Button button) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                .child("Follow").child(firebaseUser.getUid()).child("following");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child(userid).exists()) {
                    button.setText("Following");
                    button.setBackgroundResource(R.drawable.button_focus);
                    ((Button)button).setTextColor(Color.parseColor("#ffffff"));

                } else {
                    button.setText("Follow");
                    button.setBackgroundResource(R.drawable.button_background_notfocus);
                    ((Button)button).setTextColor(Color.parseColor("#455cde"));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    private void isconfirmed(String id,final CircleImageView circleImageView) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Confirmed").child(id);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    circleImageView.setVisibility(View.VISIBLE);
                } else {
                   circleImageView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
}
}
