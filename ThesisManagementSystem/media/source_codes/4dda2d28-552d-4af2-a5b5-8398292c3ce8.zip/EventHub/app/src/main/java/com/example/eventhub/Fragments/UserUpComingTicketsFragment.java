package com.example.eventhub.Fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eventhub.Adapter.TicketsAdapter;
import com.example.eventhub.Models.Posts;
import com.example.eventhub.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class UserUpComingTicketsFragment extends Fragment {
    private RecyclerView recyclerView;
    private TicketsAdapter ticketsAdapter;
    private List<Posts> postLists;
    private List<String> eventUpcomingLists;
    private List<String> joinedLists;
    LinearLayout linearLayout;
    TextView textView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_upcoming_user_tickets, container, false);
        recyclerView = view.findViewById(R.id.tickets_recyclerView);
        linearLayout = view.findViewById(R.id.frm_text);
        textView = view.findViewById(R.id.txt_openHome);

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new HomeFragment()).commit();
            }
        });

        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        postLists = new ArrayList<>();
        ticketsAdapter = new TicketsAdapter(getContext(), postLists);
        recyclerView.setAdapter(ticketsAdapter);


        checkJoinedEvents();


        return view;
    }

    private void checkJoinedEvents() {
        joinedLists = new ArrayList<>();

        String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Joined").child(userid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                joinedLists.clear();
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        joinedLists.add(snapshot.getKey());
                    }
                    readPosts();

                }



            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }



    private void readPosts() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                postLists.clear();
                for (String postid : joinedLists) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        final Posts post = snapshot.getValue(Posts.class);
                        if (post.getPostid().equals(postid)){
                    Calendar currentDate = Calendar.getInstance();
                    Date current = currentDate.getTime();
                        if (current.before(getDate(post.getStartDate(),post.getStartTime()))) {
                            linearLayout.setVisibility(View.GONE);
                            postLists.add(post);
                        }


                    }
                }


                }
                ticketsAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getActivity(), "" + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
    public Date getDate(String startDates,String startTimes){
        Long startDate = Long.parseLong(startDates);
        Long startTime = Long.parseLong(startTimes);
        Calendar t = Calendar.getInstance();
        t.setTimeInMillis(startTime);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(startDate);
        calendar.set(Calendar.HOUR_OF_DAY, t.get(Calendar.HOUR_OF_DAY));
        calendar.set(Calendar.MINUTE, t.get(Calendar.MINUTE));
        calendar.set(Calendar.MILLISECOND, t.get(Calendar.MILLISECOND));
        calendar.set(Calendar.SECOND, t.get(Calendar.SECOND));
        Date eventStartDate = calendar.getTime();
        return eventStartDate;
    }

}
