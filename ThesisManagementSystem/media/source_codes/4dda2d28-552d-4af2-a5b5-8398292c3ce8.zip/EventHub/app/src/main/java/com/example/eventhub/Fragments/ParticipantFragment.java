package com.example.eventhub.Fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.eventhub.Adapter.OrganizerAdapter;
import com.example.eventhub.Adapter.UserAdapter;
import com.example.eventhub.Models.Organizers;
import com.example.eventhub.Models.Participant;
import com.example.eventhub.Models.User;
import com.example.eventhub.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class ParticipantFragment extends Fragment {
    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private List<Participant> participants;
    String postid;
    View progress_bar;
    TextView txt_back;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_participant, container, false);
        recyclerView = view.findViewById(R.id.recycler_view);
        txt_back = view.findViewById(R.id.txt_back);
        progress_bar = view.findViewById(R.id.progress);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);
        bottomNavigationView.setVisibility(View.GONE);

        participants = new ArrayList<>();
         userAdapter = new UserAdapter(getContext(), participants);
        recyclerView.setAdapter(userAdapter);

        SharedPreferences sharedPreferences = getContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE);
        postid = sharedPreferences.getString("postid", "none");

        readUsers();

        txt_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().onBackPressed();
            }
        });



        return view;
    }


    private void readUsers() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Participants").child(postid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                participants.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Participant user = snapshot.getValue(Participant.class);
                            participants.add(user);


                }
                userAdapter.notifyDataSetChanged();
                progress_bar.setVisibility(View.GONE);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    @Override
    public void onStop() {
        super.onStop();
        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);
        bottomNavigationView.setVisibility(View.VISIBLE);

    }
}
