package com.example.eventhub.Fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eventhub.R;
import com.facebook.CallbackManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import static android.content.Context.INPUT_METHOD_SERVICE;


public class FragmentReport extends Fragment {
private ImageView btn_back;
private TextView txt_report_length;
private EditText txt_report;
private Button btn_submit;
LinearLayout frm_report;
String postid,publisher;
ProgressDialog progressDialog;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_report, container, false);
        btn_back = view.findViewById(R.id.btn_back);
        txt_report_length = view.findViewById(R.id.txt_report_length);
        txt_report = view.findViewById(R.id.txt_report);
        btn_submit = view.findViewById(R.id.btn_submit);
        frm_report = view.findViewById(R.id.frm_report);
        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);
        bottomNavigationView.setVisibility(View.GONE);
        txt_report_length.setText((int) txt_report.length() + " / 700");
        SharedPreferences preferences = getContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE);
        postid = preferences.getString("postid", "none");
        publisher = preferences.getString("publisher", "none");
btn_back.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        getActivity().onBackPressed();
    }
});
txt_report.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        frm_report.setBackgroundResource(R.drawable.button_background_notfocus);
    }
});

        txt_report.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_report_length.setText((int) txt_report.length() + " / 700");
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_report_length.setText((int) txt_report.length() + " / 700");
            }

            @Override
            public void afterTextChanged(Editable editable) {
                txt_report_length.setText((int) txt_report.length() + " / 700");
            }
        });
        frm_report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_report.requestFocus();
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(INPUT_METHOD_SERVICE);
                imm.showSoftInput(txt_report, 1);
            }
        });

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String txt = txt_report.getText().toString().trim();
                if (!txt.isEmpty()) {
                    upload();
                }else {
                    frm_report.setBackgroundResource(R.drawable.text_input_layout_error);
                }
            }
        });

        return view;
    }

    @Override
    public void onStop() {
        super.onStop();
        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);

        bottomNavigationView.setVisibility(View.VISIBLE);

    }
   public void upload(){
       progressDialog = new ProgressDialog(getContext(), android.R.style.Theme_DeviceDefault_Light_Dialog);
       progressDialog.setMessage("Uploading...");
       //prevent from progress dialog canelation on touch outside
       progressDialog.setCanceledOnTouchOutside(false);
       String date = String.valueOf(Calendar.getInstance().getTimeInMillis());
       DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Reports");
       Map<String, Object> hashMap = new HashMap<>();
       hashMap.put("report", txt_report.getText().toString().trim());
       hashMap.put("publisher", publisher);
       hashMap.put("postid", postid);
       hashMap.put("date", date);
       hashMap.put("userid", FirebaseAuth.getInstance().getCurrentUser().getUid());

       reference.push().setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
           @Override
           public void onComplete(@NonNull Task<Void> task) {
               if (task.isSuccessful()) {
                   progressDialog.dismiss();
                   ((FragmentActivity) getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new HomeFragment()).commit();
               }
           }
       }).addOnFailureListener(new OnFailureListener() {
           @Override
           public void onFailure(@NonNull Exception e) {
               Toast.makeText(getContext(), "failed", Toast.LENGTH_SHORT).show();
           }
       });
    }

}
