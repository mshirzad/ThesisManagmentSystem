package com.example.eventhub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class NotVerifiedUsersMessage extends AppCompatActivity {
    ImageView img;
    RadioButton rd1, rd2, rd3, rd4;
    Button btn_back, btn_skip, btn_next;
    int counter = 1;
    TextView txt_send_verification;
    View decorView;
    Float x1, x2;
    int min_distance = 150;
    Animation animation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_not_verified_users_message);
        btn_back = findViewById(R.id.btn_back);
        btn_skip = findViewById(R.id.btn_skip);
        btn_next = findViewById(R.id.btn_next);
        rd4 = findViewById(R.id.rd4);
        rd3 = findViewById(R.id.rd3);
        rd2 = findViewById(R.id.rd2);
        rd1 = findViewById(R.id.rd1);
        img = findViewById(R.id.img);
        txt_send_verification = findViewById(R.id.txt_send_verification);
        img.setImageResource(R.drawable.confirmation2);
        animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fadein);


        txt_send_verification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final ProgressDialog pd = new ProgressDialog(NotVerifiedUsersMessage.this, android.R.style.Theme_DeviceDefault_Light_Dialog);
                pd.setMessage("Sending...");
                pd.setCanceledOnTouchOutside(false);
                pd.show();
                FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            pd.dismiss();
                            Toast.makeText(NotVerifiedUsersMessage.this, "Email successfully sent!", Toast.LENGTH_SHORT).show();
                        } else {
                            pd.dismiss();
                            Toast.makeText(NotVerifiedUsersMessage.this, "Could'nt send verification email!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });


        rd1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                img.setImageResource(R.drawable.confirmation2);
                txt_send_verification.setVisibility(View.VISIBLE);
                img.startAnimation(animation);
                btn_back.setVisibility(View.GONE);
                counter = 1;
            }
        });
        rd2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                img.setImageResource(R.drawable.cantposts);
                counter = 2;
                txt_send_verification.setVisibility(View.GONE);
                img.startAnimation(animation);
                btn_back.setVisibility(View.VISIBLE);
            }
        });
        rd3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                img.setImageResource(R.drawable.cmorganizers);
                counter = 3;
                txt_send_verification.setVisibility(View.GONE);
                img.startAnimation(animation);
                btn_back.setVisibility(View.VISIBLE);
            }
        });
        rd4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                img.setImageResource(R.drawable.cmpost);
                counter = 4;
                txt_send_verification.setVisibility(View.GONE);
                img.startAnimation(animation);
                btn_back.setVisibility(View.VISIBLE);
            }
        });
        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (counter <= 3) {
                    counter++;
                    switch (counter) {
                        case 1:
                            rd1.setChecked(true);
                            img.setImageResource(R.drawable.confirmation2);
                            txt_send_verification.setVisibility(View.VISIBLE);
                            img.startAnimation(animation);
                            break;
                        case 2:
                            btn_back.setVisibility(View.VISIBLE);
                            rd2.setChecked(true);
                            img.setImageResource(R.drawable.cantposts);
                            txt_send_verification.setVisibility(View.GONE);
                            img.startAnimation(animation);
                            break;
                        case 3:
                            btn_back.setVisibility(View.VISIBLE);
                            rd3.setChecked(true);
                            img.setImageResource(R.drawable.cmorganizers);
                            txt_send_verification.setVisibility(View.GONE);
                            img.startAnimation(animation);
                            break;
                        case 4:
                            btn_back.setVisibility(View.VISIBLE);
                            rd4.setChecked(true);
                            img.setImageResource(R.drawable.cmpost);
                            txt_send_verification.setVisibility(View.GONE);
                            img.startAnimation(animation);
                            break;
                    }
                }
            }
        });
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (counter <= 4 && counter > 1) {
                    counter--;
                    switch (counter) {
                        case 1:
                            btn_back.setVisibility(View.GONE);
                            rd1.setChecked(true);
                            img.setImageResource(R.drawable.confirmation2);
                            txt_send_verification.setVisibility(View.VISIBLE);
                            img.startAnimation(animation);
                            break;
                        case 2:
                            rd2.setChecked(true);
                            img.setImageResource(R.drawable.cantposts);
                            txt_send_verification.setVisibility(View.GONE);
                            img.startAnimation(animation);
                            break;
                        case 3:
                            rd3.setChecked(true);
                            img.setImageResource(R.drawable.cmorganizers);
                            img.startAnimation(animation);
                            txt_send_verification.setVisibility(View.GONE);
                            break;
                        case 4:
                            rd4.setChecked(true);
                            img.setImageResource(R.drawable.cmpost);
                            img.startAnimation(animation);
                            txt_send_verification.setVisibility(View.GONE);
                            break;
                    }
                }
            }
        });
        btn_skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });

        //show Status bar on swipe
        decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int Visibility) {
                if (Visibility == 0)
                    decorView.setSystemUiVisibility(hideSystermBars());

            }
        });


    }

    //hide status bar on focus
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            decorView.setSystemUiVisibility(hideSystermBars());
        }
    }

    // UI elements to hide and show
    private int hideSystermBars() {
        return View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                x1 = event.getX();
                break;
            case MotionEvent.ACTION_UP:
                x2 = event.getX();
                float deltaX = x2 - x1;
                if (Math.abs(deltaX) > min_distance) {
                    if (x1 > x2) {
                        if (counter <= 3) {
                            counter++;
                            switch (counter) {
                                case 1:
                                    rd1.setChecked(true);
                                    img.setImageResource(R.drawable.confirmation2);
                                    img.startAnimation(animation);

                                    txt_send_verification.setVisibility(View.VISIBLE);
                                    break;
                                case 2:
                                    btn_back.setVisibility(View.VISIBLE);
                                    rd2.setChecked(true);
                                    img.setImageResource(R.drawable.cantposts);
                                    txt_send_verification.setVisibility(View.GONE);
                                    img.startAnimation(animation);
                                    break;
                                case 3:
                                    btn_back.setVisibility(View.VISIBLE);
                                    rd3.setChecked(true);
                                    img.setImageResource(R.drawable.cmorganizers);
                                    txt_send_verification.setVisibility(View.GONE);
                                    img.startAnimation(animation);
                                    break;
                                case 4:
                                    btn_back.setVisibility(View.VISIBLE);
                                    rd4.setChecked(true);
                                    img.setImageResource(R.drawable.cmpost);
                                    img.startAnimation(animation);
                                    txt_send_verification.setVisibility(View.GONE);
                                    break;
                            }
                        }
                    } else {
                        if (counter <= 4 && counter > 1) {
                            counter--;
                            switch (counter) {
                                case 1:
                                    btn_back.setVisibility(View.GONE);
                                    rd1.setChecked(true);
                                    img.startAnimation(animation);
                                    img.setImageResource(R.drawable.confirmation2);
                                    txt_send_verification.setVisibility(View.VISIBLE);
                                    break;
                                case 2:
                                    rd2.setChecked(true);
                                    img.setImageResource(R.drawable.cantposts);
                                    img.startAnimation(animation);

                                    txt_send_verification.setVisibility(View.GONE);
                                    break;
                                case 3:
                                    rd3.setChecked(true);
                                    img.setImageResource(R.drawable.cmorganizers);
                                    img.startAnimation(animation);

                                    txt_send_verification.setVisibility(View.GONE);
                                    break;
                                case 4:
                                    rd4.setChecked(true);
                                    img.setImageResource(R.drawable.cmpost);
                                    img.startAnimation(animation);
                                    txt_send_verification.setVisibility(View.GONE);
                                    break;
                            }
                        }
                    }
                }
                break;
        }
        return super.onTouchEvent(event);
    }
}