package com.example.eventhub.Models;

public class Organizers {
    private String userid;
    private  String name;
    private String description;
    private String imageurl;

    public Organizers() {
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public Organizers(String userid, String name, String description, String imageurl) {
        this.userid = userid;
        this.name = name;
        this.description = description;
        this.imageurl = imageurl;
    }
}
