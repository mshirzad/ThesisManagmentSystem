package com.example.eventhub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.eventhub.Models.Posts;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ManagePostsActivity extends AppCompatActivity {

    TextView startDateView,txt_title,txt_venueLocation,close,d_title;
    Button btn_publish,btn_delete;
    ShimmerFrameLayout shimmer_container;
    LinearLayout layout;
    Spinner spinner;
    ImageView post_image;
    View decorView;
    Map<String, String> map;
    Boolean isUpdate = true;
    ArrayList<String> arrayList,publishedList,participants;
    String postid ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_unpublished_posts);
        spinner = findViewById(R.id.spinner);
        startDateView = findViewById(R.id.startDateView);
        txt_title = findViewById(R.id.txt_title);
        txt_venueLocation = findViewById(R.id.txt_venueLocation);
        btn_publish = findViewById(R.id.btn_publish);
        btn_delete = findViewById(R.id.btn_delete);
        post_image = findViewById(R.id.post_image);
        close = findViewById(R.id.close);

        shimmer_container = findViewById(R.id.shimmer_container);
        layout = findViewById(R.id.layout);
        d_title = findViewById(R.id.d_title);
        map = new HashMap<String, String>();
        d_title.setText("Manage Your Posts");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        btn_publish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (postid != null) {
                    Intent intent = new Intent(ManagePostsActivity.this, EditPostsActivity.class);
                    intent.putExtra("postid", postid);
                    startActivity(intent);
                }
            }
        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String postidd = postid;

                final AlertDialog.Builder b = new AlertDialog.Builder(ManagePostsActivity.this, R.style.dialogTheme);
                b.setMessage("Are sure you want to delete  "+spinner.getSelectedItem()+" event?");

                b.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(final DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        final ProgressDialog progressDialog = new ProgressDialog(ManagePostsActivity.this,android.R.style.Theme_DeviceDefault_Light_Dialog);
                        progressDialog.setMessage("Please Wait...");
                        progressDialog.setCanceledOnTouchOutside(false);
                        progressDialog.show();
                        isUpdate = false;
                        FirebaseDatabase.getInstance().getReference("posts").child(postid).child("publisher").setValue("").addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                FirebaseDatabase.getInstance().getReference("Tickets").child(postid).child("publisher").setValue("").addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        FirebaseDatabase.getInstance().getReference().child("Participants").child(postid).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                for (final String ids : participants){
                                                    //add notifications
                                                        String date = String.valueOf(Calendar.getInstance().getTimeInMillis());
                                                        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Notifications").child(ids);
                                                        final String notificationid = reference.push().getKey();
                                                        HashMap<String, Object> hashMap = new HashMap<>();
                                                        hashMap.put("userid",ids);
                                                        hashMap.put("notificationid",notificationid);
                                                        hashMap.put("text","The event you joined has been canceled.");
                                                        hashMap.put("postid",postidd);
                                                        hashMap.put("ispost", true);
                                                        hashMap.put("date",date);
                                                        reference.child(notificationid).setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task) {
                                                            FirebaseDatabase.getInstance().getReference().child("Joined").child(ids).child(postidd).removeValue();
                                                            onBackPressed();
                                                        }
                                                    });

                                                }
                                                progressDialog.dismiss();
                                            }
                                        });


                                    }
                                });

                            }
                        });

                    }
                });
                b.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                b.show();

            }
        });


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (!adapterView.getSelectedItem().equals("Select Your Event Title")){
                    for (Map.Entry<String, String> entry: map.entrySet()){
                        if (entry.getValue().equals(adapterView.getSelectedItem())){
                            shimmer_container.setVisibility(View.VISIBLE);
                            layout.setVisibility(View.VISIBLE);
                            mypublishedPosts(entry.getKey());
                            postid = entry.getKey();
                            btn_publish.setClickable(true);
                            btn_publish.setTextColor(getResources().getColor(R.color.colorPrimary));
                            btn_delete.setTextColor(getResources().getColor(R.color.colorPrimary));
                        }

                    }
                }else {
                    btn_publish.setTextColor(getResources().getColor(R.color.colorAccent));
                    btn_delete.setTextColor(getResources().getColor(R.color.colorAccent));
                    btn_publish.setClickable(false);
                    layout.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        if (isUpdate){
        checkPublishedPosts();
        }


//show Status bar on swipe
        decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int Visibility) {
                if(Visibility == 0)
                    decorView.setSystemUiVisibility(hideSystermBars());

            }
        });


    }

    //hide status bar on focus
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus){
            decorView.setSystemUiVisibility(hideSystermBars());
        }
    }
    // UI elements to hide and show
    private int hideSystermBars(){
        return View.SYSTEM_UI_FLAG_FULLSCREEN
                |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

    }
    //get posts that have been published and has ticket
    private void checkPublishedPosts() {
        if (isUpdate) {
            publishedList = new ArrayList<>();
            final FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Tickets");
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    publishedList.clear();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        publishedList.add(snapshot.getKey());

                    }

                    readPosts();

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }


    private void readPosts() {
        if (isUpdate) {
            final String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts");
            reference.keepSynced(true);
            map.clear();
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        final Posts post = snapshot.getValue(Posts.class);
                        for (String postid : publishedList) {
                            if (!post.getPublisher().isEmpty()) {
                                if (post.getPostid().equals(postid) && post.getPublisher().equals(userid)) {
                                    if (!post.getState().equals("Confirmed")) {
                                        map.put(post.getPostid(), post.getTitle());
                                    }
                                }
                            }
                        }
                    }
                    map.put("0", "Select Your Event Title");
                    arrayList = new ArrayList<>();
                    Iterator<Map.Entry<String, String>> itr = map.entrySet().iterator();
                    while (itr.hasNext()) {
                        arrayList.add(itr.next().getValue());
                    }
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(ManagePostsActivity.this, android.R.layout.simple_spinner_item, arrayList);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinner.setAdapter(adapter);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(ManagePostsActivity.this, "" + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

    }

    private void mypublishedPosts(final String id) {
        if (isUpdate) {
            participants = new ArrayList<>();
            participants.clear();
            final FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Participants").child(id);
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        participants.add(snapshot.getKey());
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts").child(id);
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Posts posts = dataSnapshot.getValue(Posts.class);
                    if (posts.getState().equals("Changeable And Possible to Cancel")) {
                        btn_delete.setText("Cancel");
                        btn_publish.setText("Edit");
                    } else if (posts.getState().equals("Possible to Change")) {
                        btn_delete.setText("Cancel");
                        btn_delete.setTextColor(getResources().getColor(R.color.colorPrimary));
                        btn_publish.setText("Edit");
                        btn_delete.setClickable(false);

                    }

                    Calendar currentDate = Calendar.getInstance();
                    Date current = currentDate.getTime();
                    if (current.before(getDate(posts.getStartDate(), posts.getStartTime()))) {
                        txt_title.setText(posts.getTitle());
                        txt_venueLocation.setText(posts.getVenue());
                        Calendar t = Calendar.getInstance();
                        Long starttime = Long.parseLong(posts.getStartTime());
                        t.setTimeInMillis(starttime);
                        int hourOFDAY = t.get(Calendar.HOUR_OF_DAY);
                        int minuteofhour = t.get(Calendar.MINUTE);
                        String amPM;

                        if (hourOFDAY > 12) {
                            hourOFDAY -= 12;
                            amPM = "PM";

                        } else if (hourOFDAY == 0) {
                            hourOFDAY += 12;
                            amPM = "AM";
                        } else if (hourOFDAY == 12)
                            amPM = "PM";
                        else
                            amPM = "AM";

                        String times;
                        if (minuteofhour <= 9) {

                            if (minuteofhour == 0) {

                                times = hourOFDAY + " " + amPM;
                            } else {
                                times = hourOFDAY + ": 0" + minuteofhour + " " + amPM;
                            }
                        } else {
                            times = hourOFDAY + ":" + minuteofhour + " " + amPM;
                        }


                        Calendar d = Calendar.getInstance();
                        d.setTimeInMillis(Long.parseLong(posts.getStartDate()));

                        final String startDate = generateDaysabb(d.get(Calendar.DAY_OF_WEEK)) + ", " + generateMonthabb(((d.get(Calendar.MONTH)) + 1)) + " " + d.get(Calendar.DAY_OF_MONTH) + " at " + times;
                        startDateView.setText(startDate);
                        if (getApplication() != null) {
                            Glide.with(getApplication()).load(posts.getPostimage()).into(post_image);


                        }
                        shimmer_container.setVisibility(View.GONE);
                        layout.setVisibility(View.VISIBLE);
                    }
                }


                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }
    }
    public String generateDaysabb(int day) {
        String days;
        if (day == 7) {
            return days = "Sat";
        } else if (day == 1)
            return days = "Sun";
        else if (day == 2)
            return days = "Mon";
        else if (day == 3)
            return days = "Tue";
        else if (day == 4)
            return days = "wed";
        else if (day == 5)
            return days = "Thu";
        else if (day == 6)
            return days = "Fri";
        else
            return days = "";


    }

    public String generateMonthabb(int month) {
        String monthName;

        if (month == 1) {
            return monthName = "Jan";
        } else if (month == 2) {
            return monthName = "Feb";
        } else if (month == 3) {
            return monthName = "Mar";
        } else if (month == 4) {
            return monthName = "Apr";
        } else if (month == 5) {
            return monthName = "May";
        } else if (month == 6) {
            return monthName = "Jun";
        } else if (month == 7) {
            return monthName = "Jul";
        } else if (month == 8) {
            return monthName = "Aug";
        } else if (month == 9) {
            return monthName = "Sep";
        } else if (month == 10) {
            return monthName = "Oct";
        } else if (month == 11) {
            return monthName = "Nov";
        } else if (month == 12) {
            return monthName = "Dec";

        } else {
            return null;
        }
    }
    public Date getDate(String startDates, String startTimes){
        Long startDate = Long.parseLong(startDates);
        Long startTime = Long.parseLong(startTimes);
        Calendar t = Calendar.getInstance();
        t.setTimeInMillis(startTime);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(startDate);
        calendar.set(Calendar.HOUR_OF_DAY, t.get(Calendar.HOUR_OF_DAY));
        calendar.set(Calendar.MINUTE, t.get(Calendar.MINUTE));
        calendar.set(Calendar.MILLISECOND, t.get(Calendar.MILLISECOND));
        calendar.set(Calendar.SECOND, t.get(Calendar.SECOND));
        Date eventStartDate = calendar.getTime();
        return eventStartDate;
    }
}
