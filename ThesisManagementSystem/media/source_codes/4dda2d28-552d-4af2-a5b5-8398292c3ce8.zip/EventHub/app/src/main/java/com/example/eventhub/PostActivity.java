package com.example.eventhub;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.BitmapCompat;


import android.accessibilityservice.GestureDescription;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.FileObserver;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageActivity;
import com.theartofdev.edmodo.cropper.CropImageOptions;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import id.zelory.compressor.Compressor;

public class PostActivity extends AppCompatActivity {

    Uri imageUri,mCropUri;
    String myUri = "";
    StorageReference storageReference;

    ImageView close, image_added;
    TextView post,  endDate, startTime, endTime,startDate,txt;
    EditText description,txt_venue,title;
    StorageTask uploadTask;
    Calendar c,m,d;
    View decorView;
    Spinner spinner_status;
    long minDate,maxDate;
    int DAY,Dayofmonth,MONTH,YEAR,HOUR,MINUTE;
    String str_startDate,str_endDate,str_startTime,str_endTime;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        close = findViewById(R.id.close);
        image_added = findViewById(R.id.image_added);
        post = findViewById(R.id.btnPost);
        description = findViewById(R.id.description);
        title = findViewById(R.id.eventTitle);
        startTime = (TextView) findViewById(R.id.txt_startTime);
        endTime = (TextView) findViewById(R.id.txt_endTime);
        startDate = (TextView) findViewById(R.id.txt_startDate);
        endDate = (TextView) findViewById(R.id.txt_endDate);
        txt_venue = (EditText) findViewById(R.id.txt_Venue);
        txt =  findViewById(R.id.txt);

        // set values for category spinner
        final Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.category,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.getOnItemClickListener();

        //set values and adapter for event status spinner
        spinner_status = (Spinner) findViewById(R.id.spinner_status);
        ArrayAdapter<CharSequence> adapter_status = ArrayAdapter.createFromResource(this,R.array.event_state,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_status.setAdapter(adapter_status);
        spinner_status.getOnItemClickListener();



        //create a reference to storage in firebase
        storageReference = FirebaseStorage.getInstance().getReference("Posts");

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PostActivity.this, MainActivity.class));
                finish();
            }
        });




        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadImage();
            }
        });

        image_added.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt.setVisibility(View.GONE);
                image_added.setBackgroundResource(R.drawable.button_background_notfocus);

                CropImage.activity()
                        .setAllowRotation(true)
                        .setOutputCompressQuality(55)
                        .setAutoZoomEnabled(true)
                        .setCropShape(CropImageView.CropShape.RECTANGLE)
                        .setAspectRatio(2,1)
                        .setMinCropResultSize(1200,600)
                        .start(PostActivity.this);

            }
        });
//show Status bar on swipe
        decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int Visibility) {
                if(Visibility == 0)
                    decorView.setSystemUiVisibility(hideSystermBars());

            }
        });


    }

    //hide status bar on focus
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus){
            decorView.setSystemUiVisibility(hideSystermBars());
        }
    }
    // UI elements to hide and show
    private int hideSystermBars(){
        return View.SYSTEM_UI_FLAG_FULLSCREEN
                |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

    }
    // hiding keyboard on clicking outside editText
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (getCurrentFocus()!=null){
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);


        }

        return super.dispatchTouchEvent(ev);
    }





    private  String getFileExtention(Context context,Uri uri){
        String extension = "";
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {

            MimeTypeMap mime = MimeTypeMap.getSingleton();
            extension = mime.getExtensionFromMimeType(context.getContentResolver().getType(uri));
        }else {
            extension =  MimeTypeMap.getFileExtensionFromUrl(String.valueOf(Uri.fromFile(new File(uri.getPath().toString()))));
        }
        return extension;
    }

    private void uploadImage(){
        final ProgressDialog progressDialog = new ProgressDialog(this,android.R.style.Theme_DeviceDefault_Light_Dialog);
        progressDialog.setMessage("Posting...");
        //prevent from progress dialog canelation on touch outside
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();


        if (imageUri != null){
            final StorageReference filerefrence = storageReference.child(System.currentTimeMillis()
            + "." + getFileExtention(this , imageUri));
            final String str_desc  = description.getText().toString().trim();
            final String txt_startDate  = startDate.getText().toString().trim();
            final String txt_startTime  = startTime.getText().toString().trim();
            final String txt_endTime  = endTime.getText().toString().trim();
            final String str_venue  = txt_venue.getText().toString().trim();
            final String str_title = title.getText().toString().trim();
            Spinner spinner = findViewById(R.id.spinner);

            final  String category = spinner.getSelectedItem().toString().trim();
            final String event_state = spinner_status.getSelectedItem().toString().trim();

            String cate = "Category";
            String state = "Event State";
            if ( TextUtils.isEmpty(str_desc) || TextUtils.isEmpty(txt_startDate)  || TextUtils.isEmpty(txt_startTime)|| TextUtils.isEmpty(txt_endTime)|| TextUtils.isEmpty(str_venue) || event_state.equals(state)) {

                progressDialog.dismiss();
                Toast.makeText(PostActivity.this, "All fields are requred!", Toast.LENGTH_SHORT).show();
            }else {
                if (category.equals(cate)){
                    progressDialog.dismiss();
                    Toast.makeText(this, "Please select your event category!", Toast.LENGTH_SHORT).show();

                }else{
                uploadTask = filerefrence.putFile(imageUri);
            uploadTask.continueWithTask(new Continuation() {
                @Override
                public Object then(@NonNull Task task) throws Exception {
                    if(!task.isComplete()){
                        throw task.getException();
                    }
                    return filerefrence.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()) {
                        Long postDate = System.currentTimeMillis();
                        String postDateTime = String.valueOf(postDate);






                            Uri downloadUri = task.getResult();
                            myUri = downloadUri.toString();

                            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts");
                            final String postid = reference.push().getKey();

                            HashMap<String, Object> hashMap = new HashMap<>();
                            hashMap.put("postid", postid);
                            hashMap.put("postimage", myUri);
                            hashMap.put("postDateTime", postDateTime);
                            hashMap.put("startDate", str_startDate);
                            hashMap.put("endDate", str_endDate);
                            hashMap.put("startTime", str_startTime);
                            hashMap.put("endTime", str_endTime);
                            hashMap.put("title", str_title);
                        hashMap.put("venue", str_venue);
                        hashMap.put("description", str_desc);
                        hashMap.put("publisher", FirebaseAuth.getInstance().getCurrentUser().getUid());
                        hashMap.put("category", category);
                        hashMap.put("state", event_state);

                        reference.child(postid).setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                FirebaseDatabase.getInstance().getReference("Unpublished").child(postid).setValue(true);
                                progressDialog.dismiss();
                                Intent intent = new Intent(PostActivity.this, CreateTicketActivity.class);
                                intent.putExtra("postid", postid);
                                startActivity(intent);
                                finish();
                            }
                        });




                    } else {
                        Toast.makeText(PostActivity.this, "Failed!", Toast.LENGTH_SHORT).show();
                    }
                }

            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(PostActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }}}else {
            progressDialog.dismiss();
            Toast.makeText(this, "No image selected!", Toast.LENGTH_SHORT).show();
        }


    }


//get the result of photo crop
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            File file = new File(result.getUri().getPath());
            Long len = file.length()/1024;
            if (len < 5){
                txt.setVisibility(View.VISIBLE);
                txt.setText("Please select an image with good quality!");
                image_added.setImageURI(null);
                imageUri = null;
                image_added.setBackgroundResource(R.drawable.input_errot);
            }else if (len > 850){ txt.setVisibility(View.VISIBLE);
                txt.setText("Image is too large!");
                image_added.setImageURI(null);
                imageUri = null;
                image_added.setBackgroundResource(R.drawable.input_errot);

            }else {
                imageUri = result.getUri();
                image_added.setImageURI(imageUri);
            }
        }else if (imageUri != null) {
            image_added.setImageURI(imageUri);

        }else {

            //after closing the crop activity start this activity
            startActivity(new Intent(PostActivity.this, PostActivity.class));
            finish();
        }

}



    // Date picker for end date and start date
    public void openSelectedDate(View view){
           c = Calendar.getInstance();
           m = Calendar.getInstance();
           d= Calendar.getInstance();

        Dayofmonth = c.get(Calendar.DAY_OF_MONTH);
     MONTH = c.get(Calendar.MONTH);
       YEAR = c.get(Calendar.YEAR);
        if (view.getId() == R.id.txt_startDate){

            final DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
                @RequiresApi(api = Build.VERSION_CODES.O)
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayofmonth) {
                    int mo = monthOfYear + 1;


                    //change calendar date to the first datepicker date
                    m.set(Calendar.DAY_OF_MONTH, dayofmonth);
                    m.set(Calendar.YEAR, year);
                    m.set(Calendar.MONTH, monthOfYear);
                    str_startDate = String.valueOf(m.getTimeInMillis());
                    str_endDate = "";
                    m.add(Calendar.DAY_OF_MONTH,1);
                    minDate = m.getTimeInMillis();
                    startDate.setText(dayofmonth + " " + generateMonthabb(mo) + "," + year);
                    endDate.setText(null);


                    m.add(Calendar.YEAR,1);
                    m.add(Calendar.MONTH,6);
                    maxDate = m.getTimeInMillis();





                }

            };
            DatePickerDialog datePickerDialog = new DatePickerDialog(this, R.style.dialogTheme, listener, YEAR, MONTH, Dayofmonth);
            datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
            c.add(Calendar.YEAR,1);
            c.add(Calendar.MONTH,6);
            datePickerDialog.getDatePicker().setMaxDate(c.getTimeInMillis());
            datePickerDialog.show();




        }else if (view.getId() == R.id.txt_endDate){
             String d =   startDate.getText().toString();
            if (startDate.getText().toString().length() > 0) {

                DatePickerDialog.OnDateSetListener listener2 = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                        m.set(Calendar.MONTH,monthOfYear);
                        m.set(Calendar.YEAR, year);
                        m.set(Calendar.DAY_OF_MONTH, dayOfMonth);


                        str_endDate = String.valueOf(m.getTimeInMillis());



                        endDate.setText(dayOfMonth  +" "+ generateMonthabb((monthOfYear + 1)) + "," + year);



                    }
                };
                DatePickerDialog datePickerDialogenddate = new DatePickerDialog(this, R.style.dialogTheme, listener2, YEAR, MONTH, DAY);
                datePickerDialogenddate.getDatePicker().setMinDate(minDate - 1000);
                datePickerDialogenddate.getDatePicker().setMaxDate(maxDate);
                datePickerDialogenddate.show();


            }else  {
                    Toast.makeText(this, "You must select the starting date first!", Toast.LENGTH_SHORT).show();
                }

        }else {
            Toast.makeText(this, "nothing", Toast.LENGTH_SHORT).show();
        }


    }





        //Time picker method
        public void openSelectTime(View view) {
            Calendar d = Calendar.getInstance();
            final int HOURS = d.get(Calendar.HOUR_OF_DAY);
            final int MINUTES = d.get(Calendar.MINUTE);

            switch (view.getId()) {
                case R.id.txt_startTime:
                    TimePickerDialog.OnTimeSetListener listener = new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                            endTime.setText(null);

                            Calendar b = Calendar.getInstance();
                            b.set(Calendar.HOUR_OF_DAY,hourOfDay);
                            b.set(Calendar.MINUTE,minute);
                            Long l = b.getTimeInMillis();
                            str_startTime = String.valueOf(l);

                            HOUR = hourOfDay;
                            MINUTE = minute;

                            String status = "";
                            if (hourOfDay > 12) {
                                hourOfDay -= 12;
                                status = "PM";

                            } else if (hourOfDay == 0) {
                                hourOfDay += 12;
                                status = "AM";
                            } else if (hourOfDay == 12)
                                status = "PM";
                            else
                                status = "AM";
                            if (minute <= 9) {
                                if (minute == 0){

                                    startTime.setText(hourOfDay + " " + status);
                                }else {
                                startTime.setText(hourOfDay + ": 0" + minute + " " + status);}
                            } else{
                                startTime.setText( hourOfDay + ":" + minute + " " + status);}
                        }
                    };
                    TimePickerDialog timePickerDialog = new TimePickerDialog(this,R.style.dialogTheme ,listener, HOURS, MINUTES, false);
                    timePickerDialog.updateTime(HOURS,MINUTES);
                    timePickerDialog.show();
                    break;


                case R.id.txt_endTime:
                    if (startTime.getText().toString().length() > 0){
                    TimePickerDialog.OnTimeSetListener listener2 = new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                            Calendar b = Calendar.getInstance();
                            b.set(Calendar.HOUR_OF_DAY,hourOfDay);
                            b.set(Calendar.MINUTE,minute);
                            Long l = b.getTimeInMillis();
                            str_endTime = String.valueOf(l);

                            String status = "";
                            if (hourOfDay > 12) {
                                hourOfDay -= 12;
                                status = "PM";

                            } else if (hourOfDay == 0) {
                                hourOfDay += 12;
                                status = "AM";
                            } else if (hourOfDay == 12)
                                status = "PM";
                            else
                                status = "AM";
                            if (minute <= 9) {
                                if (minute == 0) {

                                    endTime.setText(hourOfDay + " " + status);
                                } else {
                                    endTime.setText(hourOfDay + ": 0" + minute + " " + status);
                                }
                            }else{
                                endTime.setText( hourOfDay + ":" + minute + " " + status);}
                        }
                    };
                    TimePickerDialog timePickerDialog2 = new TimePickerDialog(this,R.style.dialogTheme, listener2, HOURS, MINUTES, false);
                    timePickerDialog2.updateTime(HOUR,MINUTE);
                    timePickerDialog2.show();
                    break;}else {
                        Toast.makeText(this, "You must select the starting time first!", Toast.LENGTH_SHORT).show();

                    }
                    }}



                    // get the day of week integers and return string day name
//                    public String generateDays(int day){
//          String days;
//        if (day == 7){
//                          return   days = "Saturday";
//                        }else if (day == 1)
//                          return   days = "Sunday";
//                        else if (day == 2)
//                           return days = "Monday";
//                        else if(day == 3)
//                           return days = "Tuesday";
//                        else if (day == 4)
//                           return days = "wednesday";
//                        else if(day == 5)
//                           return days = "Thursday";
//                        else if(day == 6)
//                           return days = "Friday";
//                        else
//                            return  days = "";
//
//
//                    }
//                    public String generateMonth(int month){
//                    String monthName;
//
//                    if(month == 1){
//                       return monthName = "January";
//                    }else if (month == 2){
//                        return monthName = "February";
//                    }else if (month == 3){
//                        return monthName = "March";
//                    }else if (month == 4){
//                        return monthName = "April";
//                    }else if (month == 5){
//                        return monthName = "May";
//                    }else if (month == 6){
//                        return monthName = "June";
//                    }else if (month == 7){
//                        return monthName = "July";
//                    }else if (month == 8){
//                        return monthName = "August";
//                    }else if (month == 9){
//                        return monthName = "September";
//                    }else if (month == 10){
//                        return monthName = "October";
//                    }else if (month == 11){
//                        return monthName = "November";
//                    }else if (month == 12){
//                        return monthName = "December";
//
//                    }else {
//                        return null;
//                    }
//
//                    }
//    public String generateDaysabb(int day){
//        String days;
//        if (day == 7){
//            return   days = "Sat";
//        }else if (day == 1)
//            return   days = "Sun";
//        else if (day == 2)
//            return days = "Mon";
//        else if(day == 3)
//            return days = "Tue";
//        else if (day == 4)
//            return days = "wed";
//        else if(day == 5)
//            return days = "Thu";
//        else if(day == 6)
//            return days = "Fri";
//        else
//            return  days = "";
//
//
//    }
    public String generateMonthabb(int month){
        String monthName;

        if(month == 1){
            return monthName = "Jan";
        }else if (month == 2){
            return monthName = "Feb";
        }else if (month == 3){
            return monthName = "Mar";
        }else if (month == 4){
            return monthName = "Apr";
        }else if (month == 5){
            return monthName = "May";
        }else if (month == 6){
            return monthName = "Jun";
        }else if (month == 7){
            return monthName = "Jul";
        }else if (month == 8){
            return monthName = "Aug";
        }else if (month == 9){
            return monthName = "Sep";
        }else if (month == 10){
            return monthName = "Oct";
        }else if (month == 11){
            return monthName = "Nov";
        }else if (month == 12){
            return monthName = "Dec";

        }else {
            return null;
        }

    }

        }











