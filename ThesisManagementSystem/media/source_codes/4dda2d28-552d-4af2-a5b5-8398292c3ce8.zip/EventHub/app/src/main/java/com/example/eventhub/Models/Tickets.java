package com.example.eventhub.Models;

public class Tickets {
    private String description;
    private String name;
    private String price;
    private String endDate;
    private String startDate;
    private String publisher;
    private String quantity;
    private String refundpolicy;

    public String getRefundpolicy() {
        return refundpolicy;
    }

    public void setRefundpolicy(String refundpolicy) {
        this.refundpolicy = refundpolicy;
    }

    public Tickets(String refundpolicy) {
        this.refundpolicy = refundpolicy;
    }

    public Tickets(String description, String name, String price, String endDate, String startDate, String publisher, String quantity, String refundpolicy) {
        this.description = description;
        this.name = name;
        this.price = price;
        this.endDate = endDate;
        this.startDate = startDate;
        this.publisher = publisher;
        this.quantity = quantity;
        this.refundpolicy = refundpolicy;
    }

    public Tickets() {
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
}

