package com.example.eventhub.Adapter;

import android.app.Dialog;
import android.app.VoiceInteractor;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.eventhub.Fragments.PostDetailsFragment;
import com.example.eventhub.Fragments.ProfileFragment;
import com.example.eventhub.Models.Organizers;
import com.example.eventhub.Models.Posts;
import com.example.eventhub.Models.Tickets;
import com.example.eventhub.Models.User;

import com.example.eventhub.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.List;

public class TicketsAdapter extends RecyclerView.Adapter<TicketsAdapter.ViewHolder> {
    public Context mContext;
    public List<Posts> mPosts;


    private FirebaseUser firebaseUser;
    private Object ViewGroup;

    public TicketsAdapter(Context mContext, List<Posts> mPosts) {
        this.mContext = mContext;
        this.mPosts = mPosts;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.tickets_item, parent, false);
        return new TicketsAdapter.ViewHolder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int i) {
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        final Posts posts = mPosts.get(i);


        final Long startDate = Long.parseLong(posts.getStartDate());
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(startDate);
        Long startTime = Long.parseLong(posts.getStartTime());
        Calendar t = Calendar.getInstance();
        t.setTimeInMillis(startTime);
        final int dayofweek = c.get(Calendar.DAY_OF_WEEK);
        final int dayofmonth = c.get(Calendar.DAY_OF_MONTH);
        final int month = c.get(Calendar.MONTH);
        final int year = c.get(Calendar.YEAR);

        int hourOFDAY = t.get(Calendar.HOUR_OF_DAY);
        int minuteofhour = t.get(Calendar.MINUTE);
        String amPM;

        if (hourOFDAY > 12) {
            hourOFDAY -= 12;
            amPM = "PM";

        } else if (hourOFDAY == 0) {
            hourOFDAY += 12;
            amPM = "AM";
        } else if (hourOFDAY == 12)
            amPM = "PM";
        else
            amPM = "AM";

        final String times;
        if (minuteofhour <= 9) {

            if (minuteofhour == 0){

                times  =  hourOFDAY  + " " + amPM;
            }else {
                times = hourOFDAY + ": 0" + minuteofhour + " " + amPM;}
        } else{
            times =  hourOFDAY + ":" + minuteofhour + " " + amPM;}

        RequestOptions requestOptions = new RequestOptions();
        requestOptions.centerCrop();


        holder.frm_ticket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final TextView txt_description,txt_organizer_name,txt_username,txt_ticketType,txt_venue,txt_startDate,btn_back,txt_title;
                final Dialog dialog;

                dialog = new Dialog(mContext, R.style.AppTheme_FullScreen);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.user_tickets_item_details);
                Window window = dialog.getWindow();
                window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
                txt_description = (TextView) dialog.findViewById(R.id.txt_description);
                txt_organizer_name = (TextView) dialog.findViewById(R.id.txt_organizer_name);
                 btn_back = dialog.findViewById(R.id.btn_back);
                txt_venue = (TextView) dialog.findViewById(R.id.txt_venue);
                txt_startDate = (TextView) dialog.findViewById(R.id.txt_Date);
                txt_username = (TextView) dialog.findViewById(R.id.txt_username);
                txt_ticketType = (TextView) dialog.findViewById(R.id.txt_ticket_type);
                txt_title = dialog.findViewById(R.id.txt_title);

                txt_startDate.setText(generateDaysabb(dayofweek)+", "+generateMonthabb((month+1))+" "+dayofmonth+" "+year+" at "+times );
               txt_description.setText(posts.getDescription());
               txt_venue.setText(posts.getVenue());
               txt_title.setText(posts.getTitle());




               DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Organizers").child(posts.getPublisher());
               databaseReference.addValueEventListener(new ValueEventListener() {
                   @Override
                   public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                       Organizers organizers = dataSnapshot.getValue(Organizers.class);
                       txt_organizer_name.setText(organizers.getName());
                   }

                   @Override
                   public void onCancelled(@NonNull DatabaseError databaseError) {

                   }
               });
                DatabaseReference databaseReference1 = FirebaseDatabase.getInstance().getReference("Users").child(firebaseUser.getUid());
                databaseReference1.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        User user = dataSnapshot.getValue(User.class);
                        txt_username.setText(user.getFirstname()+" "+user.getLastname());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                DatabaseReference databaseReference2 = FirebaseDatabase.getInstance().getReference("Tickets").child(posts.getPostid());
                databaseReference2.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Tickets tickets = dataSnapshot.getValue(Tickets.class);
                        txt_ticketType.setText(tickets.getName());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                dialog.show();
                btn_back.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
        });

holder.postDate.setText(generateDaysabb(dayofweek)+", "+generateMonthabb((month+1))+" "+dayofmonth+" "+year+" at "+times );
        Glide.with(mContext).load(posts.getPostimage()).apply(requestOptions).into(holder.post_image);
        holder.title.setText(posts.getTitle());










    }

    @Override
    public int getItemCount() {
        return mPosts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView  post_image;
        public TextView  postDate, title,txt_title;
        public LinearLayout frm_ticket;
        public Dialog dialog;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            post_image = itemView.findViewById(R.id.event_image);
            title = itemView.findViewById(R.id.txt_title);
            postDate = itemView.findViewById(R.id.txt_startDate);
            frm_ticket = itemView.findViewById(R.id.frm_ticket);


        }

    }

    public String generateDaysabb(int day) {
        String days;
        if (day == 7) {
            return days = "Sat";
        } else if (day == 1)
            return days = "Sun";
        else if (day == 2)
            return days = "Mon";
        else if (day == 3)
            return days = "Tue";
        else if (day == 4)
            return days = "wed";
        else if (day == 5)
            return days = "Thu";
        else if (day == 6)
            return days = "Fri";
        else
            return days = "";


    }

    public String generateMonthabb(int month) {
        String monthName;

        if (month == 1) {
            return monthName = "Jan";
        } else if (month == 2) {
            return monthName = "Feb";
        } else if (month == 3) {
            return monthName = "Mar";
        } else if (month == 4) {
            return monthName = "Apr";
        } else if (month == 5) {
            return monthName = "May";
        } else if (month == 6) {
            return monthName = "Jun";
        } else if (month == 7) {
            return monthName = "Jul";
        } else if (month == 8) {
            return monthName = "Aug";
        } else if (month == 9) {
            return monthName = "Sep";
        } else if (month == 10) {
            return monthName = "Oct";
        } else if (month == 11) {
            return monthName = "Nov";
        } else if (month == 12) {
            return monthName = "Dec";

        } else {
            return null;
        }
    }



}
