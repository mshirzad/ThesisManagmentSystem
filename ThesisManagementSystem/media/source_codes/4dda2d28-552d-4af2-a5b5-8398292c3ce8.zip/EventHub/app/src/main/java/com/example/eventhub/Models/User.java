package com.example.eventhub.Models;

public class User {
    private String id;
    private  String firstname;
    private String lastname;
    private String imageurl;
    private String bio;
    private String number;

    public User(String id, String firstname, String lastname, String imageurl, String bio, String number) {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.imageurl = imageurl;
        this.bio = bio;
        this.number = number;
    }

    public User() {

    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }
}
