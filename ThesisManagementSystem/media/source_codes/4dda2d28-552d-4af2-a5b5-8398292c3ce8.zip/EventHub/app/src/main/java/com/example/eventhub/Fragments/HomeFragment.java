package com.example.eventhub.Fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eventhub.Adapter.OrganizerAdapter;
import com.example.eventhub.CreateOrganizerActivity;
import com.example.eventhub.CreateTicketActivity;
import com.example.eventhub.Models.Notifications;
import com.example.eventhub.Models.Organizers;
import com.example.eventhub.Models.Posts;
import com.example.eventhub.Adapter.PostAdapter;
import com.example.eventhub.OptionsActivity;
import com.example.eventhub.PostActivity;
import com.example.eventhub.R;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class HomeFragment extends Fragment {

    private RecyclerView recycler_view_FollowingPosts, recyclerView1, recycler_view_editorPicks, recyclerview_businessAndProfessional;
    private PostAdapter postAdapter_editor_picks, postAdapter_Following,postAdapter_businessAndProfessional;
    private List<Posts> postLists_editorPicks, postsLists_businessAndProfessional, followingPostLists;
    private ImageView add_action;
    int count = 8, count_PostsFromFollowing = 8, count_AllPostsFromFollowing,count_businessAndProfessionalPosts = 8,count_AllbusinessAPPosts;
    private List<String> followinglist, publishedlist;
    private List<Organizers> organizersLists;
    private OrganizerAdapter organizerAdapter;
    ArrayList<String> notifications;
    LinearLayout frm_editorPicks, frm_organizersView, frm_followingPosts,frm_businessAndProfessional,layout;
    TextView txt_seeMore_FollowingPosts, txt_seeMore_editorPicks, txt_seeMore_businessAndProfessional;
    ShimmerFrameLayout shimmer_container;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        recycler_view_FollowingPosts = view.findViewById(R.id.recycler_view_FollowingPosts);
        recyclerView1 = view.findViewById(R.id.recycler_view1);
        recycler_view_editorPicks = view.findViewById(R.id.recycler_view_editorPicks);
        add_action = view.findViewById(R.id.add_action);
        txt_seeMore_FollowingPosts = view.findViewById(R.id.txt_seeMore_FollowingPosts);
        frm_followingPosts = view.findViewById(R.id.frm_followingPosts);
        frm_organizersView = view.findViewById(R.id.frm_organizersView);
        layout = view.findViewById(R.id.layout);
        frm_editorPicks = view.findViewById(R.id.frm_editorPicks);
        frm_businessAndProfessional = view.findViewById(R.id.frm_businessAndProfessional);
        txt_seeMore_businessAndProfessional = view.findViewById(R.id.txt_seeMore_businessAndProfessional);
        recyclerview_businessAndProfessional = view.findViewById(R.id.recyclerview_businessAndProfessional);
        txt_seeMore_editorPicks = view.findViewById(R.id.txt_seeMore_editorPicks);
        shimmer_container = view.findViewById(R.id.shimmer_container);
        //enable firebase offline capabilities
//        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        if (!FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()){
            add_action.setVisibility(View.GONE);
        }
       shimmer_container.startShimmer();

        //add item on button click into following recycler view
        txt_seeMore_FollowingPosts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (count_PostsFromFollowing + 1 <= count_AllPostsFromFollowing) {
                    count_PostsFromFollowing = count_PostsFromFollowing + 8;
                    checkPostsFromFollowing();
                }
            }
        });
        // add items on button click into posts recycler view
        txt_seeMore_editorPicks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (count + 1 <= publishedlist.size()) {
                    count = count + 8;
                    checkPublishedPosts();
                }
            }
        });
        // add items on button click into business and professional  recycler view
        txt_seeMore_businessAndProfessional.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (count_businessAndProfessionalPosts + 1 <= count_AllbusinessAPPosts) {
                    count_businessAndProfessionalPosts = count_businessAndProfessionalPosts + 8;
                    readBusinessAndProfessionaEvents();
                }
            }
        });


        add_action.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Organizers").child(userid);

                reference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        if (dataSnapshot.exists()) {
                            startActivity(new Intent(getActivity(), PostActivity.class));
                        } else {
                            startActivity(new Intent(getActivity(), CreateOrganizerActivity.class));

                        }


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        getActivity().onBackPressed();
                        Toast.makeText(getActivity(), "failed", Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });


        // recycler view of posts
        recycler_view_FollowingPosts.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        recycler_view_FollowingPosts.setLayoutManager(linearLayoutManager);
        followingPostLists = new ArrayList<>();
        postAdapter_Following = new PostAdapter(getContext(), followingPostLists);
        recycler_view_FollowingPosts.setAdapter(postAdapter_Following);

        //recycler view of who to follow
        LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(getContext(), RecyclerView.HORIZONTAL, false);
        recyclerView1.setLayoutManager(linearLayoutManager1);
        organizersLists = new ArrayList<>();
        organizerAdapter = new OrganizerAdapter(getContext(), organizersLists, "organizer_item");
        recyclerView1.setAdapter(organizerAdapter);

        //recycler view of posts from people you follow
        recycler_view_editorPicks.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager_editorPicks = new LinearLayoutManager(getContext());
        linearLayoutManager_editorPicks.setReverseLayout(true);
        linearLayoutManager_editorPicks.setStackFromEnd(true);
        recycler_view_editorPicks.setLayoutManager(linearLayoutManager_editorPicks);
        postLists_editorPicks = new ArrayList<>();
        postAdapter_editor_picks = new PostAdapter(getContext(), postLists_editorPicks);
        recycler_view_editorPicks.setAdapter(postAdapter_editor_picks);

        //recycler view of posts with business and professional category
        recyclerview_businessAndProfessional.setHasFixedSize(true);
        LinearLayoutManager lM_businessAndProfessional = new LinearLayoutManager(getContext());
        lM_businessAndProfessional.setReverseLayout(true);
        lM_businessAndProfessional.setStackFromEnd(true);
        recyclerview_businessAndProfessional.setLayoutManager(lM_businessAndProfessional);
        postsLists_businessAndProfessional = new ArrayList<>();
        postAdapter_businessAndProfessional = new PostAdapter(getContext(), postsLists_businessAndProfessional);
        recyclerview_businessAndProfessional.setAdapter(postAdapter_businessAndProfessional);


        //list of methods
        checkPublishedPosts();
        checkPostsFromFollowing();
        readOrganizers();
        readBusinessAndProfessionaEvents();


        return view;


    }

    //    get the current user following people id
    private void checkPostsFromFollowing() {
        followinglist = new ArrayList<>();
       String user = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Follow").child(user).child("following");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                followinglist.clear();
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        followinglist.add(snapshot.getKey());
                    }
                }

                readPostsFromFollowing();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void readPostsFromFollowing() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                followingPostLists.clear();
                count_AllPostsFromFollowing = 0;
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    final Posts post = snapshot.getValue(Posts.class);
                    for (String postid : publishedlist) {
                        for (String id : followinglist) {
                            if (post.getPublisher().equals(id) && post.getPostid().equals(postid)) {
                                count_AllPostsFromFollowing++;
                                Calendar currentDate = Calendar.getInstance();
                                Date current = currentDate.getTime();
                                if (current.before(getDate(post.getStartDate(),post.getStartTime()))) {
                                    if (followingPostLists.size() < count_PostsFromFollowing) {
                                        followingPostLists.add(post);
                                        if (frm_followingPosts.getVisibility() == View.GONE) {
                                            frm_followingPosts.setVisibility(View.VISIBLE);
                                        }
                                    }

                                }
                            }
                        }

                    }


                }
                postAdapter_Following.notifyDataSetChanged();
                if (followingPostLists.size() == 0) {
                    frm_followingPosts.setVisibility(View.GONE);
                }
                shimmer_container.stopShimmer();
                shimmer_container.setVisibility(View.GONE);
                layout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getActivity(), "" + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    //get organizers
    private void readOrganizers() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Organizers");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                postLists_editorPicks.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    final Organizers organizers = snapshot.getValue(Organizers.class);
                    if (snapshot.exists()) {
                        if (!organizers.getUserid().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {

                            if (postLists_editorPicks.size() < count) {
                                organizersLists.add(organizers);
                                if (frm_organizersView.getVisibility() == View.GONE)
                                    frm_organizersView.setVisibility(View.VISIBLE);

                            }
                        }
                    }


                }
                organizerAdapter.notifyDataSetChanged();
                if (organizersLists.size() == 0) {
                    frm_organizersView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getActivity(), "" + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }


    //get posts that have been published and has ticket
    private void checkPublishedPosts() {
        publishedlist = new ArrayList<>();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Tickets");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                publishedlist.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    publishedlist.add(snapshot.getKey());
                }

                readPosts();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


    private void readPosts() {
        final String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                postLists_editorPicks.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    final Posts post = snapshot.getValue(Posts.class);
                    if (!post.getPublisher().isEmpty()){
                    for (String postid : publishedlist) {
                        if (post.getPostid().equals(postid)) {
                                Calendar currentDate = Calendar.getInstance();
                                Date current = currentDate.getTime();
                                if (current.before(getDate(post.getStartDate(),post.getStartTime()))) {
                                    if (postLists_editorPicks.size() < count) {
                                    postLists_editorPicks.add(post);
                                    if (frm_editorPicks.getVisibility() == View.GONE)
                                        frm_editorPicks.setVisibility(View.VISIBLE);
                                }

                            }
                        }
                    }


                }
                }
                postAdapter_editor_picks.notifyDataSetChanged();
                if (postLists_editorPicks.size() == 0) {
                    frm_editorPicks.setVisibility(View.GONE);
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getActivity(), "" + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void readBusinessAndProfessionaEvents(){
        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        final String userid = firebaseUser.getUid();
        String c = "Business and Professional";
        Query query = FirebaseDatabase.getInstance().getReference("posts").orderByChild("category")
                .startAt(c)
                .endAt(c + "\uf0ff");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                postsLists_businessAndProfessional.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Posts post = snapshot.getValue(Posts.class);
                    if (!post.getPublisher().isEmpty()){
                    count_AllbusinessAPPosts++;
                    for (String id : publishedlist){
                        if (id != null && id.equals(post.getPostid())){
                                    Calendar currentDate = Calendar.getInstance();
                                    Date current = currentDate.getTime();
                                    if (current.before(getDate(post.getStartDate(),post.getStartTime()))) {
                                        if (postsLists_businessAndProfessional.size() < count_businessAndProfessionalPosts) {
                                        postsLists_businessAndProfessional.add(post);
                                        if (frm_businessAndProfessional.getVisibility() == View.GONE)
                                            frm_businessAndProfessional.setVisibility(View.VISIBLE);
                                    }
                        }
                        }
                    }

                }
                }
                postAdapter_businessAndProfessional.notifyDataSetChanged();
                if (postsLists_businessAndProfessional.size() == 0) {
                    frm_businessAndProfessional.setVisibility(View.GONE);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public Date getDate(String startDates, String startTimes){
        Long startDate = Long.parseLong(startDates);
        Long startTime = Long.parseLong(startTimes);
        Calendar t = Calendar.getInstance();
        t.setTimeInMillis(startTime);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(startDate);
        calendar.set(Calendar.HOUR_OF_DAY, t.get(Calendar.HOUR_OF_DAY));
        calendar.set(Calendar.MINUTE, t.get(Calendar.MINUTE));
        calendar.set(Calendar.MILLISECOND, t.get(Calendar.MILLISECOND));
        calendar.set(Calendar.SECOND, t.get(Calendar.SECOND));
        Date eventStartDate = calendar.getTime();
        return eventStartDate;
    }


}