package com.example.eventhub.Adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.example.eventhub.Fragments.PostDetailsFragment;
import com.example.eventhub.Fragments.ProfileFragment;
import com.example.eventhub.Models.Organizers;
import com.example.eventhub.Models.Posts;
import com.example.eventhub.Models.Tickets;
import com.example.eventhub.Models.User;
import com.example.eventhub.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class PostsSearchAdapter extends RecyclerView.Adapter<PostsSearchAdapter.ViewHolder> {

    private Context mContext;
    private List<Posts> mPost;

    private FirebaseUser firebaseUser;

    public PostsSearchAdapter(Context mContext, List<Posts> mPost) {
        this.mContext = mContext;
        this.mPost = mPost;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.post_item_small, parent, false);

        return new PostsSearchAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final PostsSearchAdapter.ViewHolder holder, int i) {
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        final Posts post = mPost.get(i);
        Glide.with(mContext).load(post.getPostimage()).transition(DrawableTransitionOptions.withCrossFade()).listener(new RequestListener<Drawable>() {
            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                holder.progress_bar.setVisibility(View.GONE);
                return false;
            }
        }).into(holder.post_image);





        Calendar t = Calendar.getInstance();
        Long starttime = Long.parseLong(post.getStartTime());
        t.setTimeInMillis(starttime);
        int hourOFDAY = t.get(Calendar.HOUR_OF_DAY);
        int minuteofhour = t.get(Calendar.MINUTE);
        String amPM;

        if (hourOFDAY > 12) {
            hourOFDAY -= 12;
            amPM = "PM";

        } else if (hourOFDAY == 0) {
            hourOFDAY += 12;
            amPM = "AM";
        } else if (hourOFDAY == 12)
            amPM = "PM";
        else
            amPM = "AM";

        String times;
        if (minuteofhour <= 9) {

            if (minuteofhour == 0){

                times  =  hourOFDAY  + " " + amPM;
            }else {
                times = hourOFDAY + ": 0" + minuteofhour + " " + amPM;}
        } else{
            times =  hourOFDAY + ":" + minuteofhour + " " + amPM;}


        Calendar d = Calendar.getInstance();
        d.setTimeInMillis(Long.parseLong(post.getStartDate()));

        String startDate = generateDaysabb(d.get(Calendar.DAY_OF_WEEK))+", "+generateMonthabb(((d.get(Calendar.MONTH))+1))+" "+d.get(Calendar.DAY_OF_MONTH)+" at "+times;

        holder.eventDate.setText(startDate);
        holder.venue.setText(post.getVenue());
        holder.title.setText(post.getTitle());


        isSaved(post.getPostid(), holder.favorites);
        holder.favorites.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (holder.favorites.getTag().equals("save")){
                    FirebaseDatabase.getInstance().getReference().child("Saves")
                            .child(firebaseUser.getUid()).child(post.getPostid()).setValue(true);
                }else {
                    FirebaseDatabase.getInstance().getReference().child("Saves")
                            .child(firebaseUser.getUid()).child(post.getPostid()).removeValue();
                }


            }
        });



        holder.post_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = mContext.getSharedPreferences("PREFS", Context.MODE_PRIVATE).edit();
                editor.putString("postid", post.getPostid());
                editor.apply();
                SharedPreferences.Editor edit = mContext.getSharedPreferences("PREF", Context.MODE_PRIVATE).edit();
                edit.putString("category", post.getCategory());
                edit.apply();
                ((FragmentActivity) mContext).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new PostDetailsFragment(), "post_details_fragment").addToBackStack(null).commit();

            }

        });
        holder.venue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = mContext.getSharedPreferences("PREFS", Context.MODE_PRIVATE).edit();
                editor.putString("postid", post.getPostid());
                editor.apply();
                SharedPreferences.Editor edit = mContext.getSharedPreferences("PREF", Context.MODE_PRIVATE).edit();
                edit.putString("category", post.getCategory());
                edit.apply();
                ((FragmentActivity) mContext).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new PostDetailsFragment(), "post_details_fragment").addToBackStack(null).commit();

            }

        });
        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = mContext.getSharedPreferences("PREFS", Context.MODE_PRIVATE).edit();
                editor.putString("postid", post.getPostid());
                editor.apply();
                SharedPreferences.Editor edit = mContext.getSharedPreferences("PREF", Context.MODE_PRIVATE).edit();
                edit.putString("category", post.getCategory());
                edit.apply();
                ((FragmentActivity) mContext).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new PostDetailsFragment(), "post_details_fragment").addToBackStack(null).commit();

            }

        });
        holder.eventDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = mContext.getSharedPreferences("PREFS", Context.MODE_PRIVATE).edit();
                editor.putString("postid", post.getPostid());
                editor.apply();
                SharedPreferences.Editor edit = mContext.getSharedPreferences("PREF", Context.MODE_PRIVATE).edit();
                edit.putString("category", post.getCategory());
                edit.apply();
                ((FragmentActivity) mContext).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new PostDetailsFragment(), "post_details_fragment").addToBackStack(null).commit();

            }

        });


    }


    @Override
    public int getItemCount() {
        return mPost.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView image_profile, post_image, favorites, share, menue;
        public TextView username, postDate, eventDate, title, venue, publisher;
        public FrameLayout share_icon, ic_favorites;
        ProgressBar progress_bar;
        public LinearLayout layout;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            post_image = itemView.findViewById(R.id.post_image);
            layout = itemView.findViewById(R.id.post_item);

            title = itemView.findViewById(R.id.txt_title);
            eventDate = itemView.findViewById(R.id.startDateView);
            venue = itemView.findViewById(R.id.txt_venueLocation);
            favorites = itemView.findViewById(R.id.img_favorite);
            progress_bar = itemView.findViewById(R.id.progress_bar);


        }

    }

    public String generateDaysabb(int day) {
        String days;
        if (day == 7) {
            return days = "Sat";
        } else if (day == 1)
            return days = "Sun";
        else if (day == 2)
            return days = "Mon";
        else if (day == 3)
            return days = "Tue";
        else if (day == 4)
            return days = "wed";
        else if (day == 5)
            return days = "Thu";
        else if (day == 6)
            return days = "Fri";
        else
            return days = "";


    }

    public String generateMonthabb(int month) {
        String monthName;

        if (month == 1) {
            return monthName = "Jan";
        } else if (month == 2) {
            return monthName = "Feb";
        } else if (month == 3) {
            return monthName = "Mar";
        } else if (month == 4) {
            return monthName = "Apr";
        } else if (month == 5) {
            return monthName = "May";
        } else if (month == 6) {
            return monthName = "Jun";
        } else if (month == 7) {
            return monthName = "Jul";
        } else if (month == 8) {
            return monthName = "Aug";
        } else if (month == 9) {
            return monthName = "Sep";
        } else if (month == 10) {
            return monthName = "Oct";
        } else if (month == 11) {
            return monthName = "Nov";
        } else if (month == 12) {
            return monthName = "Dec";

        } else {
            return null;
        }
    }
    private  void  isSaved(final String postid, final ImageView imageView){

        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Saves")
                .child(firebaseUser.getUid());
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.child(postid).exists()){
                    imageView.setImageResource(R.drawable.ic_favorites);
                    imageView.setTag("saved");
                }else {
                    imageView.setImageResource(R.drawable.ic_favorite_border_black_24dp);
                    imageView.setTag("save");
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });




    }



}
