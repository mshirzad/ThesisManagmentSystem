package com.example.eventhub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.drawable.DrawableCompat;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.LoginFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class LoginActivity extends AppCompatActivity {

    TextInputEditText email, password;
    TextInputLayout email_inputLayout, password_inputLayout;
    Button login;
    TextView txt_link_signup,txt_forgot_password;

    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        login = findViewById(R.id.login);
        email_inputLayout = findViewById(R.id.email_inputLayout);
        txt_link_signup = findViewById(R.id.txt_link_register);
        txt_forgot_password = findViewById(R.id.txt_forgot_password);
        password_inputLayout = findViewById(R.id.password_inputLayout);
        auth = FirebaseAuth.getInstance();
        txt_forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this,ForgotPasswordActivity.class));
            }
        });

        onFocusChange(email, email_inputLayout, "Email");
        onFocusChange(password, password_inputLayout, "Password");


        txt_link_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final ProgressDialog pd = new ProgressDialog(LoginActivity.this, android.R.style.Theme_DeviceDefault_Light_Dialog);
                pd.setMessage("Please Wait...");
                //prevent from progress dialog canelation on touch outside
                pd.setCanceledOnTouchOutside(false);

                String str_email = email.getText().toString().trim();
                String str_password = password.getText().toString();

                if (TextUtils.isEmpty(str_email) || str_password.contains(" ") || TextUtils.isEmpty(str_password) || !Patterns.EMAIL_ADDRESS.matcher(str_email).matches() || str_password.length() < 8) {
                    checkValidation();
                } else {
                    pd.show();
                    auth.signInWithEmailAndPassword(str_email, str_password)
                            .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Users").child(auth.getCurrentUser().getUid());

                                        reference.addValueEventListener(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                pd.dismiss();
                                                if (FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()){
                                                    Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
                                                    startActivity(intent);
                                                    finish();
                                                }else {
                                                    Intent intent = new Intent(getApplicationContext(),NotVerifiedUsersMessage.class);
                                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
                                                    startActivity(intent);
                                                    finish();
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                                pd.dismiss();
                                            }
                                        });
                                    } else {
                                        pd.dismiss();
                                        Toast.makeText(LoginActivity.this, "Authentication failed,Wrong Email or Password!", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                }
            }
        });

    }

    // hiding keyboard on clicking outside editText
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (getCurrentFocus() != null) {

            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);

        }

        return super.dispatchTouchEvent(ev);
    }

    private void onFocusChange(final TextInputEditText textInputEditText, final TextInputLayout textInputLayout, final String hint) {
        textInputEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (b) {
                    textInputEditText.setBackgroundResource(R.drawable.text_input_layout_drawable);
                    textInputLayout.setErrorEnabled(false);
                    if (textInputEditText.getText().length() == 0) {
                        textInputLayout.setHint(hint + " *");
                        textInputLayout.setHintTextAppearance(R.style.error);
                    } else {
                        textInputLayout.setHint(hint);
                        if (hint.equals("Email")) {
                            if (!Patterns.EMAIL_ADDRESS.matcher(textInputEditText.getText().toString().trim()).matches()) {
                                textInputLayout.setErrorEnabled(false);
                                textInputLayout.setHintTextAppearance(R.style.error);
                                textInputLayout.setHint(hint + " *");
                            }
                        }
                    }
                } else {
                    textInputLayout.setHint(hint);
                    if (textInputEditText.getText().length() > 0) {
                        textInputLayout.setErrorEnabled(false);
                    }
                }
            }
        });
        textInputEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                textInputEditText.setBackgroundResource(R.drawable.text_input_layout_drawable);
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                textInputLayout.setErrorEnabled(false);
                if (textInputEditText.getText().length() >= 8 && hint.equals("Password") && !textInputEditText.getText().toString().contains(" ")) {
                    textInputLayout.setErrorEnabled(false);
                    textInputLayout.setHintTextAppearance(R.style.textLabelSuccess);
                    textInputLayout.setHint(hint);
                } else {
                    textInputLayout.setHint(hint + " *");
                    textInputLayout.setHintTextAppearance(R.style.error);
                }

                if (Patterns.EMAIL_ADDRESS.matcher(textInputEditText.getText().toString().trim()).matches() && hint.equals("Email")) {
                    textInputLayout.setHintTextAppearance(R.style.textLabelSuccess);
                    textInputLayout.setHint(hint);
                    textInputLayout.setErrorEnabled(false);
                } else if (hint.equals("Email")) {
                    textInputLayout.setHint(hint + " *");
                    textInputLayout.setHintTextAppearance(R.style.error);
                } else if (Patterns.EMAIL_ADDRESS.matcher(textInputEditText.getText().toString().trim()).matches() && textInputLayout.isErrorEnabled()) {
                    textInputLayout.setErrorEnabled(false);
                    textInputLayout.setHintTextAppearance(R.style.textLabelSuccess);
                    textInputLayout.setHint(hint);
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {


            }
        });

    }

    private void checkValidation() {
        String str_email = email.getText().toString().trim();
        String str_password = password.getText().toString();
        if (TextUtils.isEmpty(str_email)) {
            email_inputLayout.setErrorEnabled(true);
            email_inputLayout.setHint("Email *");
            email_inputLayout.setErrorTextAppearance(R.style.error);
            email_inputLayout.setError("Email Address is required!");
            email.setBackgroundResource(R.drawable.text_input_layout_error);
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(str_email).matches() && str_email.length() != 0) {
            email_inputLayout.setErrorEnabled(true);
            email_inputLayout.setHint("Email *");
            email_inputLayout.setErrorTextAppearance(R.style.error);
            email_inputLayout.setError("Not a Valid Email Address!");
            email.setBackgroundResource(R.drawable.text_input_layout_error);
        }
        if (TextUtils.isEmpty(str_password) || str_password.length() < 8 || str_password.contains(" ")) {
            password_inputLayout.setErrorEnabled(true);
            password_inputLayout.setHint("Password *");
            password_inputLayout.setErrorTextAppearance(R.style.error);
            if (str_password.length() == 0)
                password_inputLayout.setError("Password is required!");
            else if (str_password.contains(" ")) password_inputLayout.setError("Password Shouldn't Contain Space!");
                else password_inputLayout.setError("Password is less than 8 characters!");
            password.setBackgroundResource(R.drawable.text_input_layout_error);
        }
    }
}
