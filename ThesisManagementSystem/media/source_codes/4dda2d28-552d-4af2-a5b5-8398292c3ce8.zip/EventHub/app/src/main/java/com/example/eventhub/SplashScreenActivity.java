package com.example.eventhub;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.eventhub.TypeWriterLibrary.TypeWriterView;
import com.google.firebase.auth.FirebaseAuth;


public class SplashScreenActivity extends AppCompatActivity {
ImageView txt;
Animation animation;
View decorView;
TypeWriterView typeWriterView;
LinearLayout splash;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        txt = findViewById(R.id.imageView);
        splash = findViewById(R.id.splash);

        animation = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.push_up);
        txt.setAnimation(animation);

        txt.getAnimation().setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                typeWriterView = findViewById(R.id.typeWriterView);
                typeWriterView.setWithMusic(false);
                typeWriterView.animateText(" EventHub ");
                typeWriterView.setDelay(250);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });







        Thread thread = new Thread(){
            @Override
            public void run() {
                try{
                    sleep(5000);
                    if (FirebaseAuth.getInstance().getCurrentUser() != null){

                            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            finish();

                    }else {
                        Intent intent = new Intent(getApplicationContext(),StartActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                super.run();
            }
        };
        thread.start();


//show Status bar on swipe
        decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int Visibility) {
                if(Visibility == 0)
                    decorView.setSystemUiVisibility(hideSystermBars());

            }
        });



    }



    //hide status bar on focus
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus){
            decorView.setSystemUiVisibility(hideSystermBars());
        }
    }
    // UI elements to hide and show
    private int hideSystermBars(){
        return View.SYSTEM_UI_FLAG_FULLSCREEN
                |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

    }
}
