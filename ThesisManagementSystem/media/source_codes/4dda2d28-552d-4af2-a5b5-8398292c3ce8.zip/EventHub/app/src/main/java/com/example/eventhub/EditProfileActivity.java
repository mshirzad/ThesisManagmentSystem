package com.example.eventhub;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.eventhub.Models.Posts;
import com.example.eventhub.Models.User;
import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import de.hdodenhof.circleimageview.CircleImageView;

public class EditProfileActivity extends AppCompatActivity {


    Uri imageUri;
    String myUri = "";
    View decorView;
    StorageReference storageReference;
    StorageTask uploadTask;
    FirebaseAuth auth;
    boolean process = false;

    EditText txt_name, txt_last_name,txt_number;
    TextView txt_name_length, txt_last_name_length, edit_image,txt_number_lenght;
    ImageView profile_image, ic_profile,profile_image1;
    LinearLayout frm_first_name, frm_last_name,frm_first_number;
    RelativeLayout frm_profile_image;
    ImageView btn_back;
    Button btn_save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        profile_image = (CircleImageView)  findViewById(R.id.profile_image);
        profile_image1 = (CircleImageView)  findViewById(R.id.profile_image1);
        ic_profile = (CircleImageView) findViewById(R.id.ic_profile);
        txt_name = (EditText) findViewById(R.id.txt_first_name);
        txt_last_name = (EditText) findViewById(R.id.txt_last_name);
        txt_name_length = (TextView) findViewById(R.id.txt_name_length);
        frm_profile_image = (RelativeLayout) findViewById(R.id.frm_profile_image);
        frm_first_name = (LinearLayout) findViewById(R.id.frm_first_name);
        txt_last_name_length = findViewById(R.id.txt_last_name_length);
        frm_last_name = (LinearLayout) findViewById(R.id.frm_last_name);
        btn_back = (ImageView) findViewById(R.id.btn_back);
        edit_image = findViewById(R.id.btn_edit_image);
         btn_save = (Button) findViewById(R.id.btn_save);
        txt_number =  findViewById(R.id.txt_number);
        txt_number_lenght =  findViewById(R.id.txt_number_length);
        frm_first_number =  findViewById(R.id.frm_number);

        storageReference = FirebaseStorage.getInstance().getReference("profile_images");

        userInfo(profile_image,txt_name,txt_last_name,txt_number);



        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final AlertDialog.Builder b = new AlertDialog.Builder(EditProfileActivity.this, R.style.dialogTheme);
                b.setTitle("Save The Changes");
                b.setMessage("Are sure you want to save changes?");

                         b.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                             @Override
                             public void onClick(DialogInterface dialogInterface, int i) {
                                 uploadImage();
                             }
                         });
                         b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                             @Override
                             public void onClick(DialogInterface dialogInterface, int i) {

                             }
                         });
                b.show();
            }
        });

        //show Status bar on swipe
        decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int Visibility) {
                if(Visibility == 0)
                    decorView.setSystemUiVisibility(hideSystermBars());

            }
        });
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        edit_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CropImage.activity()
                        .setAspectRatio(1, 1)
                        .setMinCropResultSize(700,700)
                        .setCropShape(CropImageView.CropShape.OVAL)
                        .setAllowRotation(true)
                        .setOutputCompressQuality(38)
                        .start(EditProfileActivity.this);
                frm_profile_image.setBackgroundResource(R.drawable.circle_shape);
                edit_image.setText("Select Image");
                edit_image.setTextColor(getResources().getColor(R.color.colorPrimary));
                edit_image.setTextSize(16);
            }
        });



        txt_number_lenght.setText((int) txt_number.length() + " / 10");
        txt_number.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_number_lenght.setText((int) txt_number.length() + " / 10");

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_number_lenght.setText((int) txt_number.length() + " / 10");

            }

            @Override
            public void afterTextChanged(Editable editable) {
                txt_number_lenght.setText((int) txt_number.length() + " / 10");

            }
        });

        txt_name_length.setText((int) txt_name.length() + " / 20");
        txt_name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_name_length.setText((int) txt_name.length() + " / 20");

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_name_length.setText((int) txt_name.length() + " / 20");

            }

            @Override
            public void afterTextChanged(Editable editable) {
                txt_name_length.setText((int) txt_name.length() + " / 20");

            }
        });


        txt_last_name_length.setText((int) txt_last_name.length() + " / 20");
        txt_last_name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_last_name_length.setText((int) txt_last_name.length() + " / 20");

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_last_name_length.setText((int) txt_last_name.length() + " / 20");

            }

            @Override
            public void afterTextChanged(Editable editable) {
                txt_last_name_length.setText((int) txt_last_name.length() + " / 20");

            }
        });

// focus goes on linear layout child by clicking on it
        frm_first_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_name.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(txt_name, 1);
            }
        });
        // focus goes on linear layout child by clicking on it
        frm_last_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_last_name.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(txt_last_name, 1);
            }
        });


    }


    private  String getFileExtention(Context context, Uri uri){
           String extension = "";
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {

            MimeTypeMap mime = MimeTypeMap.getSingleton();
            extension = mime.getExtensionFromMimeType(context.getContentResolver().getType(uri));
        }else {
            extension =  MimeTypeMap.getFileExtensionFromUrl(String.valueOf(Uri.fromFile(new File(uri.getPath().toString()))));
        }
        return extension;
    }


    private void uploadImage() {
        final ProgressDialog progressDialog = new ProgressDialog(this,android.R.style.Theme_DeviceDefault_Light_Dialog);
        progressDialog.setMessage("Uploading...");
        //prevent from progress dialog canelation on touch outside
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        if (imageUri != null) {
            final StorageReference filerefrence = storageReference.child(System.currentTimeMillis()
                    + "." + getFileExtention(this,imageUri));




            final String str_name = txt_name.getText().toString().trim();
            final String str_last_name = txt_last_name.getText().toString().trim();
            final String str_number = txt_number.getText().toString().trim();
            if (str_name.isEmpty()|| str_last_name.isEmpty() || str_number.isEmpty()){
                progressDialog.dismiss();
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            }else{


                if (myUri != null && !myUri.equals(imageUri.toString()) ){
                   if (!myUri.equals("") && !myUri.equals("https://firebasestorage.googleapis.com/v0/b/eventhub-5ecec.appspot.com/o/user%20(1).png?alt=media&token=58590a57-0254-4a2a-b733-56874d051cd4")){
                    StorageReference photoref = FirebaseStorage.getInstance().getReferenceFromUrl(myUri);
                    photoref.delete();
                   }
                uploadTask = filerefrence.putFile(imageUri);
                uploadTask.continueWithTask(new Continuation() {
                    @Override
                    public Object then(@NonNull Task task) throws Exception {
                        if(!task.isComplete()){
                            throw task.getException();
                        }
                        return filerefrence.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull final Task<Uri> task) {
                    if (task.isSuccessful()) {

                        Uri downloadUri = task.getResult();
                        myUri = downloadUri.toString();
                        String userid = auth.getInstance().getCurrentUser().getUid();
                      DatabaseReference  reference = FirebaseDatabase.getInstance().getReference().child("Users").child(userid);
                        Map<String, Object> hashMap = new HashMap<>();
                        hashMap.put("lastname", str_last_name);
                        hashMap.put("firstname", str_name);
                        hashMap.put("number", str_number);
                        hashMap.put("imageurl", myUri);

                        reference.updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    process = true;
                                    finish();
                                }
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(EditProfileActivity.this, "failed", Toast.LENGTH_SHORT).show();
                            }
                        });



                    }
                }

            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(EditProfileActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }else {


                    String userid = auth.getInstance().getCurrentUser().getUid();
                DatabaseReference   reference = FirebaseDatabase.getInstance().getReference().child("Users").child(userid);
                    Map<String, Object> hashMap = new HashMap<>();
                    hashMap.put("fullname", str_last_name);
                    hashMap.put("firstname", str_name);
                    hashMap.put("number", str_number);

                    reference.updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            process = true;
                                finish();

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(EditProfileActivity.this, ""+e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });



                }



            }}else {
            progressDialog.dismiss();
            Toast.makeText(this, "image null", Toast.LENGTH_SHORT).show();
        }


    }


    //get the result of photo crop
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            File file = new File(result.getUri().getPath());
            Long len = file.length()/1024;
            if (len < 25){
                profile_image.setVisibility(View.GONE);
                profile_image1.setVisibility(View.VISIBLE);
                imageUri = null;
                frm_profile_image.setBackgroundResource(R.drawable.circle_shape_error);
                edit_image.setText("Image Has Bad Quality"+"\n     Select New One");
                edit_image.setTextColor(getResources().getColor(R.color.red));
                edit_image.setTextSize(13);

            }else if (len > 600){
                profile_image.setVisibility(View.GONE);
                profile_image1.setVisibility(View.VISIBLE);
                imageUri = null;
                frm_profile_image.setBackgroundResource(R.drawable.circle_shape_error);
                edit_image.setText("Image is too large!"+"\n  Select New One");
                edit_image.setTextColor(getResources().getColor(R.color.red));
                edit_image.setTextSize(13);
            }else {
                imageUri = result.getUri();
                if (profile_image1.getVisibility() == View.GONE){
                    profile_image.setVisibility(View.GONE);
                    profile_image1.setVisibility(View.VISIBLE);
                    profile_image1.setImageURI(result.getUri());
                }else {
                    profile_image1.setImageURI(result.getUri());
                }
            }
        }else if (imageUri != null) {
            profile_image.setImageURI(imageUri);

        }

    }


    public void userInfo(final ImageView profile_image,final EditText txt_name,final EditText txt_last_name,final EditText txt_number){

        String userid = auth.getInstance().getCurrentUser().getUid();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users").child(userid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                User user = dataSnapshot.getValue(User.class);
                if (process == false) {
                    if (!user.getImageurl().isEmpty()) {
                        Glide.with(EditProfileActivity.this).load(user.getImageurl()).into(profile_image);
                    }

                    txt_name.setText(user.getFirstname());
                    txt_last_name.setText(user.getLastname());
                    txt_number.setText(user.getNumber());

                    if (!user.getImageurl().isEmpty()) {
                        myUri = user.getImageurl();
                        Uri path = Uri.parse(myUri);
                        imageUri = path;

                    }

                }
                else {

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    //hide status bar on focus
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus){
            decorView.setSystemUiVisibility(hideSystermBars());
        }
    }
    // UI elements to hide and show
    private int hideSystermBars(){
        return View.SYSTEM_UI_FLAG_FULLSCREEN
                |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

    }
    public void hideSoftInput(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(),0);
    }
}
