package com.example.eventhub.Adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.provider.Telephony;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.eventhub.Fragments.OrganizerProfileFragment;
import com.example.eventhub.Fragments.ProfileFragment;
import com.example.eventhub.Models.Organizers;
import com.example.eventhub.Models.Participant;
import com.example.eventhub.Models.User;
import com.example.eventhub.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    private Context mContext;
    private List<Participant> mUser;

    private FirebaseUser firebaseUser;

    public UserAdapter(Context mContext, List<Participant> mUser) {
        this.mContext = mContext;
        this.mUser = mUser;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

           View view = LayoutInflater.from(mContext).inflate(R.layout.participant_item, parent, false);


        return new UserAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int i) {

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        final Participant user = mUser.get(i);


        holder.username.setText(user.getFirstname()+" "+user.getLastname());
        Glide.with(mContext).load(user.getImageurl()).into(holder.image_profile);
        holder.email.setText(user.getEmail());
        holder.phone_number.setText(user.getNumber());




    }

    @Override
    public int getItemCount() {
        return mUser.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView username,email,phone_number;
        public CircleImageView image_profile;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            username = itemView.findViewById(R.id.username);
            phone_number = itemView.findViewById(R.id.phone_number);
            image_profile = itemView.findViewById(R.id.image_profile);
            email = itemView.findViewById(R.id.email);

        }
    }


}
