package com.example.eventhub.Fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.eventhub.Adapter.OrganizerAdapter;
import com.example.eventhub.Models.Organizers;
import com.example.eventhub.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class FollowingOrganizersFragment extends Fragment {

    private RecyclerView recyclerView;
    private OrganizerAdapter organizerAdapter;
    private List<Organizers> organizers;
    List<String> followingList;
    View progress_bar;
    TextView txt_close;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_following_organizers, container, false);
        recyclerView = view.findViewById(R.id.recycler_view);
        txt_close = view.findViewById(R.id.txt_close);
        progress_bar = view.findViewById(R.id.progress_bar);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);
        bottomNavigationView.setVisibility(View.GONE);

        organizers = new ArrayList<>();
        organizerAdapter = new OrganizerAdapter(getContext(), organizers,"user_item");
        recyclerView.setAdapter(organizerAdapter);

        getUserFollowing();

        txt_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().onBackPressed();
            }
        });



        return view;
    }
    private void getUserFollowing() {
        String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        followingList = new ArrayList<>();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Follow").child(userid).child("following");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                followingList.clear();
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        followingList.add(snapshot.getKey());

                    }
                }
                readUsers();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


    private void readUsers() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Organizers");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                organizers.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Organizers organizer = snapshot.getValue(Organizers.class);
                    for (String id : followingList) {
                        if (organizer.getUserid().equals(id)) {
                            organizers.add(organizer);
                        }
                    }
                }
                organizerAdapter.notifyDataSetChanged();
                progress_bar.setVisibility(View.GONE);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    @Override
    public void onStop() {
        super.onStop();
        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);

        bottomNavigationView.setVisibility(View.VISIBLE);

    }

}
