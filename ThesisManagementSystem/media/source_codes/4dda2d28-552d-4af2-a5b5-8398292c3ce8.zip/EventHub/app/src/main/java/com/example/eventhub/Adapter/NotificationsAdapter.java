package com.example.eventhub.Adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.eventhub.Fragments.OrganizerProfileFragment;
import com.example.eventhub.Fragments.PostDetailsFragment;
import com.example.eventhub.Models.Notifications;
import com.example.eventhub.Models.Organizers;
import com.example.eventhub.Models.Posts;
import com.example.eventhub.Models.User;
import com.example.eventhub.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.List;
    public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.ViewHolder>{

        private Context mContext;
        private List<Notifications> mNotifications;
        private FirebaseUser firebaseUser;

        public NotificationsAdapter(Context mContext, List<Notifications> mNotifications) {
            this.mContext = mContext;
            this.mNotifications = mNotifications;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(mContext).inflate(R.layout.notification_item, parent, false);


            return new NotificationsAdapter.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final ViewHolder holder, int i) {
            final Notifications notifications = mNotifications.get(i);
            String sourceString = "<font color=\"black\"><b>" + notifications.getText() + "</b></font>" + notifications.getDate();

            if (notifications.getText().trim().equals("has just posted new post")) {
                getOrganizerInfo(holder.image_profile, holder.username,notifications.getText(), notifications.getUserid());
            }else {
                getUserInfo(holder.image_profile, holder.username, notifications.getText(),notifications.getUserid());
            }

//            if (notifications.getIspost()){
//                holder.post_image.setVisibility(View.VISIBLE);
//                getPostImage(holder.post_image,notifications.getPostid());
//            }else {
//                holder.post_image.setVisibility(View.GONE);
//            }
            Calendar t = Calendar.getInstance();
            Long starttime = Long.parseLong(notifications.getDate());
            t.setTimeInMillis(starttime);
            int hourOFDAY = t.get(Calendar.HOUR_OF_DAY);
            int minuteofhour = t.get(Calendar.MINUTE);
            String amPM;

            if (hourOFDAY > 12) {
                hourOFDAY -= 12;
                amPM = "PM";

            } else if (hourOFDAY == 0) {
                hourOFDAY += 12;
                amPM = "AM";
            } else if (hourOFDAY == 12)
                amPM = "PM";
            else
                amPM = "AM";

            String times;
            if (minuteofhour <= 9) {

                if (minuteofhour == 0){

                    times  =  hourOFDAY  + " " + amPM;
                }else {
                    times = hourOFDAY + ": 0" + minuteofhour + " " + amPM;}
            } else{
                times =  hourOFDAY + ":" + minuteofhour + " " + amPM;}


            Calendar d = Calendar.getInstance();
            d.setTimeInMillis(Long.parseLong(notifications.getDate()));

            final String startDate = generateDaysabb(d.get(Calendar.DAY_OF_WEEK))+", "+generateMonthabb(((d.get(Calendar.MONTH))+1))+" "+d.get(Calendar.DAY_OF_MONTH)+" at "+times;
holder.ic_delete.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        FirebaseDatabase.getInstance().getReference("Notifications").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(notifications.getNotificationid()).removeValue();
    }
});
holder.date.setText(startDate);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (notifications.getIspost()){
                        SharedPreferences.Editor editor = mContext.getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();
                        editor.putString("postid", notifications.getPostid());
                        editor.apply();
                        ((FragmentActivity)mContext).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner,new PostDetailsFragment()).addToBackStack(null).commit();
                    }else {
                        SharedPreferences.Editor editor = mContext.getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();
                        editor.putString("profileid", notifications.getUserid());
                        editor.apply();
                        ((FragmentActivity)mContext).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner,new OrganizerProfileFragment()).addToBackStack(null).commit();
                    }
                }
            });

        }

        @Override
        public int getItemCount() {
            return mNotifications.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            public TextView username,date;
            public ImageView image_profile,ic_delete;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                username = itemView.findViewById(R.id.username);
                image_profile = itemView.findViewById(R.id.image_profile);
                ic_delete = itemView.findViewById(R.id.post_image);
                date = itemView.findViewById(R.id.date);

            }
        }



        //get user info
        private void getUserInfo(final ImageView imageView, final TextView textView, final String text, final String userid){
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users").child(userid);
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    User user = dataSnapshot.getValue(User.class);
                    String sourceString = "<font color=\"black\"><b>" + user.getFirstname() +" "+ user.getLastname()+ "</b></font>" +" "+ text;
                    textView.setText(Html.fromHtml(sourceString));
                    Glide.with(mContext).load(user.getImageurl()).into(imageView);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
        private void getOrganizerInfo(final ImageView imageView, final TextView textView, final String text, String userid){
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Organizers").child(userid);
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Organizers organizers = dataSnapshot.getValue(Organizers.class);
                    String sourceString = "<font color=\"black\"><b>" + organizers.getName() + "</b></font>" +" "+ text;
                    textView.setText(Html.fromHtml(sourceString));
                    Glide.with(mContext).load(organizers.getImageurl()).into(imageView);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

//        private  void getPostImage(final ImageView imageView, final String postid){
//            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts").child(postid);
//            reference.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                    if (dataSnapshot.exists()) {
//                        Posts posts = dataSnapshot.getValue(Posts.class);
//                        Glide.with(mContext).load(posts.getPostimage()).into(imageView);
//                    }
//
//                }
//                @Override
//                public void onCancelled(@NonNull DatabaseError databaseError) {
//
//                }
//            });
//        }
        public String generateDaysabb(int day) {
            String days;
            if (day == 7) {
                return days = "Sat";
            } else if (day == 1)
                return days = "Sun";
            else if (day == 2)
                return days = "Mon";
            else if (day == 3)
                return days = "Tue";
            else if (day == 4)
                return days = "wed";
            else if (day == 5)
                return days = "Thu";
            else if (day == 6)
                return days = "Fri";
            else
                return days = "";


        }

        public String generateMonthabb(int month) {
            String monthName;

            if (month == 1) {
                return monthName = "Jan";
            } else if (month == 2) {
                return monthName = "Feb";
            } else if (month == 3) {
                return monthName = "Mar";
            } else if (month == 4) {
                return monthName = "Apr";
            } else if (month == 5) {
                return monthName = "May";
            } else if (month == 6) {
                return monthName = "Jun";
            } else if (month == 7) {
                return monthName = "Jul";
            } else if (month == 8) {
                return monthName = "Aug";
            } else if (month == 9) {
                return monthName = "Sep";
            } else if (month == 10) {
                return monthName = "Oct";
            } else if (month == 11) {
                return monthName = "Nov";
            } else if (month == 12) {
                return monthName = "Dec";

            } else {
                return null;
            }
        }

    }


