package com.example.eventhub;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.eventhub.Models.Organizers;
import com.example.eventhub.Models.User;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class CreateOrganizerActivity extends AppCompatActivity {
    Uri imageUri;
    String myUri = "";
    StorageReference storageReference;
    StorageTask uploadTask;
    FirebaseAuth auth;
    FirebaseUser firebaseUser;
    DatabaseReference reference;
    boolean progressDone = false;

    EditText txt_name, txt_description;
    TextView txt_name_length, txt_description_length, edit_image;
    CircleImageView profile_image, ic_profile;
    LinearLayout frm_first_name, frm_last_name;
    RelativeLayout frm_profile_image;
    ImageView btn_back;
    Button btn_save;
    private View decorView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_organizer);
        profile_image = (CircleImageView) findViewById(R.id.profile_image);
        ic_profile = (CircleImageView) findViewById(R.id.ic_profile);
        txt_name = (EditText) findViewById(R.id.txt_first_name);
        txt_description = (EditText) findViewById(R.id.txt_last_name);
        txt_name_length = (TextView) findViewById(R.id.txt_name_length);
        frm_profile_image = (RelativeLayout) findViewById(R.id.frm_profile_image);
        frm_first_name = (LinearLayout) findViewById(R.id.frm_first_name);
        txt_description_length = findViewById(R.id.txt_last_name_length);
        frm_last_name = (LinearLayout) findViewById(R.id.frm_last_name);
        btn_back = (ImageView) findViewById(R.id.btn_back);
        edit_image = findViewById(R.id.btn_edit_image);
        btn_save = (Button) findViewById(R.id.btn_save);

        storageReference = FirebaseStorage.getInstance().getReference("organizer_images");
        organizer(profile_image, txt_name, txt_description);


        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final AlertDialog.Builder b = new AlertDialog.Builder(CreateOrganizerActivity.this, R.style.dialogTheme);
                b.setTitle("Save The Changes");
                b.setMessage("Are sure you want to save changes?");

                b.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        uploadImage();
                    }
                });
                b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                b.show();
            }
        });


        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        edit_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CropImage.activity()
                        .setAspectRatio(1, 1)
                        .setMinCropResultSize(500,500)
                        .setCropShape(CropImageView.CropShape.OVAL)
                        .setAllowRotation(true)
                        .setOutputCompressQuality(45)
                        .start(CreateOrganizerActivity.this);
                frm_profile_image.setBackgroundResource(R.drawable.circle_shape);
                edit_image.setText("Select Image");
                edit_image.setTextColor(getResources().getColor(R.color.colorPrimary));
                edit_image.setTextSize(16);
            }
        });


        txt_name_length.setText((int) txt_name.length() + " / 30");
        txt_name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_name_length.setText((int) txt_name.length() + " / 30");

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_name_length.setText((int) txt_name.length() + " / 30");

            }

            @Override
            public void afterTextChanged(Editable editable) {
                txt_name_length.setText((int) txt_name.length() + " / 30");

            }
        });

        decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int Visibility) {
                if(Visibility == 0)
                    decorView.setSystemUiVisibility(hideSystermBars());

            }
        });
        txt_description_length.setText((int) txt_description.length() + " / 350");
        txt_description.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_description_length.setText((int) txt_description.length() + " / 350");

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                txt_description_length.setText((int) txt_description.length() + " / 350");

            }

            @Override
            public void afterTextChanged(Editable editable) {
                txt_description_length.setText((int) txt_description.length() + " / 350");

            }
        });

// focus goes on linear layout child by clicking on it
        frm_first_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_name.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(txt_name, 1);
            }
        });
        // focus goes on linear layout child by clicking on it
        frm_last_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_description.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(txt_description, 1);
            }
        });
    }


    private String getFileExtention(Context context, Uri uri) {
        String extension = "";
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {

            MimeTypeMap mime = MimeTypeMap.getSingleton();
            extension = mime.getExtensionFromMimeType(context.getContentResolver().getType(uri));
        } else {
            extension = MimeTypeMap.getFileExtensionFromUrl(String.valueOf(Uri.fromFile(new File(uri.getPath().toString()))));
        }
        return extension;
    }

    //hide status bar on focus
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus){
            decorView.setSystemUiVisibility(hideSystermBars());
        }
    }
    // UI elements to hide and show
    private int hideSystermBars(){
        return View.SYSTEM_UI_FLAG_FULLSCREEN
                |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

    }
    private void uploadImage() {
        final ProgressDialog progressDialog = new ProgressDialog(this, android.R.style.Theme_DeviceDefault_Light_Dialog);
        progressDialog.setMessage("Uploading...");
        //prevent from progress dialog canelation on touch outside
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();


        if (imageUri != null) {
//            final StorageReference filerefrence = storageReference.child("images/"+ UUID.randomUUID().toString());

            final StorageReference filerefrence = storageReference.child(System.currentTimeMillis()
                    + "." + getFileExtention(this, imageUri));

            final String str_name = txt_name.getText().toString().trim();
            final String str_description = txt_description.getText().toString().trim();
            if (str_name.isEmpty() || str_description.isEmpty()) {
                progressDialog.dismiss();
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            } else {

                if (myUri != null && !myUri.equals(imageUri.toString())) {
                    if (!myUri.equals("")) {
                        StorageReference photoref = FirebaseStorage.getInstance().getReferenceFromUrl(myUri);
                        photoref.delete();
                    }
                    uploadTask = filerefrence.putFile(imageUri);
                    uploadTask.continueWithTask(new Continuation() {
                        @Override
                        public Object then(@NonNull Task task) throws Exception {
                            if (!task.isComplete()) {
                                throw task.getException();
                            }
                            return filerefrence.getDownloadUrl();
                        }
                    }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull final Task<Uri> task) {
                            if (task.isSuccessful()) {


                                Uri downloadUri = task.getResult();
                                myUri = downloadUri.toString();
                                String userid = auth.getInstance().getCurrentUser().getUid();

                                reference = FirebaseDatabase.getInstance().getReference().child("Organizers").child(userid);
                                Map<String, Object> hashMap = new HashMap<>();
                                hashMap.put("userid", userid);
                                hashMap.put("description", str_description);
                                hashMap.put("name", str_name);
                                hashMap.put("imageurl", myUri);

                                reference.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            progressDialog.dismiss();
                                            progressDone = true;
                                            finish();
                                        }
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(CreateOrganizerActivity.this, "failed", Toast.LENGTH_SHORT).show();
                                    }
                                });


                            }
                        }

                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(CreateOrganizerActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                } else {
                    String userid = auth.getInstance().getCurrentUser().getUid();
                    reference = FirebaseDatabase.getInstance().getReference().child("Organizers").child(userid);
                    Map<String, Object> hashMap = new HashMap<>();
                    hashMap.put("description", str_description);
                    hashMap.put("name", str_name);

                    reference.updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                progressDone = true;
                                progressDialog.dismiss();
                                finish();
                            }
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(CreateOrganizerActivity.this, "failed", Toast.LENGTH_SHORT).show();
                        }
                    });

                }


            }
        } else {
            progressDialog.dismiss();
            Toast.makeText(this, "imageurl null", Toast.LENGTH_SHORT).show();
        }


    }


    //get the result of photo crop
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            File file = new File(result.getUri().getPath());
            Long len = file.length()/1024;
            if (len < 10){
                profile_image.setImageURI(null);
                profile_image.setBackground(null);
                imageUri = null;
                frm_profile_image.setBackgroundResource(R.drawable.circle_shape_error);
                edit_image.setText("Image Has Bad Quality"+"\n     Select New One");
                edit_image.setTextColor(getResources().getColor(R.color.red));
                edit_image.setTextSize(13);

            }else if (len > 500){
                profile_image.setImageURI(null);
                profile_image.setBackground(null);
                imageUri = null;
                frm_profile_image.setBackgroundResource(R.drawable.circle_shape_error);
                edit_image.setText("Image is too large!"+"\n  Select New One");
                edit_image.setTextColor(getResources().getColor(R.color.red));
                edit_image.setTextSize(13);
            }else {
                imageUri = result.getUri();
                profile_image.setImageURI(imageUri);
            }
        }else if (imageUri != null) {
            profile_image.setImageURI(imageUri);

        }

    }

    public void organizer(final ImageView profile, final EditText name, final EditText description) {

        String userid = auth.getInstance().getCurrentUser().getUid();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Organizers").child(userid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!progressDone) {

                    if (dataSnapshot.exists()) {
                        Organizers organizer = dataSnapshot.getValue(Organizers.class);
                        if (!organizer.getImageurl().isEmpty()) {
                            Glide.with(CreateOrganizerActivity.this).load(organizer.getImageurl()).into(profile);
                        }
                        name.setText(organizer.getName());
                        description.setText(organizer.getDescription());

                        if (!organizer.getImageurl().isEmpty()) {
                            myUri = organizer.getImageurl();
                            Uri path = Uri.parse(myUri);
                            imageUri = path;

                        }
                    }


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

        public void hideSoftInput(View view) {
            InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(),0);
        }

}
