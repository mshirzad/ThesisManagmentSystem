package com.example.eventhub.Fragments;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.eventhub.EditProfileActivity;
import com.example.eventhub.Models.Posts;
import com.example.eventhub.Models.User;
import com.example.eventhub.PostActivity;
import com.example.eventhub.R;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.INPUT_METHOD_SERVICE;


public class RegistrationFragment extends Fragment {

    String postid, userid,publisherid ;
    Uri imageUri;
    StorageReference storageReference;
    String myUri = "";
    TextView username, txt_title, txt_dateTime, select_image;
    EditText txt_name, txt_last_name, txt_email,phone_number;
    LinearLayout frm_email, frm_name, frm_last_name,frm_phone_number;
    ImageView back,img_profile,img_profile1;
    Button btn_register;
    UploadTask uploadTask;
    View progress_bar;
    ProgressDialog progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_registeration, container, false);

        txt_title = view.findViewById(R.id.txt_title);
        txt_dateTime = view.findViewById(R.id.txt_dateTime);
        txt_email = view.findViewById(R.id.txt_email);
        username = view.findViewById(R.id.username);
        txt_name = view.findViewById(R.id.txt_name);
        txt_last_name = view.findViewById(R.id.txt_last_name);
        img_profile = view.findViewById(R.id.img_profile);
        img_profile1 = view.findViewById(R.id.img_profile1);
        frm_email = view.findViewById(R.id.frm_email);
        phone_number = view.findViewById(R.id.phone_number);
        frm_name = view.findViewById(R.id.frm_name);
        frm_phone_number = view.findViewById(R.id.frm_phone_number);
        frm_last_name = view.findViewById(R.id.frm_last_name);
        progress_bar = view.findViewById(R.id.progress_bar);
        btn_register = view.findViewById(R.id.btn_register);
        select_image = view.findViewById(R.id.select_image);
        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);
        bottomNavigationView.setVisibility(View.GONE);
        txt_email.setSelection(txt_email.getText().length());
        txt_last_name.setSelection(txt_email.getText().length());
        txt_name.setSelection(txt_email.getText().length());
        back = view.findViewById(R.id.ic_back);
        progressDialog = new ProgressDialog(getContext(), android.R.style.Theme_DeviceDefault_Light_Dialog);
        progressDialog.setMessage("Uploading...");
        //prevent from progress dialog canelation on touch outside
        progressDialog.setCanceledOnTouchOutside(false);

        storageReference = FirebaseStorage.getInstance().getReference("participant_images");


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().onBackPressed();
            }
        });

        frm_email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_email.requestFocus();
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(INPUT_METHOD_SERVICE);
                imm.showSoftInput(txt_email, 1);


            }
        });

        frm_last_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_last_name.requestFocus();
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(INPUT_METHOD_SERVICE);
                imm.showSoftInput(txt_last_name, 1);

            }
        });
        frm_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_name.requestFocus();
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(INPUT_METHOD_SERVICE);
                imm.showSoftInput(txt_name, 1);

            }
        });
        select_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CropImage.activity()
                        .setAspectRatio(1, 1)
                        .setMinCropResultSize(700,700)
                        .setCropShape(CropImageView.CropShape.RECTANGLE)
                        .setAllowRotation(true)
                        .setOutputCompressQuality(40)
                        .start(getActivity());
                img_profile.setBackgroundResource(R.drawable.circle_shape);
                select_image.setText("Select Image");
                select_image.setTextColor(getResources().getColor(R.color.colorPrimary));
                select_image.setTextSize(16);
            }
        });
        frm_phone_number.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                phone_number.requestFocus();
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(INPUT_METHOD_SERVICE);
                imm.showSoftInput(phone_number, 1);
            }
        });


        SharedPreferences sharedPreferences = getContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE);
        postid = sharedPreferences.getString("postid", "none");

        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (img_profile.getVisibility() ==View.VISIBLE){
                        if (img_profile.getDrawable() != null){
                    progressDialog.show();
                    FirebaseDatabase.getInstance().getReference().child("Joined").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .child(postid).setValue(true);
                    uploadImage();
                        }else Toast.makeText(getContext(), "All fields are required!", Toast.LENGTH_SHORT).show();

                    }else if (img_profile1.getVisibility() == View.VISIBLE && img_profile1.getDrawable() != null){
                        progressDialog.show();
                        FirebaseDatabase.getInstance().getReference().child("Joined").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                .child(postid).setValue(true);
                        uploadImage();
                    }else Toast.makeText(getContext(), "All fields are required!", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts").child(postid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Posts posts = dataSnapshot.getValue(Posts.class);
                txt_title.setText(posts.getTitle());
                publisherid = posts.getPublisher();

                String date = posts.getStartDate();
                Calendar c = Calendar.getInstance();
                Long d = Long.parseLong(date);
                c.setTimeInMillis(d);
                String month = generateMonth(((c.get(Calendar.MONTH)) + 1));
                String day = generateDays(c.get(Calendar.DAY_OF_WEEK));


                Calendar t = Calendar.getInstance();
                Long time = Long.parseLong(posts.getStartTime());
                t.setTimeInMillis(time);

                int hourOFDAY = t.get(Calendar.HOUR_OF_DAY);
                int minuteofhour = t.get(Calendar.MINUTE);
                String amPM;
                if (hourOFDAY > 12) {
                    hourOFDAY -= 12;
                    amPM = "PM";

                } else if (hourOFDAY == 0) {
                    hourOFDAY += 12;
                    amPM = "AM";
                } else if (hourOFDAY == 12)
                    amPM = "PM";
                else
                    amPM = "AM";

                String stimes;
                if (minuteofhour <= 9) {

                    if (minuteofhour == 0) {

                        stimes = hourOFDAY + " " + amPM;
                    } else {
                        stimes = hourOFDAY + ": 0" + minuteofhour + " " + amPM;
                    }
                } else {
                    stimes = hourOFDAY + ":" + minuteofhour + " " + amPM;
                }


                Calendar et = Calendar.getInstance();
                Long endtime = Long.parseLong(posts.getEndTime());
                et.setTimeInMillis(endtime);
                int hour = et.get(Calendar.HOUR_OF_DAY);
                int minute = et.get(Calendar.MINUTE);
                String status;
                if (hour > 12) {
                    hour -= 12;
                    status = "PM";

                } else if (hour == 0) {
                    hour += 12;
                    status = "AM";
                } else if (hour == 12)
                    status = "PM";
                else
                    status = "AM";

                String etimes;
                if (minute <= 9) {

                    if (minute == 0) {

                        etimes = hour + " " + status;
                    } else {
                        etimes = hour + ": 0" + minute + " " + status;
                    }
                } else {
                    etimes = hour + ":" + minute + " " + status;
                }


                txt_dateTime.setText(day + ", " + c.get(Calendar.DAY_OF_MONTH) + " " + month + " " + c.get(Calendar.YEAR) + " from " + stimes + " to " + etimes);


                userInfo(img_profile, txt_name, txt_last_name, username, txt_email,phone_number);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        return view;


    }



    public void userInfo(final ImageView profile_image, final EditText txt_name, final EditText txt_last_name, final TextView username, TextView txt_email, final EditText phone_number) {

        final String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        txt_email.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users").child(userid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                User user = dataSnapshot.getValue(User.class);
                if (!user.getImageurl().isEmpty() &&  getContext() != null) {
                    Glide.with(getContext()).load(user.getImageurl()).into(profile_image);
                }

                txt_name.setText(user.getFirstname());
                txt_last_name.setText(user.getLastname());
                username.setText(user.getFirstname() + " " + user.getLastname());
                phone_number.setText(user.getNumber());

                if (!user.getImageurl().isEmpty()) {
                    myUri = user.getImageurl();
                    Uri path = Uri.parse(myUri);
                    imageUri = path;

                }
                progress_bar.setVisibility(View.GONE);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void uploadImage() throws IOException {

        if (imageUri != null) {

            final StorageReference filerefrence = storageReference.child(System.currentTimeMillis()
                    + "." + getFileExtention(getContext(), imageUri));


            final String str_email = txt_email.getText().toString();
            final String str_name = txt_name.getText().toString();
            final String str_last_name = txt_last_name.getText().toString();
            final String str_phone_number = phone_number.getText().toString();

            if (str_name.isEmpty() || str_last_name.isEmpty() || str_email.isEmpty() || str_phone_number.isEmpty()) {
                progressDialog.dismiss();
                Toast.makeText(getContext(), "All fields are required", Toast.LENGTH_SHORT).show();
            } else {
                if (myUri.length() < 0 || myUri.equals("https://firebasestorage.googleapis.com/v0/b/eventhub-5ecec.appspot.com/o/user%20(1).png?alt=media&token=58590a57-0254-4a2a-b733-56874d051cd4")) {
                    progressDialog.dismiss();
                    Toast.makeText(getContext(), "Select your image!", Toast.LENGTH_SHORT).show();
                } else {

                    if (myUri != null && !myUri.equals(imageUri.toString())) {

                        uploadTask = filerefrence.putFile(imageUri);
                        uploadTask.continueWithTask(new Continuation() {
                            @Override
                            public Object then(@NonNull Task task) throws Exception {
                                if (!task.isComplete()) {
                                    throw task.getException();
                                }
                                return filerefrence.getDownloadUrl();
                            }
                        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull final Task<Uri> task) {
                                if (task.isSuccessful()) {
                                    if (!publisherid.trim().isEmpty()){
                                    addNotifications(publisherid, postid);}
                                    Uri downloadUri = task.getResult();
                                    myUri = downloadUri.toString();
                                    final String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Participants").child(postid).child(userid);
                                    Map<String, Object> hashMap = new HashMap<>();
                                    hashMap.put("lastname", str_last_name);
                                    hashMap.put("userid", userid);
                                    hashMap.put("firstname", str_name);
                                    hashMap.put("email", str_email);
                                    hashMap.put("imageurl", myUri);
                                    hashMap.put("number",  str_phone_number);
                                    reference.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                        progressDialog.dismiss();
                                                        ((FragmentActivity) getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new HomeFragment()).commit();
                                                    }
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toast.makeText(getContext(), "failed", Toast.LENGTH_SHORT).show();
                                        }
                                    });


                                }
                            }

                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getContext(), "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {

                        Bitmap bitmap = ((BitmapDrawable) img_profile.getDrawable()).getBitmap();
                        final Uri mynewUri = getImageUris(getContext(),bitmap);
                        uploadTask = filerefrence.putFile(mynewUri);
                        uploadTask.continueWithTask(new Continuation() {
                            @Override
                            public Object then(@NonNull Task task) throws Exception {
                                if (!task.isComplete()) {
                                    throw task.getException();
                                }
                                return filerefrence.getDownloadUrl();
                            }
                        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull final Task<Uri> task) {
                                if (task.isSuccessful()) {
                                    if (!publisherid.trim().isEmpty()){
                                        addNotifications(publisherid, postid);}
                                    Uri downloadUri = task.getResult();
                                    myUri = downloadUri.toString();
                                    String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Participants").child(postid).child(userid);
                                    Map<String, Object> hashMap = new HashMap<>();
                                    hashMap.put("lastname", str_last_name);
                                    hashMap.put("firstname", str_name);
                                    hashMap.put("email", str_email);
                                    hashMap.put("imageurl", myUri);
                                    hashMap.put("number", str_phone_number);

                                    reference.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                progressDialog.dismiss();
                                                ((FragmentActivity) getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new HomeFragment()).commit();
                                            }
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toast.makeText(getContext(), "failed", Toast.LENGTH_SHORT).show();
                                        }
                                    });


                                }
                            }

                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getContext(), "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
//


                    }

                }


            }
        } else {
            progressDialog.dismiss();
            Toast.makeText(getContext(), "image null", Toast.LENGTH_SHORT).show();
        }


    }
    //add notifications
    private void addNotifications(final String userid, final String postid){
        String date = String.valueOf(Calendar.getInstance().getTimeInMillis());
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Notifications").child(userid);
        final String notificationid = reference.push().getKey();
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("userid",FirebaseAuth.getInstance().getCurrentUser().getUid());
        hashMap.put("notificationid",notificationid);
        hashMap.put("text","Joined Your Event");
        hashMap.put("postid",postid);
        hashMap.put("ispost", true);
        hashMap.put("date",date);
        reference.child(notificationid).setValue(hashMap);
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            File file = new File(result.getUri().getPath());
            Long len = file.length()/1024;
            Toast.makeText(getContext(), ""+len, Toast.LENGTH_SHORT).show();
            if (len < 25){
                img_profile1.setVisibility(View.GONE);
                img_profile.setVisibility(View.VISIBLE);
                imageUri = null;
                img_profile.setBackgroundResource(R.drawable.circle_shape_error);
                select_image.setText("Image Has Bad Quality"+"\n     Select New One");
                select_image.setTextColor(getResources().getColor(R.color.red));
                select_image.setTextSize(13);

            }else if (len > 600){
                img_profile1.setVisibility(View.GONE);
                img_profile.setVisibility(View.VISIBLE);
                imageUri = null;
                img_profile.setBackgroundResource(R.drawable.circle_shape_error);
                select_image.setText("Image is too large!"+"\n  Select New One");
                select_image.setTextColor(getResources().getColor(R.color.red));
                select_image.setTextSize(13);
            }else {
                imageUri = result.getUri();
                if (img_profile1.getVisibility() == View.GONE){
                    img_profile.setVisibility(View.GONE);
                    img_profile1.setVisibility(View.VISIBLE);
                    img_profile1.setImageURI(result.getUri());
                }else {
                    img_profile1.setImageURI(result.getUri());
                }
            }
        }else if (imageUri != null) {
            img_profile1.setImageURI(imageUri);

        }

    }

    private String getFileExtention(Context context, Uri uri) {
        String extension = "";
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {

            MimeTypeMap mime = MimeTypeMap.getSingleton();
            extension = mime.getExtensionFromMimeType(context.getContentResolver().getType(uri));
        } else {
            extension = MimeTypeMap.getFileExtensionFromUrl(String.valueOf(Uri.fromFile(new File(uri.getPath().toString()))));
        }
        return extension;
    }

    @Override
    public void onStop() {
        super.onStop();
        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);

        bottomNavigationView.setVisibility(View.VISIBLE);

    }

    @Override
    public void onResume() {
        super.onResume();
        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);
        bottomNavigationView.setVisibility(View.GONE);

    }

    public Uri getImageUris(Context context, Bitmap bitmap) {

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(context.getContentResolver(), bitmap, "Title", null);
        return Uri.parse(path);

    }
    public String generateMonth(int month) {
        String monthName;

        if (month == 1) {
            return monthName = "January";
        } else if (month == 2) {
            return monthName = "February";
        } else if (month == 3) {
            return monthName = "March";
        } else if (month == 4) {
            return monthName = "April";
        } else if (month == 5) {
            return monthName = "May";
        } else if (month == 6) {
            return monthName = "June";
        } else if (month == 7) {
            return monthName = "July";
        } else if (month == 8) {
            return monthName = "August";
        } else if (month == 9) {
            return monthName = "September";
        } else if (month == 10) {
            return monthName = "October";
        } else if (month == 11) {
            return monthName = "November";
        } else if (month == 12) {
            return monthName = "December";

        } else {
            return null;
        }

    }

    public String generateDays(int day) {
        String days;
        if (day == 7) {
            return days = "Saturday";
        } else if (day == 1)
            return days = "Sunday";
        else if (day == 2)
            return days = "Monday";
        else if (day == 3)
            return days = "Tuesday";
        else if (day == 4)
            return days = "wednesday";
        else if (day == 5)
            return days = "Thursday";
        else if (day == 6)
            return days = "Friday";
        else
            return days = "";


    }
    public void hideSoftInput(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager)getActivity().getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(),0);
    }
}
