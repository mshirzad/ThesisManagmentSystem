package com.example.eventhub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.SignInMethodQueryResult;

public class ForgotPasswordActivity extends AppCompatActivity {

    Button send_email;
    TextView txt_error,back;
    TextInputEditText email;
    TextInputLayout email_inputLayout;
    FirebaseAuth firebaseauth;
    String str_email;
    CoordinatorLayout coordinatorLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        send_email = findViewById(R.id.send_email);
        txt_error = findViewById(R.id.txt_error);
        back = findViewById(R.id.back);
        email = findViewById(R.id.email);
        email_inputLayout = findViewById(R.id.email_inputLayout);
        coordinatorLayout = findViewById(R.id.coordinatorlayout);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        onFocusChange(email,email_inputLayout,"Email");
        send_email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hideSoftInput(coordinatorLayout);
                str_email = email.getText().toString().trim();
                if (TextUtils.isEmpty(str_email)   || !Patterns.EMAIL_ADDRESS.matcher(str_email).matches()) {
                    checkValidation();
                }else {
                    checkEmailExist();
                }
            }
        });



    }

    private void onFocusChange(final TextInputEditText textInputEditText, final TextInputLayout textInputLayout, final String hint) {
        textInputEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (b) {
                    textInputEditText.setBackgroundResource(R.drawable.text_input_layout_drawable);
                    textInputLayout.setErrorEnabled(false);
                    if (textInputEditText.getText().length() == 0) {
                        textInputLayout.setHint(hint + " *");
                        textInputLayout.setHintTextAppearance(R.style.error);
                    } else {
                        textInputLayout.setHint(hint);
                        if (hint.equals("Email")) {
                            if (!Patterns.EMAIL_ADDRESS.matcher(textInputEditText.getText().toString().trim()).matches()) {
                                textInputLayout.setErrorEnabled(false);
                                textInputLayout.setHintTextAppearance(R.style.error);
                                textInputLayout.setHint(hint + " *");
                            }
                        }
                    }
                } else {
                    textInputLayout.setHint(hint);
                    if (textInputEditText.getText().length() > 0) {
                        textInputLayout.setErrorEnabled(false);
                    }
                }
            }
        });
        textInputEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                textInputEditText.setBackgroundResource(R.drawable.text_input_layout_drawable);
                if (txt_error.getVisibility() == View.VISIBLE){
                    txt_error.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                textInputLayout.setErrorEnabled(false);
                if (Patterns.EMAIL_ADDRESS.matcher(textInputEditText.getText().toString().trim()).matches() && hint.equals("Email")) {
                    textInputLayout.setHintTextAppearance(R.style.textLabelSuccess);
                    textInputLayout.setHint(hint);
                    textInputLayout.setErrorEnabled(false);
                } else if (hint.equals("Email")) {
                    textInputLayout.setHint(hint + " *");
                    textInputLayout.setHintTextAppearance(R.style.error);
                } else if (Patterns.EMAIL_ADDRESS.matcher(textInputEditText.getText().toString().trim()).matches() && textInputLayout.isErrorEnabled()) {
                    textInputLayout.setErrorEnabled(false);
                    textInputLayout.setHintTextAppearance(R.style.textLabelSuccess);
                    textInputLayout.setHint(hint);
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {


            }
        });

    }
    private void checkValidation() {
        String str_email = email.getText().toString().trim();
        if (TextUtils.isEmpty(str_email)) {
            email_inputLayout.setErrorEnabled(true);
            email_inputLayout.setHint("Email *");
            email_inputLayout.setErrorTextAppearance(R.style.error);
            email_inputLayout.setError("Email Address is required!");
            email.setBackgroundResource(R.drawable.text_input_layout_error);
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(str_email).matches() && str_email.length() != 0) {
            email_inputLayout.setErrorEnabled(true);
            email_inputLayout.setHint("Email *");
            email_inputLayout.setErrorTextAppearance(R.style.error);
            email_inputLayout.setError("Not a Valid Email Address!");
            email.setBackgroundResource(R.drawable.text_input_layout_error);
        }

    }
    private void checkEmailExist() {
        final ProgressDialog pd = new ProgressDialog(ForgotPasswordActivity.this, android.R.style.Theme_DeviceDefault_Light_Dialog);
        pd.setMessage("Please Wait...");
        pd.setCanceledOnTouchOutside(false);
        pd.show();
        FirebaseAuth.getInstance().fetchSignInMethodsForEmail(str_email)
                .addOnCompleteListener(new OnCompleteListener<SignInMethodQueryResult>() {
                    @Override
                    public void onComplete(@NonNull Task<SignInMethodQueryResult> task) {

                        boolean isNewUser = task.getResult().getSignInMethods().isEmpty();

                        if (isNewUser) {
                            // email not existed
                            txt_error.setText("Email does not exist!");
                            txt_error.setVisibility(View.VISIBLE);
                            pd.dismiss();
                        } else {
                            // email existed
                            FirebaseAuth.getInstance().sendPasswordResetEmail(str_email)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                pd.dismiss();
                                                Snackbar snackbar =  Snackbar.make(coordinatorLayout,"An email has been sent to you!",Snackbar.LENGTH_LONG);
                                                snackbar.setAction("Log In", new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View view) {
                                                        startActivity(new Intent(ForgotPasswordActivity.this,LoginActivity.class));
                                                    }
                                                }).setDuration(20000);
                                                snackbar.setActionTextColor(getResources().getColor(R.color.colorPrimary));
                                                View sbView = snackbar.getView();
                                                sbView.setBackgroundColor(ContextCompat.getColor(getApplicationContext(),R.color.black1));
                                                TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
                                                textView.setTextColor(getResources().getColor(R.color.white));
                                                snackbar.show();


                                            } else {
                                                pd.dismiss();
                                                txt_error.setVisibility(View.VISIBLE);
                                                txt_error.setText(task.getException().getMessage());
                                            }
                                        }
                                    });
                        }

                    }
                });
    }
    public void hideSoftInput(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(),0);
    }
}
