package com.example.eventhub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.androidstudy.networkmanager.Monitor;
import com.androidstudy.networkmanager.Tovuti;
import com.example.eventhub.Fragments.HomeFragment;
import com.example.eventhub.Fragments.NotificationsFragment;
import com.example.eventhub.Fragments.ProfileFragment;
import com.example.eventhub.Fragments.SearchFragment;
import com.example.eventhub.Fragments.TicketsFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.FirebaseDatabase;


public class MainActivity extends AppCompatActivity {

    private View decorView;
    View layout_error;
    TextView close;
    Float x1, x2;
    int min_distance = 150;
    Animation animation;
    int counter = 0;
    BottomNavigationView bottomnav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        layout_error = findViewById(R.id.layout_error);
        close = findViewById(R.id.close);

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout_error.setVisibility(View.GONE);
            }
        });

        Tovuti.from(this).monitor(new Monitor.ConnectivityListener() {
            @Override
            public void onConnectivityChanged(int connectionType, boolean isConnected, boolean isFast) {
                if (isConnected) {
                    if (layout_error.getVisibility() == View.VISIBLE) {
                        layout_error.setVisibility(View.GONE);
                    }
                } else {
                    layout_error.setVisibility(View.VISIBLE);
                }
            }
        });



        //set bottom navigation and show it
        bottomnav = findViewById(R.id.bottom_navigation);
        bottomnav.setOnNavigationItemSelectedListener(navListener);
        getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new HomeFragment()).commit();


        //show Status bar on swipe
        decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int Visibility) {
                if (Visibility == 0)
                    decorView.setSystemUiVisibility(hideSystermBars());

            }
        });

    }


    //how to change edittext focus when clicking outside of it
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (getCurrentFocus() != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);

        }

        return super.dispatchTouchEvent(ev);
    }


//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//       getMenuInflater().inflate(R.menu.app_bar_menu, menu);
//        return true;
//    }


    //hide status bar on focus
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            decorView.setSystemUiVisibility(hideSystermBars());
        }
    }

    // UI elements to hide and show
    private int hideSystermBars() {
        return View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

    }

    //Change between bottom navigation items
    private BottomNavigationView.OnNavigationItemSelectedListener navListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            Fragment selectedfragment = null;
            switch (menuItem.getItemId()) {
                case R.id.navigation_home:
                    selectedfragment = new HomeFragment();
                    counter = 1;
                    break;
                case R.id.navigation_search:
                    counter = 2;
                    selectedfragment = new SearchFragment();
                    break;
                case R.id.navigation_tickets:
                    counter = 3;
                    selectedfragment = new TicketsFragment();
                    break;
                case R.id.navigation_notifications:
                    counter = 4;
                    selectedfragment = new NotificationsFragment();
                    break;
                case R.id.navigation_profile:
                    counter = 5;
                    selectedfragment = new ProfileFragment();
                    break;

            }


            getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, selectedfragment).commit();
            return true;
        }
    };

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                x1 = event.getX();
                break;
            case MotionEvent.ACTION_UP:
                x2 = event.getX();
                float deltaX = x2 - x1;
                if (Math.abs(deltaX) > min_distance) {
                    if (x1 > x2) {
                        if (counter <= 4) {
                            counter++;
                            switch (counter) {
                                case 1:
                                    bottomnav.setSelectedItemId(R.id.navigation_home);
                                    getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new HomeFragment()).commit();
                                    break;
                                case 2:
                                    getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new SearchFragment()).commit();
                                    bottomnav.setSelectedItemId(R.id.navigation_search);
                                    break;
                                case 3:
                                    getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new TicketsFragment()).commit();
                                    bottomnav.setSelectedItemId(R.id.navigation_tickets);
                                    break;
                                case 4:
                                    getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new NotificationsFragment()).commit();
                                    bottomnav.setSelectedItemId(R.id.navigation_notifications);
                                    break;
                                case 5:
                                    getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new ProfileFragment()).commit();
                                    bottomnav.setSelectedItemId(R.id.navigation_profile);
                                    break;
                            }
                        }
                    } else {
                        if (counter <= 4 && counter > 1) {
                            counter--;
                            switch (counter) {
                                case 1:
                                    bottomnav.setSelectedItemId(R.id.navigation_home);
                                    getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new HomeFragment()).commit();
                                    break;
                                case 2:
                                    getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new SearchFragment()).commit();
                                    bottomnav.setSelectedItemId(R.id.navigation_search);
                                    break;
                                case 3:
                                    getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new TicketsFragment()).commit();
                                    bottomnav.setSelectedItemId(R.id.navigation_tickets);
                                    break;
                                case 4:
                                    getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new NotificationsFragment()).commit();
                                    bottomnav.setSelectedItemId(R.id.navigation_notifications);
                                    break;
                                case 5:
                                    getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner, new ProfileFragment()).commit();
                                    bottomnav.setSelectedItemId(R.id.navigation_profile);
                                    break;
                            }
                        }
                    }
                }
                break;
        }
        return super.onTouchEvent(event);
    }


}
