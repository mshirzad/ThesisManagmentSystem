package com.example.eventhub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ChangePasswordActivity extends AppCompatActivity {

    TextInputLayout old_Password_inputLayout,new_Password_inputLayout,new_Password_confirm_inputLayout;
    TextInputEditText confirm_new_password,new_password,old_Password;
    Button change;
    TextView txt_error,back;
    String str_password,str_confirm_password,str_new_password;
    CoordinatorLayout coordinatorLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        old_Password = findViewById(R.id.old_Password);
        new_password = findViewById(R.id.new_password);
        confirm_new_password = findViewById(R.id.confirm_new_password);
        old_Password_inputLayout = findViewById(R.id.old_Password_inputLayout);
        new_Password_inputLayout = findViewById(R.id.new_Password_inputLayout);
        new_Password_confirm_inputLayout = findViewById(R.id.new_Password_confirm_inputLayout);
        change = findViewById(R.id.change);
        back = findViewById(R.id.back);
        coordinatorLayout = findViewById(R.id.coordinatorlayout);
        txt_error = findViewById(R.id.txt_error);
        onFocusChange(old_Password, old_Password_inputLayout, "Password");
        onFocusChange(new_password, new_Password_inputLayout, "New Password");
        onFocusChange(confirm_new_password, new_Password_confirm_inputLayout, "New Password");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 str_password = old_Password.getText().toString().trim();
                 str_confirm_password = new_password.getText().toString().trim();
                 str_new_password = confirm_new_password.getText().toString().trim();
                txt_error.setVisibility(View.GONE);

                if (!str_new_password.equals(str_confirm_password)) {
                    txt_error.setVisibility(View.VISIBLE);
                    txt_error.setText("passwords do not match.");
                } else {
                    if (str_password.length() == 0 || str_password.length() < 8 || str_new_password.length() == 0 || str_new_password.length() < 8
                            || str_confirm_password.length() == 0 || str_confirm_password.length() < 8 || str_new_password.contains(" ") || str_password.contains(" ") || str_confirm_password.contains(" "))
                        checkValidation();
                    else changePassword();
                }

            }
        });
    }

            private void changePassword() {
                final ProgressDialog pd = new ProgressDialog(ChangePasswordActivity.this, android.R.style.Theme_DeviceDefault_Light_Dialog);
                pd.setMessage("Please Wait...");
                pd.setCanceledOnTouchOutside(false);
                pd.show();
                final FirebaseUser user;
                user = FirebaseAuth.getInstance().getCurrentUser();
                final String email = user.getEmail();
                AuthCredential credential = EmailAuthProvider.getCredential(email, str_password);

                user.reauthenticate(credential).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            user.updatePassword(str_new_password).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (!task.isSuccessful()) {
                                        pd.dismiss();
                                        pd.dismiss();
                                        Snackbar snackbar =  Snackbar.make(coordinatorLayout,"Something went wrong. Please try again later!",Snackbar.LENGTH_LONG);
                                        snackbar.setDuration(20000);
                                        snackbar.setActionTextColor(getResources().getColor(R.color.colorPrimary));
                                        View sbView = snackbar.getView();
                                        sbView.setBackgroundColor(ContextCompat.getColor(getApplicationContext(),R.color.black1));
                                        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
                                        textView.setTextColor(getResources().getColor(R.color.white));
                                        snackbar.show();

                                    } else {
                                        confirm_new_password.setText(null);
                                        new_password.setText(null);
                                        old_Password.setText(null);
                                        old_Password.setHint("Password");
                                        new_password.setHint("New Password");
                                        confirm_new_password.setHint("New Password");
                                        pd.dismiss();
                                        Snackbar snackbar =  Snackbar.make(coordinatorLayout,"Password Successfully Modified!",Snackbar.LENGTH_LONG);
                                        snackbar.setAction("Close", new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                startActivity(new Intent(ChangePasswordActivity.this,OptionsActivity.class));
                                            }
                                        }).setDuration(20000);
                                        snackbar.setActionTextColor(getResources().getColor(R.color.colorPrimary));
                                        View sbView = snackbar.getView();
                                        sbView.setBackgroundColor(ContextCompat.getColor(getApplicationContext(),R.color.black1));
                                        TextView textView = (TextView) sbView.findViewById(com.google.android.material.R.id.snackbar_text);
                                        textView.setTextColor(getResources().getColor(R.color.white));
                                        snackbar.show();
                                    }
                                }
                            });
                        } else {
                            txt_error.setVisibility(View.VISIBLE);
                            txt_error.setText("Your old password is wrong.");
                            pd.dismiss();
                        }
                    }
                });
            }





    public void hideSoftInput(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(),0);
    }
    private void onFocusChange(final TextInputEditText textInputEditText, final TextInputLayout textInputLayout, final String hint) {
        textInputEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (b) {
                    textInputEditText.setBackgroundResource(R.drawable.text_input_layout_drawable);
                    textInputLayout.setErrorEnabled(false);
                    if (textInputEditText.getText().length() == 0) {
                        textInputLayout.setHint(hint + " *");
                        textInputLayout.setHintTextAppearance(R.style.error);
                    } else {
                        textInputLayout.setHint(hint);
                    }
                } else {
                    textInputLayout.setHint(hint);
                    if (textInputEditText.getText().length() > 0) {
                        textInputLayout.setErrorEnabled(false);
                    }
                }
            }
        });
        textInputEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                textInputEditText.setBackgroundResource(R.drawable.text_input_layout_drawable);
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                textInputLayout.setErrorEnabled(false);
                if (textInputEditText.getText().length() >= 8 && hint.equals("Password") && !textInputEditText.getText().toString().contains(" ")) {
                    textInputLayout.setErrorEnabled(false);
                    textInputLayout.setHintTextAppearance(R.style.textLabelSuccess);
                    textInputLayout.setHint(hint);
                }else if (textInputEditText.getText().length() >= 8 && hint.equals("New Password") && !textInputEditText.getText().toString().contains(" ")) {
                    textInputLayout.setErrorEnabled(false);
                    textInputLayout.setHintTextAppearance(R.style.textLabelSuccess);
                    textInputLayout.setHint(hint);
                } else {
                    textInputLayout.setHint(hint + " *");
                    textInputLayout.setHintTextAppearance(R.style.error);
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {


            }
        });


    }
    private void checkValidation() {
        String str_password = old_Password.getText().toString();
        String str_confirm_password = new_password.getText().toString();
        String str_new_password = confirm_new_password.getText().toString();
        if (TextUtils.isEmpty(str_password) || str_password.length() < 8 || str_password.contains(" ")) {
            old_Password_inputLayout.setErrorEnabled(true);
            old_Password_inputLayout.setHint("Password *");
            old_Password_inputLayout.setErrorTextAppearance(R.style.error);
            if (str_password.length() == 0)
                old_Password_inputLayout.setError("Password is required!");
            else if (str_password.contains(" ")) old_Password_inputLayout.setError("Password Shouldn't Contain Space!");
            else old_Password_inputLayout.setError("Password is less than 8 characters!");
            old_Password.setBackgroundResource(R.drawable.text_input_layout_error);
        }
        if (TextUtils.isEmpty(str_password) || str_password.length() < 8 || str_password.contains(" ")) {
            old_Password_inputLayout.setErrorEnabled(true);
            old_Password_inputLayout.setHint("Password *");
            old_Password_inputLayout.setErrorTextAppearance(R.style.error);
            if (str_password.length() == 0)
                old_Password_inputLayout.setError("Password is required!");
            else if (str_password.contains(" ")) old_Password_inputLayout.setError("Password Shouldn't Contain Space!");
            else old_Password_inputLayout.setError("Password is less than 8 characters!");
            old_Password.setBackgroundResource(R.drawable.text_input_layout_error);
        }
        if (TextUtils.isEmpty(str_new_password) || str_new_password.length() < 8 || str_new_password.contains(" ")) {
            new_Password_inputLayout.setErrorEnabled(true);
            new_Password_inputLayout.setHint("Password *");
            new_Password_inputLayout.setErrorTextAppearance(R.style.error);
            if (str_new_password.length() == 0)
                new_Password_inputLayout.setError("Password is required!");
            else if (str_new_password.contains(" ")) new_Password_inputLayout.setError("Password Shouldn't Contain Space!");
            else new_Password_inputLayout.setError("Password is less than 8 characters!");
            new_password.setBackgroundResource(R.drawable.text_input_layout_error);
        }
        if (TextUtils.isEmpty(str_confirm_password) || str_confirm_password.length() < 8 || str_confirm_password.contains(" ")) {
            new_Password_confirm_inputLayout.setErrorEnabled(true);
            new_Password_confirm_inputLayout.setHint("Password *");
            new_Password_confirm_inputLayout.setErrorTextAppearance(R.style.error);
            if (str_confirm_password.length() == 0)
                new_Password_confirm_inputLayout.setError("Password is required!");
            else if (str_confirm_password.contains(" ")) new_Password_confirm_inputLayout.setError("Password Shouldn't Contain Space!");
            else new_Password_confirm_inputLayout.setError("Password is less than 8 characters!");
            confirm_new_password.setBackgroundResource(R.drawable.text_input_layout_error);
        }


    }
}
