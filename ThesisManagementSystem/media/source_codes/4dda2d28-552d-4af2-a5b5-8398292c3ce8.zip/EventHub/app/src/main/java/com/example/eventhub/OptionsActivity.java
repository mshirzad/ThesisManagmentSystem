package com.example.eventhub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class OptionsActivity extends AppCompatActivity {
    TextView txt_logout,txt_organizer,txt_close,txt_user,txt_about_developer,txt_edit_posts,txt_editPublishedPosts,send_email,change_password;
    private View decorView;
    LinearLayout linearLayout,linearLayout2;
    GoogleSignInClient mGoogleSignInClient ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);

        txt_logout = findViewById(R.id.txt_logout);
        txt_organizer = findViewById(R.id.txt_organizer);
        txt_close = findViewById(R.id.txt_close);
        txt_user = findViewById(R.id.txt_user);
        txt_about_developer = findViewById(R.id.txt_about_developer);
        txt_edit_posts = findViewById(R.id.txt_edit_posts);
        txt_editPublishedPosts = findViewById(R.id.txt_editPublishedPosts);
        change_password = findViewById(R.id.change_password);
        send_email = findViewById(R.id.send_email);
        linearLayout2 = findViewById(R.id.linearLayout2);
        linearLayout = findViewById(R.id.linearLayout);
        FirebaseAuth.getInstance().getCurrentUser().reload();
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        // [END config_signin]

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);


        if (FirebaseAuth.getInstance().getCurrentUser().isEmailVerified()){
        }else {
            linearLayout.setVisibility(View.GONE);
            linearLayout2.setVisibility(View.VISIBLE);
        }
        send_email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               final ProgressDialog pd = new ProgressDialog(OptionsActivity.this,android.R.style.Theme_DeviceDefault_Light_Dialog);
                pd.setMessage("Please Wait...");
                //prevent from progress dialog canelation on touch outside
                pd.setCanceledOnTouchOutside(false);
                pd.show();
                FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                    pd.dismiss();
                    }
                });
            }
        });
change_password.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        startActivity(new Intent(OptionsActivity.this,ChangePasswordActivity.class));
    }
});
        txt_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        txt_organizer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(OptionsActivity.this,CreateOrganizerActivity.class));
            }
        });
        txt_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(OptionsActivity.this,EditProfileActivity.class));
            }
        });

        txt_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                mGoogleSignInClient.signOut().addOnCompleteListener(OptionsActivity.this,
                        new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                Intent intent = new Intent(getApplicationContext(),StartActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                finish();
                            }
                        });

            }
        });


        txt_about_developer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              final Dialog mDialog = new Dialog(OptionsActivity.this);
                mDialog.setContentView(R.layout.about_developer);
                TextView close =mDialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mDialog.dismiss();
                    }
                });
                mDialog.show();
            }
        });

        txt_edit_posts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(OptionsActivity.this,EditUnpublishedPosts.class));
            }
        });
        txt_editPublishedPosts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(OptionsActivity.this,ManagePostsActivity.class));
            }
        });

//show Status bar on swipe
        decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int Visibility) {
                if(Visibility == 0)
                    decorView.setSystemUiVisibility(hideSystermBars());

            }
        });

    }

    //hide status bar on focus
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus){
            decorView.setSystemUiVisibility(hideSystermBars());
        }
    }
    // UI elements to hide and show
    private int hideSystermBars(){
        return View.SYSTEM_UI_FLAG_FULLSCREEN
                |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

    }
}
