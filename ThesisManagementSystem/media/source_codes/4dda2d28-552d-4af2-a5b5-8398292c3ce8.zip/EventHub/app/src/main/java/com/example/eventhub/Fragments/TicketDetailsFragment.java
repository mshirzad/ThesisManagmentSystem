package com.example.eventhub.Fragments;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.eventhub.Models.Organizers;
import com.example.eventhub.Models.Posts;
import com.example.eventhub.Models.Tickets;
import com.example.eventhub.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

public class TicketDetailsFragment extends Fragment {

    String postid, userid, date;
    TextView txt_description, txt_title, txt_dateTime, txt_organizer_name, txt_tiket_name, txt_fees, txt_tickets_left, txt_sales_start, txt_sales_end, txt_see_more, read_more;
    ProgressBar progressBar;
    TableRow more;
    Button btn_register;
    ImageView back;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ticket_details, container, false);

        txt_description = view.findViewById(R.id.txt_ticket_description);
        txt_title = view.findViewById(R.id.txt_title);
        txt_dateTime = view.findViewById(R.id.txt_datTime);
        txt_organizer_name = view.findViewById(R.id.txt_organizer_name);
        txt_tiket_name = view.findViewById(R.id.txt_ticket_name);
        txt_fees = view.findViewById(R.id.txt_fees);
        txt_tickets_left = view.findViewById(R.id.txt_tickets_left);
        progressBar = view.findViewById(R.id.progress_bar);
        more = view.findViewById(R.id.more);
        txt_see_more = view.findViewById(R.id.see_more);
        txt_sales_start = view.findViewById(R.id.txt_sales_start);
        txt_sales_end = view.findViewById(R.id.txt_sales_end);
        read_more = view.findViewById(R.id.read_more);
        btn_register = view.findViewById(R.id.btn_register);
        back = view.findViewById(R.id.ic_back);


        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);

        bottomNavigationView.setVisibility(View.GONE);


        SharedPreferences preferences = getContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE);
        postid = preferences.getString("postid", "none");
        final String publisher = preferences.getString("publisher","none");




        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = getContext().getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();
                editor.putString("postid", postid);
                editor.putString("publisher", publisher);
                editor.apply();
                ((FragmentActivity) getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_contatiner,new RegistrationFragment()).addToBackStack(null).commit();
            }
        });


back.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        getActivity().onBackPressed();
    }
});

        txt_see_more.setText("More info");
        txt_see_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (more.getVisibility() == View.GONE) {
                    more.setVisibility(View.VISIBLE);
                    txt_see_more.setText("Less info");

                } else {
                    more.setVisibility(View.GONE);
                    txt_see_more.setText("More info");
                }
            }
        });

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Tickets").child(postid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                final Tickets tickets = dataSnapshot.getValue(Tickets.class);
                txt_description.setText(tickets.getDescription());
                txt_tiket_name.setText(tickets.getName());
                if (tickets.getPrice().equals("Free")) {
                    txt_fees.setText(tickets.getPrice());
                } else
                    txt_fees.setText(tickets.getPrice() + " AFN");

                Long startdate = Long.parseLong(tickets.getStartDate());
                Calendar calender = Calendar.getInstance();
                calender.setTimeInMillis(startdate);
                txt_sales_start.setText(calender.get(Calendar.DAY_OF_MONTH) + " " + generateMonthabb(((calender.get(Calendar.MONTH) + 1))) + " " + calender.get(Calendar.YEAR));

                Long enddate = Long.parseLong(tickets.getEndDate());
                Calendar ed = Calendar.getInstance();
                ed.setTimeInMillis(enddate);

                txt_sales_end.setText(ed.get(Calendar.DAY_OF_MONTH) + " " + generateMonthabb(((ed.get(Calendar.MONTH)) + 1)) + " " + ed.get(Calendar.YEAR));

                if (tickets.getDescription().length() <= 250){
                    read_more.setVisibility(View.GONE);
                }
                read_more.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                       final Dialog dialog = new Dialog(getActivity(), R.style.AppTheme_FullScreen);
                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialog.setContentView(R.layout.description_layout);
                        Window window = dialog.getWindow();
                        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
                        dialog.show();
                      TextView  btn_back = dialog.findViewById(R.id.btn_back);
                       TextView description_view = (TextView) dialog.findViewById(R.id.txt_description_more);


                        description_view.setText(tickets.getDescription());

                        btn_back.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog.dismiss();
                            }
                        });
                    }
                });


                final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Participants").child(postid);
                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()){
                            Long l = dataSnapshot.getChildrenCount();
                            int join = (int) l.intValue();
                            int quantity = Integer.parseInt(tickets.getQuantity());
                            txt_tickets_left.setText(String.valueOf(quantity - join));
                        }else
                            txt_tickets_left.setText(tickets.getQuantity());


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        DatabaseReference reference2 = FirebaseDatabase.getInstance().getReference("posts").child(postid);
        reference2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Posts posts = dataSnapshot.getValue(Posts.class);
                txt_title.setText(posts.getTitle());
                userid = posts.getPublisher();
                date = posts.getStartDate();
                Calendar c = Calendar.getInstance();
                Long d = Long.parseLong(date);
                c.setTimeInMillis(d);
                String month = generateMonth(((c.get(Calendar.MONTH)) + 1));
                String day = generateDays(c.get(Calendar.DAY_OF_WEEK));


                Calendar t = Calendar.getInstance();
                Long time = Long.parseLong(posts.getStartTime());
                t.setTimeInMillis(time);

                int hourOFDAY = t.get(Calendar.HOUR_OF_DAY);
                int minuteofhour = t.get(Calendar.MINUTE);
                String amPM;
                if (hourOFDAY > 12) {
                    hourOFDAY -= 12;
                    amPM = "PM";

                } else if (hourOFDAY == 0) {
                    hourOFDAY += 12;
                    amPM = "AM";
                } else if (hourOFDAY == 12)
                    amPM = "PM";
                else
                    amPM = "AM";

                String stimes;
                if (minuteofhour <= 9) {

                    if (minuteofhour == 0) {

                        stimes = hourOFDAY + " " + amPM;
                    } else {
                        stimes = hourOFDAY + ": 0" + minuteofhour + " " + amPM;
                    }
                } else {
                    stimes = hourOFDAY + ":" + minuteofhour + " " + amPM;
                }


                Calendar et = Calendar.getInstance();
                Long endtime = Long.parseLong(posts.getEndTime());
                et.setTimeInMillis(endtime);
                int hour = et.get(Calendar.HOUR_OF_DAY);
                int minute = et.get(Calendar.MINUTE);
                String status;
                if (hour > 12) {
                    hour -= 12;
                    status = "PM";

                } else if (hour == 0) {
                    hour += 12;
                    status = "AM";
                } else if (hour == 12)
                    status = "PM";
                else
                    status = "AM";

                String etimes;
                if (minute <= 9) {

                    if (minute == 0) {

                        etimes = hour + " " + status;
                    } else {
                        etimes = hour + ": 0" + minute + " " + status;
                    }
                } else {
                    etimes = hour + ":" + minute + " " + status;
                }


                txt_dateTime.setText(day + ", " + c.get(Calendar.DAY_OF_MONTH) + " " + month + " " + c.get(Calendar.YEAR) + " from " + stimes + " to " + etimes);

                DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference("Organizers").child(userid);
                reference1.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Organizers organizers = dataSnapshot.getValue(Organizers.class);
                        txt_organizer_name.setText(organizers.getName());
                        progressBar.setVisibility(View.GONE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });








        return view;


    }

    public String generateMonth(int month) {
        String monthName;

        if (month == 1) {
            return monthName = "January";
        } else if (month == 2) {
            return monthName = "February";
        } else if (month == 3) {
            return monthName = "March";
        } else if (month == 4) {
            return monthName = "April";
        } else if (month == 5) {
            return monthName = "May";
        } else if (month == 6) {
            return monthName = "June";
        } else if (month == 7) {
            return monthName = "July";
        } else if (month == 8) {
            return monthName = "August";
        } else if (month == 9) {
            return monthName = "September";
        } else if (month == 10) {
            return monthName = "October";
        } else if (month == 11) {
            return monthName = "November";
        } else if (month == 12) {
            return monthName = "December";

        } else {
            return null;
        }

    }

    public String generateDays(int day) {
        String days;
        if (day == 7) {
            return days = "Saturday";
        } else if (day == 1)
            return days = "Sunday";
        else if (day == 2)
            return days = "Monday";
        else if (day == 3)
            return days = "Tuesday";
        else if (day == 4)
            return days = "wednesday";
        else if (day == 5)
            return days = "Thursday";
        else if (day == 6)
            return days = "Friday";
        else
            return days = "";


    }

    public String generateMonthabb(int month) {
        String monthName;

        if (month == 1) {
            return monthName = "Jan";
        } else if (month == 2) {
            return monthName = "Feb";
        } else if (month == 3) {
            return monthName = "Mar";
        } else if (month == 4) {
            return monthName = "Apr";
        } else if (month == 5) {
            return monthName = "May";
        } else if (month == 6) {
            return monthName = "Jun";
        } else if (month == 7) {
            return monthName = "Jul";
        } else if (month == 8) {
            return monthName = "Aug";
        } else if (month == 9) {
            return monthName = "Sep";
        } else if (month == 10) {
            return monthName = "Oct";
        } else if (month == 11) {
            return monthName = "Nov";
        } else if (month == 12) {
            return monthName = "Dec";

        } else {
            return null;
        }

    }

    @Override
    public void onStop() {
        super.onStop();
        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);
        bottomNavigationView.setVisibility(View.VISIBLE);

    }
}
