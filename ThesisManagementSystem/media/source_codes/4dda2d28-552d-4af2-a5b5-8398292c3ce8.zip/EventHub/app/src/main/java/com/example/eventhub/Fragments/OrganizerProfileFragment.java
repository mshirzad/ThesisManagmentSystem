package com.example.eventhub.Fragments;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.eventhub.Adapter.PostAdapter;
import com.example.eventhub.Adapter.PostsSearchAdapter;
import com.example.eventhub.CreateOrganizerActivity;
import com.example.eventhub.Models.Organizers;
import com.example.eventhub.Models.Posts;
import com.example.eventhub.PostActivity;
import com.example.eventhub.R;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;


public class OrganizerProfileFragment extends Fragment {

    public ImageView profile_image;
    public FrameLayout ic_back;
    public TextView txt_organizer_name,txt_name,txt_name1,txt_description,txt_showmore,ic_back1;
    public Button btn_follow;
    public RecyclerView recycler_view;
    public List<Posts> postLists;
    public PostsSearchAdapter postAdapter;
    CircleImageView confirm;
    private List<String> publishedlist;
    public AppBarLayout appBarLayout;
    public Dialog dialog;
    String userid;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_organizer_profile, container, false);
        profile_image = view.findViewById(R.id.profile_image);
        ic_back = view.findViewById(R.id.ic_back);
        txt_organizer_name = view.findViewById(R.id.txt_organizer_name);
        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);
        txt_name = view.findViewById(R.id.txt_name);
        txt_name1 = view.findViewById(R.id.txt_name1);
        txt_description = view.findViewById(R.id.txt_description);
        txt_showmore = view.findViewById(R.id.txt_showmore);
        btn_follow = view.findViewById(R.id.btn_follow);
        ic_back1 = view.findViewById(R.id.ic_back1);
        confirm = view.findViewById(R.id.confirm);
        recycler_view = view.findViewById(R.id.recycler_view);
        recycler_view.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        AppBarLayout appBarLayout = view.findViewById(R.id.app_bar);
        recycler_view.setLayoutManager(linearLayoutManager);
        postLists = new ArrayList<>();
        postAdapter = new PostsSearchAdapter(getContext(), postLists);
        recycler_view.setAdapter(postAdapter);
        bottomNavigationView.setVisibility(View.GONE);
        ic_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().onBackPressed();
            }
        });
        ic_back1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().onBackPressed();
            }
        });

        SharedPreferences preferences = getContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE);
        userid = preferences.getString("profileid", "none");

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Organizers").child(userid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    final Organizers organizers = dataSnapshot.getValue(Organizers.class);
                    if (dataSnapshot.exists()) {

                        isFollowing(organizers.getUserid(), btn_follow);
                        isconfirmed(organizers.getUserid(),confirm);
                        txt_organizer_name.setText(organizers.getName());
                        txt_name.setText(organizers.getName());
                        txt_name1.setText(organizers.getName());
                        Glide.with(getContext()).load(organizers.getImageurl()).into(profile_image);
                        txt_description.setText(organizers.getDescription());
                        if (organizers.getUserid().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
                            btn_follow.setVisibility(View.GONE);
                        }
                        if (organizers.getDescription().length() <= 250){
                            txt_showmore.setVisibility(View.GONE);
                        }
                        txt_showmore.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog = new Dialog(getActivity(), R.style.AppTheme_FullScreen);
                                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                dialog.setContentView(R.layout.description_layout);
                                Window window = dialog.getWindow();
                                window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
                                dialog.show();
                                TextView btn_back = dialog.findViewById(R.id.btn_back);
                               TextView description_view = (TextView) dialog.findViewById(R.id.txt_description_more);


                                description_view.setText(organizers.getDescription());

                                btn_back.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        dialog.dismiss();
                                    }
                                });
                            }
                        });


                        btn_follow.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if (btn_follow.getText().toString().equals("Follow")) {
                                    FirebaseDatabase.getInstance().getReference().child("Follow").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                            .child("following").child(organizers.getUserid()).setValue(true);
                                    FirebaseDatabase.getInstance().getReference().child("Follow").child(organizers.getUserid())
                                            .child("followers").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(true);
                                } else {
                                    FirebaseDatabase.getInstance().getReference().child("Follow").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                            .child("following").child(organizers.getUserid()).removeValue();
                                    FirebaseDatabase.getInstance().getReference().child("Follow").child(organizers.getUserid())
                                            .child("followers").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).removeValue();

                                }
                            }
                        });

                    }



            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                getActivity().onBackPressed();
                Toast.makeText(getActivity(), "failed", Toast.LENGTH_SHORT).show();
            }
        });

        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int i) {
                if (Math.abs(i) - appBarLayout.getTotalScrollRange() == 0) {
                    //collapsed
                    txt_organizer_name.setVisibility(View.VISIBLE);
                    ic_back1.setVisibility(View.VISIBLE);
                    ic_back.setVisibility(View.GONE);

                } else {
                    //expanded
                    txt_organizer_name.setVisibility(View.GONE);
                    ic_back1.setVisibility(View.GONE);
                    ic_back.setVisibility(View.VISIBLE);
                }

            }
        });

        checkPublishedPosts();

        return view;
    }



    private void checkPublishedPosts() {
        publishedlist = new ArrayList<>();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Tickets");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    publishedlist.add(snapshot.getKey());
                }

                readPosts();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


    private void readPosts() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                postLists.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    final Posts post = snapshot.getValue(Posts.class);
                    for (String postid : publishedlist){
                        if (postid != null){
                            Calendar currentDate = Calendar.getInstance();
                            Date current = currentDate.getTime();
                            if (current.before(getDate(post.getStartDate(),post.getStartTime()))) {
                            if (post.getPublisher().equals(userid) && post.getPostid().equals(postid)){
                                postLists.add(post);
                            }
                            }
                        }
                    }


                }
                postAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getActivity(), ""+databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
    private void isFollowing(final String userid, final Button button) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                .child("Follow").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("following");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child(userid).exists()) {
                    button.setText("Following");
                    button.setBackgroundResource(R.drawable.button_focus);
                    ((Button)button).setTextColor(Color.parseColor("#ffffff"));

                } else {
                    button.setText("Follow");
                    button.setBackgroundResource(R.drawable.button_background);
                    ((Button)button).setTextColor(Color.parseColor("#455cde"));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    @Override
    public void onStop() {
        super.onStop();
        BottomNavigationView bottomNavigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);

        bottomNavigationView.setVisibility(View.VISIBLE);

    }
    public Date getDate(String startDates, String startTimes){
        Long startDate = Long.parseLong(startDates);
        Long startTime = Long.parseLong(startTimes);
        Calendar t = Calendar.getInstance();
        t.setTimeInMillis(startTime);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(startDate);
        calendar.set(Calendar.HOUR_OF_DAY, t.get(Calendar.HOUR_OF_DAY));
        calendar.set(Calendar.MINUTE, t.get(Calendar.MINUTE));
        calendar.set(Calendar.MILLISECOND, t.get(Calendar.MILLISECOND));
        calendar.set(Calendar.SECOND, t.get(Calendar.SECOND));
        Date eventStartDate = calendar.getTime();
        return eventStartDate;
    }
    private void isconfirmed(String id,final CircleImageView circleImageView) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Confirmed").child(id);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    circleImageView.setVisibility(View.VISIBLE);
                } else {
                    circleImageView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
