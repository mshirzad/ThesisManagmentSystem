package com.example.eventhub.Fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.eventhub.Adapter.OrganizerAdapter;
import com.example.eventhub.Adapter.PostsSearchAdapter;
import com.example.eventhub.Models.Organizers;
import com.example.eventhub.Models.Posts;
import com.example.eventhub.R;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class SearchFragment extends Fragment {

    private RecyclerView recyclerView, recyclerView_users;
    private PostsSearchAdapter postsSearchAdapter;
    private OrganizerAdapter organizerAdapter;
    private List<Posts> posts;
    private List<Organizers> organizers;
    EditText search_bar;
    LinearLayout frm_searchOrganizers, frm_searchPosts;
    ShimmerFrameLayout shimmer_container, shimmer_container_organizers;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        recyclerView_users = view.findViewById(R.id.recycler_users);
        frm_searchPosts = view.findViewById(R.id.frm_searchPosts);
        recyclerView_users.setHasFixedSize(true);
        recyclerView_users.setLayoutManager(new LinearLayoutManager(getContext()));

        search_bar = view.findViewById(R.id.search_bar);
        shimmer_container_organizers = view.findViewById(R.id.shimmer_container_organizers);
        shimmer_container = view.findViewById(R.id.shimmer_container);
        shimmer_container.setVisibility(View.VISIBLE);


        organizers = new ArrayList<>();
        organizerAdapter = new OrganizerAdapter(getContext(), organizers, "user_item");
        recyclerView_users.setAdapter(organizerAdapter);

        recyclerView = view.findViewById(R.id.recycler);
        frm_searchOrganizers = view.findViewById(R.id.frm_searchOrganizer);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        search_bar = view.findViewById(R.id.search_bar);

        posts = new ArrayList<>();
        postsSearchAdapter = new PostsSearchAdapter(getContext(), posts);
        recyclerView.setAdapter(postsSearchAdapter);

        frm_searchOrganizers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                frm_searchPosts.setVisibility(View.VISIBLE);
                recyclerView_users.setVisibility(View.VISIBLE);
                frm_searchOrganizers.setVisibility(View.GONE);
                recyclerView.setVisibility(View.GONE);
                if (organizers.size() > 0){
                    shimmer_container_organizers.setVisibility(View.VISIBLE);
                    shimmer_container.setVisibility(View.GONE);}
                    serachUsers(search_bar.getText().toString());
            }
        });
        frm_searchPosts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                frm_searchPosts.setVisibility(View.GONE);
                recyclerView_users.setVisibility(View.GONE);
                frm_searchOrganizers.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.VISIBLE);
                if (posts.size() >0){
                    shimmer_container.setVisibility(View.VISIBLE);
                    shimmer_container_organizers.setVisibility(View.GONE);
                }
                    serachPosts(search_bar.getText().toString());
            }
        });

        search_bar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if (recyclerView.getVisibility() == View.VISIBLE) {
                    serachPosts(charSequence.toString().toLowerCase());
                } else {
                    serachUsers(charSequence.toString().toLowerCase());
                }
            }


            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        readPosts();
        readUsers();

        return view;
    }

    private void serachPosts(final String s) {
        Query query = FirebaseDatabase.getInstance().getReference("posts");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                posts.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Posts post = snapshot.getValue(Posts.class);
                    if (post.getTitle().toLowerCase().contains(s)){
                    Calendar currentDate = Calendar.getInstance();
                    Date current = currentDate.getTime();
                    if (current.before(getDate(post.getStartDate(),post.getStartTime())) && !post.getPublisher().isEmpty()) {
                        posts.add(post);
                    }
                }
                }
                postsSearchAdapter.notifyDataSetChanged();
                shimmer_container.setVisibility(View.GONE);
                if (recyclerView.getVisibility() == View.GONE) {
                    recyclerView.setVisibility(View.VISIBLE);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void readPosts() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("posts");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (search_bar.getText().toString().equals("")) {
                    posts.clear();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Posts post = snapshot.getValue(Posts.class);
                        Calendar currentDate = Calendar.getInstance();
                        Date current = currentDate.getTime();
                        if (current.before(getDate(post.getStartDate(),post.getStartTime())) && !post.getPublisher().isEmpty()) {
                            posts.add(post);
                        }

                    }
                    postsSearchAdapter.notifyDataSetChanged();
                    shimmer_container.setVisibility(View.GONE);
                    if (recyclerView.getVisibility() == View.GONE) {
                        recyclerView.setVisibility(View.VISIBLE);
                    }

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void serachUsers(final String s) {
        Query query = FirebaseDatabase.getInstance().getReference("Organizers");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                organizers.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Organizers organizer = snapshot.getValue(Organizers.class);
                    if (organizer.getName().toLowerCase().contains(s)) {
                        organizers.add(organizer);
                    }

                }
                organizerAdapter.notifyDataSetChanged();
                shimmer_container_organizers.setVisibility(View.GONE);
                if (recyclerView_users.getVisibility() == View.GONE) {
                    recyclerView.setVisibility(View.VISIBLE);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void readUsers() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Organizers");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (search_bar.getText().toString().equals("")) {
                    organizers.clear();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Organizers organizer = snapshot.getValue(Organizers.class);
                        organizers.add(organizer);

                    }
                    organizerAdapter.notifyDataSetChanged();
                    shimmer_container_organizers.setVisibility(View.GONE);
                    if (recyclerView_users.getVisibility() == View.GONE) {
                        recyclerView.setVisibility(View.VISIBLE);
                    }
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    @Override
    public void onResume() {
        search_bar.setText(null);
        super.onResume();
}
    public Date getDate(String startDates, String startTimes){
        Long startDate = Long.parseLong(startDates);
        Long startTime = Long.parseLong(startTimes);
        Calendar t = Calendar.getInstance();
        t.setTimeInMillis(startTime);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(startDate);
        calendar.set(Calendar.HOUR_OF_DAY, t.get(Calendar.HOUR_OF_DAY));
        calendar.set(Calendar.MINUTE, t.get(Calendar.MINUTE));
        calendar.set(Calendar.MILLISECOND, t.get(Calendar.MILLISECOND));
        calendar.set(Calendar.SECOND, t.get(Calendar.SECOND));
        Date eventStartDate = calendar.getTime();
        return eventStartDate;
    }


}
